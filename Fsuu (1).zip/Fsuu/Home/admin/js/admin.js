$(document).ready(function(event) {
	
	school_year();

	$('#type-option').change(function(){
		var text = $(this).val();
		console.log(text);
		if (text == "Employee") {
			window.location = "employee";
		}
		else if (text == "Student") {
			window.location = "student";
		}
		else{
			window.location = "import";
		}
	});


	// set academic
	$('#set_academic').click(function(event){

		var new_sy = $('#new_sy').val();
		var new_sem = $('#new_sem').val();

		// console.log(new_sy+''+new_sem);

		if (new_sy =="") {
			alert('Please Input The school Year');
		}
		else{
			$.ajax({
				url: "function/insert",
				type: "POST",
				data: {
					"set_year" : true,
					new_sy:new_sy,
					new_sem:new_sem,
				},
				success:function(response){
					// console.log(response);
					$('#new_sy').val("");
					if (response == 1) {
						alertify.success("Academic Year Has Been Set");
						return true;
					}
					else{
						alertify.error("Something Went Wrong");
					}
				}
			});	
		}
	});

	// select offices
	$('#office_name').change(function(event) {
		var text = $(this).val();



		if (text == "Program_dean" || text == "Department_chaiperson") {
			$('.department').addClass('show');
		}
		else{
			$('.department').removeClass('show');
		}
	});



	// add admin
	$('#add_admin').click(function(event){
		var email = $('#email').val();
		var role = $('#role').val();
		var office_name = $('#office_name').val();
		var idnumber = $('#idnumber').val();
		var dept_name = $('#dept_name').val();

		if (office_name == "Program_dean" || office_name == "Department_chaiperson") {
            $.ajax({
                url: "function/insert",
                type: "POST",
                data: {
                    "add_admin_department" : true,
                    email:email,
                    role:role,
                    office_name:office_name,
                    idnumber:idnumber,
                    dept_name:dept_name,
                },
                success:function(response){
                   
                    if (response == 1) {
                        $('#email').val('');
                        $('#head_name').val('');
                        $('#idnumber').val('');
                        $('#dept_name').val('');
                        alertify.success("Add Admin Success");
                    }
                    else if (response == 2) {
                        alertify.notify("Email Already Registered");
                    }
                    else{
                        $('#email').val('');
                        $('#head_name').val('');
                        $('#idnumber').val('');
                        alertify.error("Add Admin Failed");
                    }
                }
            });
        }
        else{
        	$.ajax({
				url: "function/insert",
				type: "POST",
				data: {
					"add_admin" : true,
					email:email,
					role:role,
					office_name:office_name,
					idnumber:idnumber,
				},
				success:function(response){
					
					if (response == 1) {
						$('#email').val('');
						$('#head_name').val('');
						$('#idnumber').val('');
						alertify.success("Add Admin Success");
					}
					else if (response == 2) {
						alertify.notify("Email Already Registered");
					}
					else{
						$('#email').val('');
						$('#head_name').val('');
						$('#idnumber').val('');
						alertify.error("Add Admin Failed");
					}
				}
			});
        }
		
	});

	$('#stud, #emplyo').change(function(event){
		var grad = $('#stud').val().split('.').pop().toLowerCase();
		var emplo = $('#emplyo').val().split('.').pop().toLowerCase();

		// console.log(grad);

		if ($.inArray(grad,['csv']) == 0) {
			$('.wrong').text("");
			$('#import').attr('disabled',false);
		}
		else if ($.inArray(emplo,['csv']) == 0) {
			$('#import_emplo').attr('disabled',false);
		}
		else{
			$('.wrong').text("Please Insert Correct File");
			$('#import').attr('disabled',true);
			$('#import_emplo').attr('disabled',true);
		}



	});

	$('#add_office').click(function(){

		

		$('.modal_add_office').addClass('bg-status')

		
	});
	$('#add_office_name').click(function(){
		var name = $('#office_name').val();
		$.ajax({
			url: "function/insert",
			type: "POST",
			data: {
				"add_office" : true,
				name:name,
			},
			success:function(response){
				console.log(response);
				if (response == 1) {
					alertify.success("Add Office Success");
					setTimeout(function(){
						$('.modal_add_office').removeClass('bg-status')
					},1000);
					setTimeout(function(){
						window.location = "progress";
					},2000);
				}
				else{

				}
			}
		});
	})

	$('#close_office').click(function(){
		$('.modal_add_office').removeClass('bg-status')
	})





	// load sy
	setInterval(function(){
		school_year();
	},1500);

	$(document).on('click', '#option', function(event) {
		event.preventDefault();
	 	var id = $(this).attr('value');
	 	var name = $("#card_office_name").text();
		
		$.ajax({
			url: "function/search",
			type: "POST",
			data: {
				"search_office" : true,
				id:id,
				name:name,
			},
			success:function(response){

				$('.table-office').empty();

				if (response == 2) {
					$('.modal-option-office').addClass('bg-status');
					$('#delete-office').attr('value',id);
					 $('#add-office').attr('value',id);
				}
				else{
					$.each(response, function(index, val) {
						$('.modal-option-office').addClass('bg-status')
						 $('.office-name').text(val['office_name']);
						 // $('#edit-office').attr('value',val['office_name_id']);
						 $('#add-office').attr('value',val['office_name_id']);
						 $('#delete-office').attr('value',id);
						 $('.table-office').append('<tr>'+
						 	
						 	'<td class="">'+val['office_fname']+' '+val['office_lname']+'</td>'+
						 	'<td class="text-center"> <button id="edit-office" class="btn btn-sm btn-secondary" value='+val['account_fk']+'><i class="fas fa-pen"></i> Edit</button>  <button id="remove_account" class="btn btn-sm btn-danger" value='+val['account_fk']+'><i class="fas fa-user-times"></i> Remove</button> <button class="btn btn-sm btn-primary" value='+val['account_fk']+' id="transfer"> <i class="fas fa-arrow-circle-right"></i> Transfer</button> </td>'+
						 	'</tr>');
					});
				}
			}
		});
	});

	$('#close_office_modal').click(function(event) {
		/* Act on the event */
		$('.modal-option-office').removeClass('bg-status')
	});

	$(document).on('click', '#transfer', function(event) {
		event.preventDefault();
		var id = $(this).attr('value');

			$('.option-btn').hide(300);
			$('.trasnfer_data').show(400)

		$.ajax({
			url: "function/search",
			type: "POST",
			data: {
				"search_office_data" : true,
				id:id,
			},
			success:function(response){
				if (response == 2) {
					
				}
				else{
					$.each(response, function(index, val) {
						 /* iterate through array or object */
						 $('#transfer_account_data').attr('value',val['account_fk']);
						 $('#tmp_email').attr('value',val['email']);
						 $('#idnum').attr('value',val['account_fk']);
					});
				}
			}
		})
		/* Act on the event */
	});

	$('#transfer_account_data').click(function(event) {
		/* Act on the event */
		var id = $(this).attr('value');
		var office_id = $('#office_name_transfer').val();
		var email = $('#tmp_email').val();

		$.ajax({
			url: "function/update",
			type: "POST",
			data: {
				"transfer_data" : true,
				id:id,
				office_id:office_id,
			},
			success:function(response){
				if (response == 1) {
					alertify.success(email+' '+'Transfered');
					setTimeout(function(){
						window.location = "progress";
					},1500);
				}
				else{
					alertify.error("Failed To Transfer");
				}
			}
		});

	});

	$('#cancel-transfer').click(function(event) {
		/* Act on the event */

		$('.option-btn').show(300);
			$('.trasnfer_data').hide(400)
	});

	$(document).on('click', '#remove_account', function(event) {
		event.preventDefault();

		var id = $(this).attr('value');

		// console.log(id);

		

		$.ajax({
			url: "function/update",
			type: "POST",
			data: {
				"remove_account_data" : true,
				id:id,
			},
			success:function(response){
				console.log(response);
				if (response == 1) {
					alertify.success("Remove Account");
					$('.modal-option-office').removeClass('bg-status')
					setTimeout(function(){
						window.location="progress"
					},2000);
				}
				else{
					alertify.error("Something went wrong");
				}
			}
		})

		/* Act on the event */
	});

	$(document).on('click', '#edit-office', function(event) {
		event.preventDefault();
		var id = $(this).attr('value');

		console.log(id);

		$.ajax({
			url: "function/search",
			type: "POST",
			data: {
				"search_data_person" : true,
				id:id,
			},
			success:function(response){
				// console.log(response);
				if (response == 2) {
					
				}
				else{
					$.each(response, function(index, val) {
						 /* iterate through array or object */
						 // console.log(val['email']);
						 $('.modal-option-office').removeClass('bg-status')
						 $('.modal-profile').addClass('bg-status')
						 $('#office_email').prop('value',val['email']);
						 $('#fname').prop('value',val['office_fname']);
						 $('#lname').prop('value',val['office_lname']);
						 $('#update_status').attr('value',id);
					});
				}
			}
		})

		/* Act on the event */
	});

	$('#close_profile').click(function(event) {
		/* Act on the event */

		$('.modal-option-office').addClass('bg-status')
		$('.modal-profile').removeClass('bg-status')
	});

	$('#update_status').click(function(event) {
		var id = $(this).attr('value');

		var email = $('#office_email').val();
		var fname = $('#fname').val();
		var lname = $('#lname').val();

		$.ajax({
			url: "function/update",
			type: "POST",
			data: {
				"update_info" : true,
				id:id,
				email:email,
				fname:fname,
				lname:lname,
			},
			success:function(response){
				console.log(response);
				if (response == 1) {
					alertify.success("Person Updated Data");
					$('.modal-option-office').removeClass('bg-status')
					setTimeout(function(){
						window.location="progress"
					},2000);
				}
				else{
					alertify.error("Something went wrong");
				}
			}
		})
	});

	$('#delete-office').click(function(event) {
		var id = $(this).attr('value');

		$.ajax({
			url: "function/update",
			type: "POST",
			data: {
				"delete_office" : true,
				id:id,
			},
			success:function(response){
				if (response == 1) {
					alertify.success("Office Delete");
					$('.modal-option-office').removeClass('bg-status')
					setTimeout(function(){
						window.location="progress"
					},2000);
				}
				else{
					alertify.error("Something went wrong");
				}
			}
		})
	});
	$('#add-office').click(function(event) {
		var id = $(this).attr('value');

		$('.option-btn').hide(300);
		$('.add-person').show(300);
		$('.office-footer').hide(300);
	});

	$('#cancel-add-person').click(function(event) {
		/* Act on the event */
		$('.option-btn').show(300);
		$('.add-person').hide(300);
		$('.office-footer').show(300);
	});
	$('#add-personel').click(function(event) {
		/* Act on the event */

		var id = $('#add-office').attr('value');
		var email = $('#email').val();
		var idnum = $('#idnum').val();
		var office_name = $('.office-name').text();

		$.ajax({
			url: "function/update",
			type: "POST",
			data: {
				"add-office" : true,
				id:id,
				email:email,
				idnum:idnum,
				office_name:office_name,
			},
			success:function(response){
				console.log(response);
				if (response == 1) {
					alertify.success("Add Person");
					$('.modal-option-office').removeClass('bg-status')
					 $('#email').val('');
					 $('#idnum').val('');
					setTimeout(function(){
						window.location="progress"
					},2000);
				}
				else if (response == 2) {
					alertify.notify("Email Existed");
				}
				else{
					alertify.error("Something went wrong");
				}
			}
		})

	});
});



function school_year(){
	// console.log("daw");

	$.ajax({
		url: "function/load",
		type: "POST",
		cache: false,
		success:function(response){
			if (response == 2) {

			}
			else{
				$.each(response,function(index,val){
					$('#sy').prop('value',val['school_year']);
					$('#sem').prop('value',val['semester']);
				});
			}
		}
	});
}