<?php  



	require "../../../../connector/connect.php";

	if (isset($_POST['Apply'])) {
		
		$id = mysqli_real_escape_string($conn,$_POST['id']);
		$purpose = mysqli_real_escape_string($conn,$_POST['purpose']);
		$office = mysqli_real_escape_string($conn,$_POST['office']);
		$key = mysqli_real_escape_string($conn,$_POST['key']);

		if ($purpose == "") {
			echo 3;
		}
		else{
				if ($purpose == "PERAA") {

				$find = "SELECT *FROM tbl_employee_status WHERE tbl_employee_account_fk = $key AND purpose = '$purpose'";

				$result = mysqli_query($conn,$find);

				if (mysqli_num_rows($result) > 0) {
					echo 2;
				}
				else{
					$sql = "INSERT INTO tbl_employee_status (registrar,purpose,library,program_dean,pmo,bookstore,ITSD,Comptroller,Guidance,Graduate_Studies,HRMD,vp_asa,president,asp_dean,Cashier,vp_aar,Department_chair,tbl_employee_account_fk,department_name) VALUES('pending','$purpose','pending','','pending','pending','pending','pending','pending','pending','pending','pending','pending','','','','',$key,'$office')";
					if (mysqli_query($conn,$sql) === TRUE) {
						echo 1;
					}
				}
			}
			else if ($purpose == "SEPARATION") {

				$find = "SELECT *FROM tbl_employee_status WHERE tbl_employee_account_fk = $key AND purpose = '$purpose'";

				$result = mysqli_query($conn,$find);

				if (mysqli_num_rows($result) > 0) {
					echo 2;
				}
				else{
					$sql = "INSERT INTO tbl_employee_status (registrar,purpose,library,program_dean,pmo,bookstore,ITSD,Comptroller,Guidance,Graduate_Studies,HRMD,vp_asa,president,asp_dean,Cashier,vp_aar,Department_chair,tbl_employee_account_fk,department_name) VALUES('pending','$purpose','pending','pending','pending','pending','pending','pending','','','pending','','','pending','pending','pending','',$key,'$office')";

					if (mysqli_query($conn,$sql) === TRUE) {
						echo 1;
					}
				}
			}
			else{

				$find = "SELECT *FROM tbl_employee_status WHERE tbl_employee_account_fk = $key AND purpose = '$purpose'";

				$result = mysqli_query($conn,$find);

				if (mysqli_num_rows($result) > 0) {
					echo 2;
				}
				else{
					$sql = "INSERT INTO tbl_employee_status (registrar,purpose,library,program_dean,pmo,bookstore,ITSD,Comptroller,Guidance,Graduate_Studies,HRMD,vp_asa,president,asp_dean,Cashier,vp_aar,Department_chair,tbl_employee_account_fk,department_name) VALUES('pending','$purpose','pending','pending','pending','pending','','','','','pending','','','','','pending','pending',$key,'$office')";

					if (mysqli_query($conn,$sql) === TRUE) {
						echo 1;
					}
				}
			}
		}


		

	}



?>