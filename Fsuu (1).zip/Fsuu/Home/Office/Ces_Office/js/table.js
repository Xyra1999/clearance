$(document).ready(function() {
   
    $('#example').DataTable({
        "processing": true,
        "serverSide": true,
        "ajax" : "function/fetch"
        // "ajax":{
        //     url:"function/fetch",
        //     type:"post"
        // }
    });
    responsive: true

});




