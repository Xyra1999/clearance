<?php   
	session_start();
	unset($_SESSION['dsa']); 
	header("location: ../../../index"); 
	exit();
?>