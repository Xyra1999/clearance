<?php  


	require "../../../../connector/connect.php";

	session_start();

	if (isset($_POST['search'])) {
		$id = mysqli_real_escape_string($conn,$_POST['id']);


		$update = "UPDATE tbl_employee_msg SET status = 1 WHERE employee_msg_id = $id";

		if (mysqli_query($conn,$update) === TRUE) {
			$sql = "SELECT *FROM tbl_employee_msg WHERE employee_msg_id = $id";

			$result_val = [];
			$result_q = mysqli_query($conn,$sql);
			if (mysqli_num_rows($result_q) > 0) {
				foreach ($result_q as $value) {
				    array_push($result_val,$value);
				    // break;

				}
				header("Content-type: application/json");
				echo json_encode($result_val);

			}
			else{
				echo 2;
			}
		}
	}
	else if (isset($_POST['search_data'])) {
		$id = mysqli_real_escape_string($conn,$_POST['id']);

		$sql = "SELECT *FROM account_type WHERE account_info_id = $id";

		$result_find = mysqli_query($conn,$sql);

		if (mysqli_num_rows($result_find) > 0) {
			while ($row = mysqli_fetch_assoc($result_find)) {
				$id = $row['account_info_id'];
				$_SESSION['teaching_id'] = $id;
				echo "Yes";
				break;

			}
			# code...
		}
	}
	else if (isset($_POST['search_msg'])) {
		
		$id = mysqli_real_escape_string($conn,$_POST['id']);
		$office = $_SESSION['name'];


		$search_purpose = "SELECT *FROM tbl_defiency_employee WHERE tbl_library_defiency_id = $id";

		// echo $office_a;

		$result_find = mysqli_query($conn,$search_purpose);
		$result_val = [];
		$result_q = mysqli_query($conn,$search_purpose);
		if (mysqli_num_rows($result_q) > 0) {
			foreach ($result_q as $value) {
			    array_push($result_val,$value);
			    break;

			}
			header("Content-type: application/json");
			echo json_encode($result_val);

		}
		else{
			echo 2;
		}

			
	}
?>
