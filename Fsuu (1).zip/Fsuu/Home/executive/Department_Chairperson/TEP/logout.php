<?php   
	session_start();
	unset($_SESSION['chair_tep']); 
	header("location: ../../../../index"); 
	exit();
?>