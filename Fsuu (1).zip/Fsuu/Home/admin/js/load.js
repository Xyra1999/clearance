$(document).ready(function(event) {

	load_data();

	setInterval(function(){
		load_data();
	},2000);

});


function load_data(){
	
	$.ajax({
		url: "function/data",
		cache: false,
		type: "POST",

		success:function(response){
			// $('.load_data').remove();
			// console.log(response);
			if (response == 2) {

			}
			else{

				$.each(response,function(val,index){
					// console.log(index['account_fk']);
					$('.load_data').append("awd")
				});
			}
		}
	});	
}