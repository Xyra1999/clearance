<?php

require_once 'assets/google/vendor/autoload.php';

$google_client = new Google_Client();

//Set the OAuth 2.0 Client ID
$google_client->setClientId('274068133905-4tquuct6bu8lku35ns4a5t2voj1r8eb1.apps.googleusercontent.com');

//Set the OAuth 2.0 Client Secret key
$google_client->setClientSecret('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');

//Set the OAuth 2.0 Redirect URI
$google_client->setRedirectUri('http://localhost/Fsuu/controller');


$google_client->addScope("https://www.googleapis.com/auth/plus.login https://www.googleapis.com/auth/userinfo.email");


$login_url = $google_client->createAuthUrl();

// session_start();

?>