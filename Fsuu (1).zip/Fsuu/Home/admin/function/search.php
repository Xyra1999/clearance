<?php  


	require "../../../connector/connect.php";

	if (isset($_POST['search_data'])) {
		
		$id = mysqli_real_escape_string($conn,$_POST['id']);


		$search = "SELECT *FROM tbl_employee_status WHERE tbl_employee_id = $id";

		$result_val = [];
		$result_q = mysqli_query($conn,$search);
		if (mysqli_num_rows($result_q) > 0) {
			foreach ($result_q as $value) {
			    array_push($result_val,$value);
			}
			header("Content-type: application/json");
			echo json_encode($result_val);

		}
		else{
			echo 2;
		}
	}
	else if (isset($_POST['student_search'])) {
		$id = mysqli_real_escape_string($conn,$_POST['id']);

		$search = "SELECT *FROM tbl_student_status WHERE student_info_id = $id";

		$result_val = [];
		$result_q = mysqli_query($conn,$search);
		if (mysqli_num_rows($result_q) > 0) {
			foreach ($result_q as $value) {
			    array_push($result_val,$value);
			}
			header("Content-type: application/json");
			echo json_encode($result_val);

		}
		else{
			echo 2;
		}
	}
	else if (isset($_POST['search_office'])) {
		$id = mysqli_real_escape_string($conn,$_POST['id']);
		$name = mysqli_real_escape_string($conn,$_POST['name']);

		$search = "SELECT *FROM tbl_office_name as office_name JOIN office_head as head ON office_name.office_name_id = head.office_name_fk WHERE office_name_id = $id";

		$result_val = [];
		$result_q = mysqli_query($conn,$search);
		if (mysqli_num_rows($result_q) > 0) {
			foreach ($result_q as $value) {
			    array_push($result_val,$value);
			}
			header("Content-type: application/json");
			echo json_encode($result_val);
		}

		else{
			echo 2;
		}
	}
	else if (isset($_POST['search_data_person'])) {
		$id = mysqli_real_escape_string($conn,$_POST['id']);

		$search = "SELECT *from account_type as account JOIN office_head as head ON account.account_info_id = head.account_fk WHERE account.account_info_id = $id";

		$result_val = [];
		$result_q = mysqli_query($conn,$search);
		if (mysqli_num_rows($result_q) > 0) {
			foreach ($result_q as $value) {
			    array_push($result_val,$value);
			}
			header("Content-type: application/json");
			echo json_encode($result_val);

		}
		else{
			echo 2;
		}
	}
	else if (isset($_POST['search_office_data'])) {
		$id = mysqli_real_escape_string($conn,$_POST['id']);

		$sql = "SELECT *FROM account_type as account JOIN office_head as head ON account.account_info_id = head.account_fk  WHERE account.account_info_id = $id";

		$result_val = [];
		$result_q = mysqli_query($conn,$sql);
		if (mysqli_num_rows($result_q) > 0) {
			foreach ($result_q as $value) {
			    array_push($result_val,$value);
			}
			header("Content-type: application/json");
			echo json_encode($result_val);

		}
		else{
			echo 2;
		}
	}


?>