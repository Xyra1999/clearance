<?php   
	session_start();
	unset($_SESSION['hrmd']); 
	header("location: ../../../index"); 
	exit();
?>