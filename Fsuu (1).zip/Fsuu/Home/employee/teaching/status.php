<?php  


	session_start();

	if ($_SESSION['teaching']) {
		require "../../../connector/connect.php";
		$email = $_SESSION['teaching'];

		$find = "SELECT *from account_type WHERE email ='$email'";

		$result = mysqli_query($conn,$find);

	    if (mysqli_num_rows($result) > 0) {
	        while ($row = mysqli_fetch_assoc($result)) {
	            $u_email = $row['email'];
	            $id = $row['account_info_id'];
	            Data($u_email,$id);
	            break;
	        }
    	}
	}
	else{
		header("location: ../../../index");
		exit();
	}
?>

<?php  

	function Data($u_email,$id){
		require "../../../connector/connect.php";

		$search = "SELECT *FROM account_type as account JOIN tbl_employee as employee ON account.account_info_id = employee.emplo_account_fk WHERE employee.emplo_account_fk = '$id'";

		$result = mysqli_query($conn,$search);

	    if (mysqli_num_rows($result) > 0) {
	        while ($row = mysqli_fetch_assoc($result)) {
	            $fname = $row['emplo_fname'];
	            $mname = $row['emplo_mname'];
	            $lname = $row['emplo_lname'];
	            $emplo_id = $row['emplo_idnumber'];
	            $emplo_school_year = $row['emplo_school_year'];
	            $employee_id = $row['employee_id'];
	            Display($u_email,$fname,$mname,$lname,$emplo_id,$emplo_school_year,$employee_id);
	            break;
	        }
    	}

	}
?>

<?php  

	function Display($u_email,$fname,$mname,$lname,$emplo_id,$emplo_school_year,$employee_id){
		?>

			<!DOCTYPE html>
			<html>
			<head>
				<meta charset="utf-8">
				<meta http-equiv="X-UA-Compatible" content="IE=edge">
				<link href="../../../assets/css/bootstrap.min.css" rel="stylesheet">
				<link rel="stylesheet" href="../../../assets/css/style.css">
				<link href="../../../assets/icon/fsuu.png" rel="icon">
				<link rel="stylesheet" href="css/teaching.css">
				<script type="text/javascript" src="../../../assets/js/jquery-3.4.1.min.js"></script>
				<title>Father Saturnino Urios University</title>
			</head>
			<body>


			<!-- header -->
			<nav class="navbar navbar-default banner-color">
			  <div class="container-fluid">
			    <a href="index"><img src="../../../assets/image/plain.png" alt="" height="100" width="200" class="img-fluid rounded"></a>
			    <div class="d-flex">
			      <div class="row">
			      	<div class="list">
			      		<ul>
			      			<li><span class="text-light fw-bold" style="font-size: 18px;"><?php echo $fname." ".$lname; ?></span></li>
			      			<li><a href="profile" class="text-light fw-bold"><i class="fas fa-user-circle fs-6"></i></a></li>
			      			<li><button class="btn btn-sm btn-outline"><i class="fas fa-bell fs-5 text-light"></i></button></li>
			      			<li><a class="text-light fw-bold" href="logout"><i class="fas fa-power-off"></i></a></li>
			      		</ul>
			      	</div>
			      </div>
			    </div>
			  </div>
			</nav>
			<div class="color-header">
				<div class="container">
					<div class="inside-header text-left">
						<ul>
							<li><a href="apply" class="text-secondary">Apply Clearance</a></li>
							<li><a class="text-secondary" href="archieves">Archieves</a></li>
							<li><a class="text-secondary" href="status">Status</a></li>
							<li><a href="message" class="text-secondary">Deficiency/Requirements</a></li>
						</ul>
					</div>
				</div>
			</div>
			<!-- end of header -->

			<div class="container mt-3">
				<div class="col-md-4">
					<label for="" class="form-label">
						<h3>Status</h3>
					</label>
					<select name="" id="status_select" class="form-select">
						<option value="" selected disabled>Status Select</option>
						<option value="PERAA">PERAA</option>
						<option value="SEPARATION">SEPARATION</option>
						<option value="GRADING">GRADING</option>
					</select>
				</div>
			</div>

			<!-- <div class="container mt-3">
				<h3>Status</h3>
				<table class="table" width="100%">
					<thead>
						<tr class="table-dark text-center">
							<th>Officess</th>
							<th>Requirements</th>
							<th>Action</th>
							<th>Status</th>
						</tr>
					</thead>
					<tbody>
						<tr class="text-center">
							<td>Admission</td>
							<td><button class="btn btn-sm btn-primary">View Requirements</button></td>
							<td><button class="btn btn-sm btn-primary"><i class="fas fa-envelope"></i></button></td>
							<td><span class="text-light bg-danger p-2 rounded">Pending</span></td>
						</tr>
						
					</tbody>
				</table>
			</div> -->



	
		<?php
	}

?>



<script type="text/javascript" src="../../../assets/js/fontawesome.js"></script>
<script type="text/javascript" src="js/update.js"></script>

</body>
</html>