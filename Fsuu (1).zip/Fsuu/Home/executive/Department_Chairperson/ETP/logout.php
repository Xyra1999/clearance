<?php   
	session_start();
	unset($_SESSION['chair_etp']); 
	header("location: ../../../../index"); 
	exit();
?>