$(document).ready(function(){
	sepration_load();


	setInterval(function(){
		sepration_load();
	},2000);
});

function sepration_load(){

	$.ajax({
		url: "function/sepration_load",
		cache: false,

		success:function(response){
			$('td').remove();
			if (response == 2) {

			}
			else{
				$.each(response,function(index,val){

					
                $('.separation_data').append('<tr class="text-center">'+
                            '<td>Registrar Office</td>'+
                            '<td><button class="btn btn-sm btn-primary">View Requirements</button></td>'+
                            '<td><button class="btn btn-sm btn-primary"><i class="fas fa-envelope"></i></button></td>'+
                            '<td><span id="regis" class="text-light bg-danger p-2 rounded" style="font-size: 13px;">'+val['registrar']+'</span></td>'+
                        '</tr>'+
                        '<tr class="text-center">'+
                            '<td>College Librarian</td>'+
                            '<td><button class="btn btn-sm btn-primary">View Requirements</button></td>'+
                            '<td><button class="btn btn-sm btn-primary"><i class="fas fa-envelope"></i></button></td>'+
                            '<td><span class="text-light bg-danger p-2 rounded" style="font-size: 13px;">'+val['library']+'</span></td>'+
                        '</tr>'+
                        '<tr class="text-center">'+
                            '<td>Property and Maintenance Office</td>'+
                            '<td><button class="btn btn-sm btn-primary">View Requirements</button></td>'+
                            '<td><button class="btn btn-sm btn-primary"><i class="fas fa-envelope"></i></button></td>'+
                            '<td><span class="text-light bg-danger p-2 rounded" style="font-size: 13px;">'+val['pmo']+'</span></td>'+
                        '</tr>'+
                        '<tr class="text-center">'+
                            '<td>Bookstore/Auxilliary Resource Services</td>'+
                            '<td><button class="btn btn-sm btn-primary">View Requirements</button></td>'+
                            '<td><button class="btn btn-sm btn-primary"><i class="fas fa-envelope"></i></button></td>'+
                            '<td><span class="text-light bg-danger p-2 rounded" style="font-size: 13px;">'+val['bookstore']+'</span></td>'+
                        '</tr>'+
                        '<tr class="text-center">'+
                            '<td>ITSD</td>'+
                            '<td><button class="btn btn-sm btn-primary">View Requirements</button></td>'+
                            '<td><button class="btn btn-sm btn-primary"><i class="fas fa-envelope"></i></button></td>'+
                            '<td><span class="text-light bg-danger p-2 rounded" style="font-size: 13px;">'+val['ITSD']+'</span></td>'+
                        '</tr>'+
                        '<tr class="text-center">'+
                            '<td>Comptroller</td>'+
                            '<td><button class="btn btn-sm btn-primary">View Requirements</button></td>'+
                            '<td><button class="btn btn-sm btn-primary"><i class="fas fa-envelope"></i></button></td>'+
                            '<td><span class="text-light bg-danger p-2 rounded" style="font-size: 13px;">'+val['Comptroller']+'</span></td>'+
                        '</tr>'+
                        '<tr class="text-center">'+
                            '<td>Program Dean</td>'+
                            '<td><button class="btn btn-sm btn-primary">View Requirements</button></td>'+
                            '<td><button class="btn btn-sm btn-primary"><i class="fas fa-envelope"></i></button></td>'+
                            '<td><span class="text-light bg-danger p-2 rounded" style="font-size: 13px;">'+val['HRMD']+'</span></td>'+
                        '</tr>'+
                        '<tr class="text-center">'+
                            '<td>Graduate Studies and Research</td>'+
                            '<td><button class="btn btn-sm btn-primary">View Requirements</button></td>'+
                            '<td><button class="btn btn-sm btn-primary"><i class="fas fa-envelope"></i></button></td>'+
                            '<td><span class="text-light bg-danger p-2 rounded" style="font-size: 13px;">'+val['asp_dean']+'</span></td>'+
                        '</tr>'+
                        '<tr class="text-center">'+
                            '<td>Cashier</td>'+
                            '<td><button class="btn btn-sm btn-primary">View Requirements</button></td>'+
                            '<td><button class="btn btn-sm btn-primary"><i class="fas fa-envelope"></i></button></td>'+
                            '<td><span class="text-light bg-danger p-2 rounded" style="font-size: 13px;">'+val['Cashier']+'</span></td>'+
                        '</tr>'+
                        '<tr class="text-center">'+
                            '<td>Academic Affairs and Research (VP-AAR)</td>'+
                            '<td><button class="btn btn-sm btn-primary">View Requirements</button></td>'+
                            '<td><button class="btn btn-sm btn-primary"><i class="fas fa-envelope"></i></button></td>'+
                            '<td><span class="text-light bg-danger p-2 rounded" style="font-size: 13px;">'+val['vp_aar']+'</span></td>'+
                        '</tr>');
					
				});
			}
		}
	});
}