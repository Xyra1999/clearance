<?php  


	session_start();

	if ($_SESSION['etp']) {
		require "../../../../connector/connect.php";
		$email = $_SESSION['etp'];

		$find = "SELECT *from account_type WHERE email ='$email'";

		$result = mysqli_query($conn,$find);

	    if (mysqli_num_rows($result) > 0) {
	        while ($row = mysqli_fetch_assoc($result)) {
	            $u_email = $row['email'];
	            $id = $row['account_info_id'];
	            Data($u_email,$id);
	            break;
	        }
    	}
	}
	else{
		header("location: ../../../../index");
		exit();
	}

?>

<?php  

	function Data($u_email,$id){
		require "../../../../connector/connect.php";

		$search = "SELECT *FROM account_type as account JOIN office_head as office ON account.account_info_id = office.account_fk WHERE office.account_fk = $id";

		$result = mysqli_query($conn,$search);

	    if (mysqli_num_rows($result) > 0) {
	        while ($row = mysqli_fetch_assoc($result)) {
	            $u_email = $row['email'];
	            $fname = $row['office_fname'];
	            $lname = $row['office_lname'];
	            Display($u_email,$fname,$lname);
	            break;
	        }
    	}

	}
?>

<?php  

	function Display($u_email,$fname,$lname){
		?>

			<!DOCTYPE html>
			<html>
			<head>
				<meta charset="utf-8">
				<meta http-equiv="X-UA-Compatible" content="IE=edge">
				<link href="../../../../assets/css/bootstrap.min.css" rel="stylesheet">
				<link rel="stylesheet" href="../../../../assets/css/style.css">
				<link href="../../../../assets/icon/fsuu.png" rel="icon">
				<title>Father Saturnino Urios University</title>
			</head>
			<body>


			<!-- header -->
			<nav class="navbar navbar-default banner-color">
			  <div class="container-fluid">
			    <a href="index"><img src="../../../../assets/image/plain.png" alt="" height="100" width="200" class="img-fluid rounded"></a>
			    <div class="d-flex">
			      <div class="row">
			      	<div class="list">
			      		<ul>
			      			<li><span class="text-light fw-bold" style="font-size: 15px;">Engineering and Technology Program</span></li>
			      			<li><span class="text-light fw-bold" style="font-size: 16px;"><?php echo $fname." ".$lname; ?></span></li>
			      			<li><a href="profile" class="text-light fw-bold"><i class="fas fa-user-circle fs-6"></i></a></li>
			      			<li><a class="text-light fw-bold" href="logout"><i class="fas fa-power-off"></i></a></li>
			      		</ul>
			      	</div>
			      </div>
			    </div>
			  </div>
			</nav>
			<div class="color-header">
				<div class="container">
					<div class="inside-header text-left">
						<ul>
							<li><a href="applicant" class="text-secondary">Applicant</a></li>
							<li><a class="text-secondary" href="clearance">Clearance Cleared</a></li>
							<li><a href="logs" class="text-secondary">Activity Log</a></li>
						</ul>
					</div>
				</div>
			</div>
			<!-- end of header -->

		<?php
	}

?>



<script type="text/javascript" src="../../../../assets/js/fontawesome.js"></script>
<script type="text/javascript" src="../../../../assets/js/jquery-3.4.1.min.js"></script>
<script src="js/admin.js"></script>

</body>
</html>