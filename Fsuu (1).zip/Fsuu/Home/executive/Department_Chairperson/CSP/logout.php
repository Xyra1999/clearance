<?php   
	session_start();
	unset($_SESSION['chair_csp']); 
	header("location: ../../../../index"); 
	exit();
?>