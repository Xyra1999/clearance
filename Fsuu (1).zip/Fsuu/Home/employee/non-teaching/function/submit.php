<?php  

	require "../../../../connector/connect.php";

	if (isset($_POST['apply_clearance'])) {
		$id = mysqli_real_escape_string($conn,$_POST['id']);
		$type = mysqli_real_escape_string($conn,$_POST['text']);

		if ($type == "") {
			echo 3;
		}
		else{
			if ($type == "PERAA") {

				$find = "SELECT *FROM tbl_employee_status WHERE tbl_employee_account_fk = $id AND purpose = '$type'";

				$result = mysqli_query($conn,$find);

				if (mysqli_num_rows($result) > 0) {
					echo 2;
				}
				else{
					$sql = "INSERT INTO tbl_employee_status (registrar,purpose,library,program_dean,pmo,bookstore,ITSD,Comptroller,Guidance,Graduate_Studies,HRMD,vp_asa,president,asp_dean,Cashier,vp_aar,Department_chair,tbl_employee_account_fk) VALUES('pending','$type','pending','','pending','pending','pending','pending','pending','pending','pending','pending','pending','','','','',$id)";
					if (mysqli_query($conn,$sql) === TRUE) {
						echo 1;
					}
				}
			}
			else if ($type == "SEPARATION") {

				$find = "SELECT *FROM tbl_employee_status WHERE tbl_employee_account_fk = $id AND purpose = '$type'";

				$result = mysqli_query($conn,$find);

				if (mysqli_num_rows($result) > 0) {
					echo 2;
				}
				else{
					$sql = "INSERT INTO tbl_employee_status (registrar,purpose,library,program_dean,pmo,bookstore,ITSD,Comptroller,Guidance,Graduate_Studies,HRMD,vp_asa,president,asp_dean,Cashier,vp_aar,Department_chair,tbl_employee_account_fk) VALUES('pending','$type','pending','pending','pending','pending','pending','pending','','','pending','','','pending','pending','pending','',$id)";

					if (mysqli_query($conn,$sql) === TRUE) {
						echo 1;
					}
				}
			}
			else{
				$find = "SELECT *FROM tbl_employee_status WHERE tbl_employee_account_fk = $id AND purpose = '$type'";

				$result = mysqli_query($conn,$find);
				if (mysqli_num_rows($result) > 0) {
					echo 2;
				}
				else{
					$sql = "INSERT INTO tbl_employee_status (registrar,purpose,library,program_dean,pmo,bookstore,ITSD,Comptroller,Guidance,Graduate_Studies,HRMD,vp_asa,president,asp_dean,Cashier,vp_aar,Department_chair,tbl_employee_account_fk) VALUES('pending','$type','pending','pending','pending','pending','','','','','pending','','','','','pending','pending',$id)";

					if (mysqli_query($conn,$sql) === TRUE) {
						echo 1;
					}
				}
			}
		}

	}
	else if (isset($_POST['update'])) {
		
		$id = mysqli_real_escape_string($conn,$_POST['id']);

		$fname = mysqli_real_escape_string($conn,$_POST['fname']);
		$mname = mysqli_real_escape_string($conn,$_POST['mname']);
		$lname = mysqli_real_escape_string($conn,$_POST['lname']);
		$load = mysqli_real_escape_string($conn,$_POST['load']);

		$sql ="UPDATE tbl_employee as employee JOIN tbl_employee_info as info ON employee.employee_id = info.employee_fk SET employee.emplo_fname='$fname',employee.emplo_mname='$mname',employee.emplo_lname='$lname',info.with_load ='$load' WHERE employee.employee_id = $id";

		if (mysqli_query($conn,$sql) === TRUE) {
			echo 1;
		}
	}

?>