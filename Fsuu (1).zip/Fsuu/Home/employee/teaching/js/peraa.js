$(document).ready(function(event){

	load_data_peraa();

	setInterval(function(){
		load_data_peraa();
	},2000);


    $('#print').click(function(event){
        // alert("PATYA NALANG KO ");

        var id = $(this).attr('value');

        $.ajax({
            url: "function/search",
            type: "POST",
            data: {
                "search_data" : true,
                id:id,
            },
            success:function(response){
                if (response == "Yes") {
                    window.location = "teaching-print"
                }
                else{
                    
                }
            }
        });
    })

});


function load_data_peraa(){
	$.ajax({
		url: "function/peraa_load",
		cache: false,

		success:function(response){
			$('td').remove();
			if (response == 2) {

			}
			else{
				$.each(response,function(index,val){

                    if (val['registrar'] == 1 && val['library'] == 1 && val['pmo'] == 1 && val['bookstore']  == 1 && val['ITSD'] == 1 && val['Comptroller'] == 1 && val['Guidance'] == 1 && val['Graduate_Studies'] == 1 && val['HRMD'] == 1 && val['vp_asa'] == 1 && val['president'] == 1) {
                        $('.btn-hide').addClass('show');
                    }
                    else{
                        $('.btn-hide').removeClass('show');
                    }

                    // status
					  var regis = val['registrar']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['registrar'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : val['registrar'] == 3 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Approve W/ INC</span>" :"<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var library = val['library']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['library'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var pmo = val['pmo']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['pmo'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var bookstore = val['bookstore']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['bookstore'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var itsd = val['ITSD']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['ITSD'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var comproller = val['Comptroller']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['Comptroller'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var guidance = val['Guidance']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['Guidance'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var graduate = val['Graduate_Studies']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['Graduate_Studies'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var hrmd = val['HRMD']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['HRMD'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var vp_asa = val['vp_asa']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['vp_asa'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var President = val['president']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['president'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";

                     //requirements button
                    


                $('.peraa_data').append('<tr class="text-center">'+
                            '<td>Registrar Office</td>'+
                            '<td>'+regis+'</td>'+
                        '</tr>'+
                        '<tr class="text-center">'+
                            '<td>College Librarian</td>'+
                          
                            
                            '<td>'+library+'</td>'+
                        '</tr>'+
                        '<tr class="text-center">'+
                            '<td>Property and Maintenance Office</td>'+
                       
                            
                            '<td>'+pmo+'</td>'+
                        '</tr>'+
                        '<tr class="text-center">'+
                            '<td>Bookstore/Auxilliary Resource Services</td>'+
                         
                            
                            '<td>'+bookstore+'</td>'+
                        '</tr>'+
                        '<tr class="text-center">'+
                            '<td>ITSD</td>'+
                            
                            
                            '<td>'+itsd+'</td>'+
                        '</tr>'+
                        '<tr class="text-center">'+
                            '<td>Comptroller</td>'+
                          
                            
                            '<td>'+comproller+'</td>'+
                        '</tr>'+
                        '<tr class="text-center">'+
                            '<td>Guidance Office</td>'+
                          
                            
                            '<td>'+guidance+'</td>'+
                        '</tr>'+
                        '<tr class="text-center">'+
                            '<td>Graduate Studies and Research</td>'+
                            
                            
                            '<td>'+graduate+'</td>'+
                        '</tr>'+
                        '<tr class="text-center">'+
                            '<td>HRMD (Director)</td>'+
                            
                           
                            '<td>'+hrmd+'</td>'+
                        '</tr>'+
                        '<tr class="text-center">'+
                            '<td>Administrative Student Affairs (VP-ASA)</td>'+
                       
                            
                            '<td>'+vp_asa+'</td>'+
                        '</tr>'+
                        '<tr class="text-center">'+
                            '<td>University President</td>'+
                            '<td>'+President+'</td>'+
                        '</tr>');
					
				});
			}
		}
	});

    
}