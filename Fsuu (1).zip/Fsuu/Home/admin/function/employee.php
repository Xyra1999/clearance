<?php  

	if (isset($_POST['import_emplo'])) {
		$filename = $_FILES['employee_file']['tmp_name'];

		$sy = $_SESSION['sy'];
		$sem = $_SESSION['sem'];

		if ($_FILES['employee_file']['size'] > 0) {
			$file = fopen($filename, 'r');


			while (($row = fgetcsv($file,10000,",")) !== FALSE) {
			    $idnumber = $row[0];
			    $email = $row[1];
			    $deparment = $row[2];
			    $status = $row[3];
			    $employee_type = $row[4];
			    $date_employe = $row[5];
			    // echo $count;
			    Search($idnumber,$email,$deparment,$status,$employee_type,$date_employe,$sy);
			}
			fclose($file);
		}
	}

?>

<?php  
	
	function Search($idnumber,$email,$deparment,$status,$employee_type,$date_employe,$sy){

		require "../../connector/connect.php";

		$search = "SELECT *FROM account_type WHERE email = '$email'";

		$result = mysqli_query($conn,$search);

		if (mysqli_num_rows($result) > 0) {	
		}
		else{
			Insert($idnumber,$email,$deparment,$status,$employee_type,$date_employe,$sy);
		}
	}
?>

<?php  
	
	function Insert($idnumber,$email,$deparment,$status,$employee_type,$date_employe,$sy){
		require "../../connector/connect.php";

		$insert_type = "INSERT INTO account_type(email,type) VALUES ('$email','employee')";
	    if (mysqli_query($conn,$insert_type) === TRUE) {
	    	$last_id = mysqli_insert_id($conn);
	    	$insert = "INSERT INTO tbl_employee(emplo_fname,emplo_mname,emplo_lname,emplo_idnumber,emplo_school_year,emplo_account_fk) VALUES ('','','','$idnumber','$sy',$last_id)";
	    	if (mysqli_query($conn,$insert) === TRUE) {
	    		$employee_insert = mysqli_insert_id($conn);
	    		$employee_info = "INSERT INTO tbl_employee_info(date_employed,employee_office,status,employee_type,with_load,employee_fk,emplo_info_account_fk) VALUES('$date_employe','$deparment','$status','$employee_type','',$employee_insert,$last_id)";
	    		if (mysqli_query($conn,$employee_info) === TRUE) {
	    			echo "<script> 
	    			alert('Uploaded')  
	    			window.location='import';
	    		</script>";
	    		}
	    	}
	    }
	}

?>