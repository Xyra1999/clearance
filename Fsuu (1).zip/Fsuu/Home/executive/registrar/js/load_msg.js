$(document).ready(function(event) {
	

	$('#message-modal').click(function(event) {
         $('.message').toggleClass('show');
         $('body').toggleClass('off');
     });


	$(document).on('click', '.message-list', function(event) {
		event.preventDefault();

		var id = $(this).closest('li').find('#btn').text();
		var applicant_email = $('.applicant_email').text();
		var employee_id = $('#employee_approved').prop('value');
		var status = $('#status_info').prop('value');

		// $('.applicant_email').removeClass('fw-bold');

		// console.log(da);
		$.ajax({
			url: "function/search",
			type: "POST",
			data: {
				"search" : true,
				id:id,
			},
			success:function(response){
				$('.message').removeClass('show')
				$('body').removeClass('off')
				if (response == 2) {

				}
				else{
					$.each(response, function(index, val) {
						$('.modal_box').addClass('bg-active');
						$('#applicant_reply').text(val['reply_msg']);
						$('#msg').text(val['text_msg']);
						$('#employee_send').attr('value',val['office_fk']);
						$('#convo_id').prop('value',val['employee_msg_id']);
						$('#approved_msg').prop('value',status);
						$('#applicant_email').prop('value',applicant_email);
					});
				}
			}
		});
	});

	load_msg();


	setInterval(function(){
		load_msg();
	},2000)



});


function load_msg(view=""){
	$.ajax({
		url: "function/fetch",
		method: "POST",
		data:{
			view:view,
		},
		dataType: "json",
		success:function(data){
			
			$('.data-msg').html(data.notification);
			if (data.unseen_notification > 0) {
				$('.count').html(data.unseen_notification);
			}
			else{
				$('.count').html("");
			}
		}
	});
}