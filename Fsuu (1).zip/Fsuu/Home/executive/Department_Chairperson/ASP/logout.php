<?php   
	session_start();
	unset($_SESSION['chair_asp']); 
	header("location: ../../../../index"); 
	exit();
?>