<?php   
	session_start();
	unset($_SESSION['comptroller']); 
	header("location: ../../../index"); 
	exit();
?>