<?php  


	require "../../../../connector/connect.php";

	if (isset($_POST['search'])) {
		$id = mysqli_real_escape_string($conn,$_POST['id']);


		$update = "UPDATE tbl_employee_msg SET status = 1 WHERE employee_msg_id = $id";

		if (mysqli_query($conn,$update) === TRUE) {
			$sql = "SELECT *FROM tbl_employee_msg WHERE employee_msg_id = $id";

			$result_val = [];
			$result_q = mysqli_query($conn,$sql);
			if (mysqli_num_rows($result_q) > 0) {
				foreach ($result_q as $value) {
				    array_push($result_val,$value);
				    // break;

				}
				header("Content-type: application/json");
				echo json_encode($result_val);

			}
			else{
				echo 2;
			}
		}
	}
	else if (isset($_POST['search_data'])) {
		$id = mysqli_real_escape_string($conn,$_POST['id']);

		$search = "SELECT *FROM tbl_employee_status WHERE tbl_employee_id = $id";

		$result_val = [];
		$result_q = mysqli_query($conn,$search);
		if (mysqli_num_rows($result_q) > 0) {
			foreach ($result_q as $value) {
			    array_push($result_val,$value);
			}
			header("Content-type: application/json");
			echo json_encode($result_val);

		}
		else{
			echo 2;
		}

	}

	else if (isset($_POST['student_search'])) {
		# code...
		$id = mysqli_real_escape_string($conn,$_POST['id']);

		$search = "SELECT *FROM tbl_student_status WHERE student_info_id = $id";

		$result_val = [];
		$result_q = mysqli_query($conn,$search);
		if (mysqli_num_rows($result_q) > 0) {
			foreach ($result_q as $value) {
			    array_push($result_val,$value);
			}
			header("Content-type: application/json");
			echo json_encode($result_val);

		}
		else{
			echo 2;
		}

	}

?>