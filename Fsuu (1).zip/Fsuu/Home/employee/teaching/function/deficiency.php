
<?php  

	require "../../../../connector/connect.php";

	session_start();



	$request = $_REQUEST;

	$col = array(
		0	=>	'tbl_library_defiency_id',
		1	=>	'idnumber',
		2	=>	'office_name',
		3	=>	'purpose',
		4	=>	'tbl_library_defiency_id',
	);

	$sql = "SELECT *from tbl_defiency_employee";

	$query = mysqli_query($conn,$sql);

	$totalData = mysqli_num_rows($query);

	$filter = $totalData;

	$sql ="SELECT *from tbl_defiency_employee WHERE 1=1";
	if(!empty($request['search']['value'])){
	    $sql.=" AND (tbl_library_defiency_id Like '".$request['search']['value']."%' ";
	    $sql.=" OR idnumber Like '".$request['search']['value']."%' ";
	    $sql.=" OR office_name Like '".$request['search']['value']."%' ";
	    $sql.=" OR purpose Like '".$request['search']['value']."%' ";
	    $sql.=" OR tbl_library_defiency_id Like '".$request['search']['value']."%' )";
	}

	$query = mysqli_query($conn,$sql);
	$totalData = mysqli_num_rows($query);

	$sql.=" ORDER BY ".$col[$request['order'][0]['column']]."   ".$request['order'][0]['dir']."  LIMIT ".
    $request['start']."  ,".$request['length']."  ";

	$query = mysqli_query($conn,$sql);
	$data = array();

	while ($row = mysqli_fetch_array($query)) {

		$btn = "<button class='btn btn-sm btn-outline btn-secondary' value='".$row[0]."' id='btn_deficiency'>Deficiency</button>";

		$office = "<span id='o_name'>".$row[1]."</span>";

	    $subdata = array();
	    $subdata[] = $row[0];
	     $subdata[] = $row[2];
	    $subdata[] = "$office";
	    $subdata[] = $row[3];
	    $subdata[] = "$btn";
	    $data[] = $subdata;
	}

	$json_data=array(
	    "draw"              =>  intval($request['draw']),
	    "recordsTotal"      =>  intval($totalData),
	    "recordsFiltered"   =>  intval($filter),
	    "data"              =>  $data
	);

	echo json_encode($json_data);

?>