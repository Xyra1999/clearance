<?php  

	require "../../../../../connector/connect.php";

	if (isset($_POST['employee_update'])) {

		$id = mysqli_real_escape_string($conn,$_POST['id']);
		
		$sql = "UPDATE tbl_employee_status SET Department_chair = 1 WHERE tbl_employee_id = $id";

		if (mysqli_query($conn,$sql) === TRUE) {

			$sql_find = "SELECT *FROM tbl_employee_status WHERE tbl_employee_id =$id";

			$result = mysqli_query($conn,$sql_find);

			if (mysqli_num_rows($result) > 0) {
				while ($row = mysqli_fetch_assoc($result)) {
				    $emplo_fk = $row['tbl_employee_account_fk'];
				    break;
				}
			}

			$sql_get_id = "SELECT *FROM tbl_employee WHERE emplo_account_fk = $emplo_fk";

			$result_id = mysqli_query($conn,$sql_get_id);

			if (mysqli_num_rows($result_id) > 0) {
				while ($row = mysqli_fetch_assoc($result_id)) {
				    $idnumber = $row['emplo_idnumber'];
				    break;
				}
			}

			$logs = $idnumber." "."Has been approved";

			$logs_remark = "INSERT INTO tbl_log_dean(remark,type,department_name,date_log) VALUES ('$logs','Department Chairperson','Criminology Program',NOW())";

			if (mysqli_query($conn,$logs_remark) === TRUE) {
				echo 1;	
			}		
		}
	}
	else if (isset($_POST['undo_employee'])) {
		$id = mysqli_real_escape_string($conn,$_POST['id']);
		
		$sql = "UPDATE tbl_employee_status SET Department_chair = 0 WHERE tbl_employee_id = $id";

		if (mysqli_query($conn,$sql) === TRUE) {
			$sql_find = "SELECT *FROM tbl_employee_status WHERE tbl_employee_id =$id";

			$result = mysqli_query($conn,$sql_find);

			if (mysqli_num_rows($result) > 0) {
				while ($row = mysqli_fetch_assoc($result)) {
				    $emplo_fk = $row['tbl_employee_account_fk'];
				    break;
				}
			}

			$sql_get_id = "SELECT *FROM tbl_employee WHERE emplo_account_fk = $emplo_fk";

			$result_id = mysqli_query($conn,$sql_get_id);

			if (mysqli_num_rows($result_id) > 0) {
				while ($row = mysqli_fetch_assoc($result_id)) {
				    $idnumber = $row['emplo_idnumber'];
				    break;
				}
			}

			$logs = $idnumber." "."Change Status";

			$logs_remark = "INSERT INTO tbl_log_dean(remark,type,department_name,date_log) VALUES ('$logs','Department Chairperson','Criminology Program',NOW())";

			if (mysqli_query($conn,$logs_remark) === TRUE) {
				echo 1;	
			}		
		}
	}
	else if (isset($_POST['student_search'])) {
		$id = mysqli_real_escape_string($conn,$_POST['id']);



		$search = "SELECT *FROM tbl_student_status WHERE student_info_id = $id";

		$result_val = [];
		$result_q = mysqli_query($conn,$search);
		if (mysqli_num_rows($result_q) > 0) {
			foreach ($result_q as $value) {
			    array_push($result_val,$value);
			}
			header("Content-type: application/json");
			echo json_encode($result_val);

		}
		else{
			echo 2;
		}
	}
	else if (isset($_POST['update_status'])) {
		$id = mysqli_real_escape_string($conn,$_POST['id']);

		$sql = "UPDATE tbl_student_status SET Department_chair = 1 WHERE student_info_id = $id";

		if (mysqli_query($conn,$sql) === TRUE) {
			echo 1;
		}
	}
	else if (isset($_POST['undo_student'])) {
		$id = mysqli_real_escape_string($conn,$_POST['id']);

		$sql = "UPDATE tbl_student_status SET Department_chair = 0 WHERE student_info_id = $id";

		if (mysqli_query($conn,$sql) === TRUE) {
			echo 1;
		}
	}

?>