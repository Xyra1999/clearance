$(document).ready(function() {
    $('#example').DataTable();
    responsive: true


});

