<?php  
	
	session_start();

	$office_id = $_SESSION['office_id'];
	$office_name = $_SESSION['office_name'];

	if (isset($_POST['import'])) {
		$filename = $_FILES['bookstore_csv']['tmp_name'];

		// $sy = $_SESSION['sy'];
		// $sem - $_SESSION['sem'];

		if ($_FILES['bookstore_csv']['size'] > 0) {
			$file = fopen($filename, 'r');


			while (($row = fgetcsv($file,10000,",")) !== FALSE) {
			    $email = $row[0];
			    $purpose = $row[1];
			    $books = $row[2];
			    // echo $count;
			    Search_data($email,$purpose,$books,$office_id,$office_name);
			}
			fclose($file);
		}
	}

?>

<?php  


	function Search_data($email,$purpose,$books,$office_id,$office_name){
		
		require "../../../../connector/connect.php";

		$sql = "SELECT *FROM account_type WHERE email = '$email'";

		$result = mysqli_query($conn,$sql);
		if (mysqli_num_rows($result) > 0 ) {
			while ($row = mysqli_fetch_assoc($result)) {
			    $id = $row['account_info_id'];
			    Uniq_id($id,$email,$purpose,$books,$office_id,$office_name);
			}
		}
		else{

		}
	}

?>

<?php  

	function Uniq_id($id,$email,$purpose,$books,$office_id,$office_name){

		require "../../../../connector/connect.php";

		$sql = "SELECT *FROM account_type as account JOIN tbl_employee_status as status ON account.account_info_id = status.tbl_employee_account_fk JOIN tbl_employee as employee ON account.account_info_id = employee.emplo_account_fk WHERE account.account_info_id = $id AND status.purpose ='$purpose'";

		$result_find = mysqli_query($conn,$sql);

		while ($row = mysqli_fetch_assoc($result_find)) {
		    $id_uniq = $row['tbl_employee_id'];
		    $email = $row['email'];
		    $idnum = $row['emplo_idnumber'];
		    Logs_history($id_uniq,$purpose,$idnum,$books,$id,$office_name,$office_id);
		}
	}

?>

<?php  


	function Logs_history($id_uniq,$purpose,$idnum,$books,$id,$office_name,$office_id){

		require "../../../../connector/connect.php";

		$execute = empty($books) ? "UPDATE tbl_employee_status SET bookstore = 1 WHERE tbl_employee_id = $id_uniq" : "UPDATE tbl_employee_status SET bookstore = 2 WHERE tbl_employee_id = $id_uniq";

		$sql_stored = empty($books) ? "" : "INSERT INTO tbl_defiency_employee(office_name,idnumber,purpose,book,library_account_fk,office_fk,status_employee_fk) VALUES ('$office_name','$idnum','$purpose','$books',$id,$office_id,$id_uniq)";

			if (mysqli_query($conn,$execute) === TRUE) {
				if (mysqli_query($conn,$sql_stored) === TRUE) {
					$logs_approve = $idnum." "."Sent a notification";

					$sql_log = "INSERT INTO tbl_library_log(remark,purpose,idnumber,date_log) VALUES ('$logs_approve','$purpose','$idnum',NOW())";

					if (mysqli_query($conn,$sql_log) === TRUE) {
						echo "<script> 
			    			alert('Uploaded')  
			    			window.location='../import';
			    		</script>";
					}	
				}
			}
		
	}

?>