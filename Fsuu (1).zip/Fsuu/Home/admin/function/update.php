<?php  

	
	require "../../../connector/connect.php";

	if (isset($_POST['delete_office'])) {
		
		$id = mysqli_real_escape_string($conn,$_POST['id']);

		$sql = "DELETE FROM tbl_office_name WHERE office_name_id = $id";

		if (mysqli_query($conn,$sql) === TRUE) {
			echo 1;
		}
	}
	else if (isset($_POST['add-office'])) {
		$id = mysqli_real_escape_string($conn,$_POST['id']);
		$email = mysqli_real_escape_string($conn,$_POST['email']);
		$idnum = mysqli_real_escape_string($conn,$_POST['idnum']);
		$office_name = mysqli_real_escape_string($conn,$_POST['office_name']);
		

		$search = "SELECT email FROM account_type WHERE email = '$email'";

		$result = mysqli_query($conn,$search);


		if (mysqli_num_rows($result) > 0) {
			echo 2;
		}
		else{
			$insert_data = "INSERT INTO account_type(email,type) VALUES('$email','Office Head')";
			if (mysqli_query($conn,$insert_data) === TRUE) {
				$last_id = mysqli_insert_id($conn);
				$data = "INSERT INTO office_head(office_fname,office_lname,office_assign,date_registered,account_fk,department_fk,office_name_fk) VALUES('','','$office_name',NOW(),$last_id,null,$id)";

				if (mysqli_query($conn,$data) == TRUE) {
					echo 1;
				}
			}
			else{
				echo 3;
			}
		}
	}
	else if (isset($_POST['update_info'])) {
		$id = mysqli_real_escape_string($conn,$_POST['id']);
		$email = mysqli_real_escape_string($conn,$_POST['email']);
		$fname = mysqli_real_escape_string($conn,$_POST['fname']);
		$lname = mysqli_real_escape_string($conn,$_POST['lname']);

		$sql = "UPDATE account_type as account JOIN office_head as head ON account.account_info_id = head.account_fk SET account.email ='$email',head.office_fname='$fname',head.office_lname='$lname' WHERE account.account_info_id = $id";

		if (mysqli_query($conn,$sql) === TRUE) {
			
			echo 1;
		}
	}
	else if (isset($_POST['remove_account_data'])) {
		$id = mysqli_real_escape_string($conn,$_POST['id']);
		
		// echo $id;

		$sql = "DELETE FROM office_head WHERE account_fk = $id";
		if (mysqli_query($conn,$sql) === TRUE) {
			
			$sql_d = "DELETE FROM account_type WHERE account_info_id = $id";

			if (mysqli_query($conn,$sql_d) === TRUE) {
				echo 1;
			}
		}
	}
	else if (isset($_POST['transfer_data'])) {
		$id = mysqli_real_escape_string($conn,$_POST['id']);
		$office_fk = mysqli_real_escape_string($conn,$_POST['office_id']);

		$sql = "UPDATE office_head SET office_name_fk =$office_fk WHERE account_fk = $id";


		if (mysqli_query($conn,$sql) === TRUE) {
			echo 1;
		}
	}

?>