$(document).ready(function(event){

	load_data_peraa();

	setInterval(function(){
		load_data_peraa();
	},2000);


     $('#print').click(function(event){
        // alert("PATYA NALANG KO ");

        var id = $(this).attr('value');

        $.ajax({
            url: "function/search",
            type: "POST",
            data: {
                "search_data" : true,
                id:id,
            },
            success:function(response){
                if (response == "Yes") {
                    window.location = "teaching-print"
                }
                else{
                    
                }
            }
        });
    })

});


function load_data_peraa(){

	$.ajax({
		url: "function/separation_load",
		cache: false,

		success:function(response){
			$('td').remove();
			if (response == 2) {

			}
			else{
				$.each(response,function(index,val){

                    if (val['registrar'] == 1 && val['library'] == 1 && val['pmo'] == 1 && val['bookstore']  == 1 && val['ITSD'] == 1 && val['Comptroller'] == 1 && val['program_dean'] == 1 && val['asp_dean'] == 1 && val['HRMD'] == 1 && val['vp_aar'] == 1 && val['Cashier'] == 1) {
                        $('.btn-hide').addClass('show');
                     }
                    else{
                        $('.btn-hide').removeClass('show');
                    }


					 var regis = val['registrar']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['registrar'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : val['registrar'] == 3 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Approve W/ INC</span>" :"<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var library = val['library']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var pmo = val['pmo']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var bookstore = val['bookstore']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var itsd = val['ITSD']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var comproller = val['Comptroller']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var program_dean = val['program_dean']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var arts = val['asp_dean']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var hrmd = val['HRMD']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var vp_aar = val['vp_aar']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var Cashier = val['Cashier']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                $('.separation').append('<tr class="text-center">'+
                            '<td>Registrar Office</td>'+
                            

                            '<td>'+regis+'</td>'+
                        '</tr>'+
                        '<tr class="text-center">'+
                            '<td>College Librarian</td>'+
                           
                            '<td>'+library+'</td>'+
                        '</tr>'+
                        '<tr class="text-center">'+
                            '<td>Property and Maintenance Office</td>'+
                         
                            '<td>'+pmo+'</td>'+
                        '</tr>'+
                        '<tr class="text-center">'+
                            '<td>Bookstore/Auxilliary Resource Services</td>'+
                           
                            '<td>'+bookstore+'</td>'+
                        '</tr>'+
                        '<tr class="text-center">'+
                            '<td>ITSD</td>'+
                           
                            '<td>'+itsd+'</td>'+
                        '</tr>'+
                        '<tr class="text-center">'+
                            '<td>Comptroller</td>'+
                            
                            '<td>'+comproller+'</td>'+
                        '</tr>'+
                        '<tr class="text-center">'+
                            '<td>Program Dean</td>'+
                           
                            '<td>'+program_dean+'</td>'+
                        '</tr>'+
                        '<tr class="text-center">'+
                            '<td>Dean Art and Science</td>'+
                     
                            '<td>'+arts+'</td>'+
                        '</tr>'+
                        '<tr class="text-center">'+
                            '<td>Cashier</td>'+
               
                            '<td>'+Cashier+'</td>'+
                        '</tr>'+
                        '<tr class="text-center">'+
                            '<td>HRMD (Director)</td>'+
                            
                            '<td>'+hrmd+'</td>'+
                        '</tr>'+
                        '<tr class="text-center">'+
                            '<td>Academic Affairs and Research (VP-AAR)</td>'+
                            
                            '<td>'+vp_aar+'</td>'+
                        '</tr>');
					
				});
			}
		}
	});
}