<?php  

	require "../../../../connector/connect.php";


	$request = $_REQUEST;

	$col = array(
		0	=>	'student_info_id',
		1	=>	'fname',
		2	=>	'idnumber',
		3	=>	'email',
		4	=>	'student_info_id',
	);

	$sql = "SELECT stats.student_info_id,account.email,student.idnumber,student.fname,student.mname,student.lname FROM tbl_student_status as stats JOIN account_type as account ON stats.tbl_account_fk = account.account_info_id JOIN tbl_student as student ON student.account_student_fk = account.account_info_id WHERE stats.ces =0";

	$query = mysqli_query($conn,$sql);

	$totalData = mysqli_num_rows($query);

	$filter = $totalData;

	$sql ="SELECT stats.student_info_id,account.email,student.idnumber,student.fname,student.mname,student.lname FROM tbl_student_status as stats JOIN account_type as account ON stats.tbl_account_fk = account.account_info_id JOIN tbl_student as student ON student.account_student_fk = account.account_info_id WHERE 1=1 AND stats.ces=0 ";
	if(!empty($request['search']['value'])){
	    $sql.=" AND (account.email Like '".$request['search']['value']."%' ";
	    $sql.=" OR name Like '".$request['search']['value']."%' ";
	    $sql.=" OR fname Like '".$request['search']['value']."%' ";
	    $sql.=" OR email Like '".$request['search']['value']."%' ";
	    $sql.=" OR student_info_id Like '".$request['search']['value']."%' )";
	}

	$query = mysqli_query($conn,$sql);
	$totalData = mysqli_num_rows($query);

	$sql.=" ORDER BY ".$col[$request['order'][0]['column']]."   ".$request['order'][0]['dir']."  LIMIT ".
    $request['start']."  ,".$request['length']."  ";

	$query = mysqli_query($conn,$sql);

	$data = array();

	while ($row = mysqli_fetch_array($query)) {
	    $subdata = array();
	    $subdata[] = $row[0];
	    $subdata[] = $row[3]." ".$row[4]." ".$row[5];
	   
	    $subdata[] = $row[2];
	    $subdata[] = $row[1];
	    $subdata[] = "<button class='btn btn-sm btn-primary' value='".$row[0]."' id='view'>View</button>
	    	<button class='btn btn-sm btn-success' value='".$row[0]."' id='approve'>Approved</button>
	    ";
	    $data[] = $subdata;
	}

	$json_data=array(
	    "draw"              =>  intval($request['draw']),
	    "recordsTotal"      =>  intval($totalData),
	    "recordsFiltered"   =>  intval($filter),
	    "data"              =>  $data
	);

	echo json_encode($json_data);

?>