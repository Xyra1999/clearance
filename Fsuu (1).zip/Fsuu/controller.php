<?php
// require_once "core/function.php";
require_once 'connector/connect.php';
require_once "connector/config.php";

if (isset($_GET['code'])) {
    $token = $google_client->fetchAccessTokenWithAuthCode($_GET['code']);
}
else{
    header('Location: index');
    exit();
}
    if(isset($token["error"]) != "invalid_grant"){
    
        $google_client->setAccessToken($token['access_token']);

        $_SESSION['access_token'] = $token['access_token'];

        $oAuth = new Google_Service_Oauth2($google_client);
        $userData = $oAuth->userinfo_v2_me->get();

        session_start();
        // $_SESSION['google_email'] = $userData['email'];

        $fname = mysqli_real_escape_string($conn,$userData->givenName);
        $lname = mysqli_real_escape_string($conn,$userData->family_name);
        $email = mysqli_real_escape_string($conn,$userData->email);

        $pic = mysqli_real_escape_string($conn,$userData->picture);

        $mname = "";
        $contact = "";
        $hash = "";

        $find = "SELECT *from account_type WHERE email ='$email'";

        $result = mysqli_query($conn,$find);

        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                $u_email = $row['email'];
                $type = $row['type'];
                Account_type($u_email,$type,$fname,$lname);
                break;
            }
        }
        else{
            header("location: index?UserNotFound");
            exit();
        }
   
    }
?>


<?php  

    function Account_type($u_email,$type,$fname,$lname){

        require 'connector/connect.php';
        if ($type == "admin") {
            $sql = "SELECT *FROM account_type WHERE email ='$u_email'";

            $result = mysqli_query($conn,$sql);
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    $use_email = $row['email'];
                    session_start();
                    $_SESSION['admin'] = $use_email;
                    header("location: Home/admin");
                    exit();
                }
            }
        }
        else if ($type == "student") {
            $sql = "SELECT *FROM account_type WHERE email ='$u_email' AND status =0";

            $result = mysqli_query($conn,$sql);
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    $use_email = $row['email'];
                    $id = $row['account_info_id'];
                    Student_Data($use_email,$id,$fname,$lname);
                    break;
                }
            }
            else{
                session_start();
                $_SESSION['student'] = $u_email;
                header("location: Home/student");
                exit();
            }
        }
        else if ($type == "Office Head") {

            $sql = "SELECT *FROM account_type WHERE email ='$u_email' AND status = 0";

            $result = mysqli_query($conn,$sql);
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    $use_email = $row['email'];
                    $id = $row['account_info_id'];
                    Office_head($use_email,$id,$fname,$lname);
                    break;
                }
            }
            else{
                $sql = "SELECT *FROM account_type WHERE email ='$u_email'";
                $result_search = mysqli_query($conn,$sql);

                while ($row = mysqli_fetch_assoc($result_search)){
                    $use_email = $row['email'];
                    $id = $row['account_info_id'];

                    Updated_office_account($use_email,$id); 
                    break;
                }
            }
        }
        else if($type == "employee"){

            // echo $u_email;

            $sql = "SELECT *FROM account_type WHERE email ='$u_email' AND status = 0";
            $result = mysqli_query($conn,$sql);
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    $use_email = $row['email'];
                    $use_id = $row['account_info_id'];
                    search_employee($use_email,$use_id,$fname,$lname);
                    break;
                }
            }
            else{

                $sql = "SELECT *FROM account_type WHERE email = '$u_email'";
                $result_q = mysqli_query($conn,$sql);
                while ($row = mysqli_fetch_assoc($result_q)) {
                    $id = $row['account_info_id'];
                    Identify_employee($u_email,$fname,$lname,$id);
                    break;
                }
            }
        }
    }
?>


<?php  

    function Updated_office_account($use_email,$id){

        require 'connector/connect.php';

        $sql = "SELECT *FROM account_type as account JOIN office_head as office ON account.account_info_id = office.account_fk WHERE office.account_fk = $id";

        $result_q = mysqli_query($conn,$sql);

        while ($row = mysqli_fetch_assoc($result_q)) {
            $dept_fk = $row['department_fk'];
            if ($row['office_assign'] == "Admission") {
                session_start();
                $_SESSION['adminssion'] = $use_email;
                header("location: Home/Office/Admission");
                exit();
            }
            else if ($row['office_assign'] == "CES_office") {
                session_start();
                $_SESSION['ces'] = $use_email;
                header("location: Home/Office/Ces_Office");
                exit();
            }
            else if ($row['office_assign'] == "Guidance_office") {
                session_start();
                $_SESSION['guidance'] = $use_email;
                header("location: Home/Office/Guidance");
                exit();
            }
            else if ($row['office_assign'] == "ORA") {
                session_start();
                $_SESSION['ora'] = $use_email;
                header("location: Home/Office/ORA");
                exit();
            }
            else if ($row['office_assign'] == "DSA_office") {
                session_start();
                $_SESSION['dsa'] = $use_email;
                header("location: Home/Office/DSA");
                exit();
            }
            else if ($row['office_assign'] == "Veritas") {
                session_start();
                $_SESSION['veritas'] = $use_email;
                header("location: Home/Office/Veritas");
                exit();
            }
            else if ($row['office_assign'] == "DAO") {
                session_start();
                $_SESSION['dao'] = $use_email;
                header("location: Home/Office/DAO");
                exit();
            }
            else if ($row['office_assign'] == "Cashier") {
                session_start();
                $_SESSION['cashier'] = $use_email;
                header("location: Home/Office/Cashier");
                exit();
            }
            else if ($row['office_assign'] == "Program_dean") {
                // Program Dean
                $sql_find = "SELECT *FROM office_head as head JOIN tbl_department as dept ON head.department_fk = dept.department_id WHERE head.department_fk = $dept_fk";

                $result_dept = mysqli_query($conn,$sql_find);

                while ($row  = mysqli_fetch_assoc($result_dept)) {
                    
                    if($row['department_name'] == "Nursing Program"){
                        session_start();
                        $_SESSION['nursing'] = $use_email;
                        header("location: Home/executive/Program_Dean/NP");
                        exit();
                    }
                    else if ($row['department_name'] == "Business Administration Program") {
                        session_start();
                        $_SESSION['bap'] = $use_email;
                        header("location: Home/executive/Program_Dean/BAP");
                        exit();
                    }
                    else if ($row['department_name'] == "Computer Studies Program") {
                        session_start();
                        $_SESSION['csp'] = $use_email;
                        header("location: Home/executive/Program_Dean/CSP");
                        exit();
                    } 
                    else if ($row['department_name'] == "Arts And Science Program") {
                        session_start();
                        $_SESSION['asp'] = $use_email;
                        header("location: Home/executive/Program_Dean/ASP");
                        exit();
                    } 
                    else if ($row['department_name'] == "Accountancy Program") {
                        session_start();
                        $_SESSION['ap'] = $use_email;
                        header("location: Home/executive/Program_Dean/AP");
                        exit();
                    } 
                    else if ($row['department_name'] == "College of Law Program") {
                        session_start();
                        $_SESSION['law'] = $use_email;
                        header("location: Home/executive/Program_Dean/College_Law");
                        exit();
                    } 
                    else if ($row['department_name'] == "Engineering and Technology Program") {
                        session_start();
                        $_SESSION['etp'] = $use_email;
                        header("location: Home/executive/Program_Dean/ETP");
                        exit();
                    }
                    else if ($row['department_name'] == "Teachers Education Program") {
                        session_start();
                        $_SESSION['tep'] = $use_email;
                        header("location: Home/executive/Program_Dean/TEP");
                        exit();
                    }
                    else{
                        session_start();
                        $_SESSION['cjep'] = $use_email;
                        header("location: Home/executive/Program_Dean/CJEP");
                        exit();
                    }

                }
            }
            else if ($row['office_assign'] == "Records_incharge") {
                session_start();
                $_SESSION['record'] = $use_email;
                header("location: Home/Office/Record");
                exit();
            }
            else if ($row['office_assign'] == "Registrars_office") {
                session_start();
                $_SESSION['registrar'] = $use_email;
                header("location: Home/executive/registrar");
                exit();
            }
            else if ($row['office_assign'] == "College-librarian") {
                session_start();
                $_SESSION['library'] = $use_email;
                header("location: Home/Office/library");
                exit();
            }
            else if ($row['office_assign'] == "PMO") {
                session_start();
                $_SESSION['pmo'] = $use_email;
                header("location: Home/Office/PMO");
                exit();
            }
            else if ($row['office_assign'] == "Bookstore") {
                session_start();
                $_SESSION['bookstore'] = $use_email;
                header("location: Home/Office/Bookstore");
                exit();
            }
            else if ($row['office_assign'] == "ITSD") {
                session_start();
                $_SESSION['itsd'] = $use_email;
                header("location: Home/Office/ITSD");
                exit();
            }
            else if ($row['office_assign'] == "Graduate_studies") {
                session_start();
                $_SESSION['studies'] = $use_email;
                header("location: Home/Office/Graduates");
                exit();
            }
            else if ($row['office_assign'] == "HRMD") {
                session_start();
                $_SESSION['hrmd'] = $use_email;
                header("location: Home/executive/HRMD_Head");
                exit();
            }
            else if ($row['office_assign'] == "VP_ASA") {
                session_start();
                $_SESSION['vp_asa'] = $use_email;
                header("location: Home/executive/VP_Asa");
                exit();
            }
            else if ($row['office_assign'] == "University_president") {
                session_start();
                $_SESSION['president'] = $use_email;
                header("location: Home/executive/President");
                exit();
            }
            else if ($row['office_assign'] == "Comptroller") {
                session_start();
                $_SESSION['comptroller'] = $use_email;
                header("location: Home/Office/Comptroller");
                exit();
            }
            else if ($row['office_assign'] == "VP_AAR") {
                session_start();
                $_SESSION['vp_arr'] = $use_email;
                header("location: Home/executive/VP_Arr");
                exit();
            }
            else{
                // Department Chairperson
                // session_start();
                // $_SESSION['chairperson'] = $use_email;
                // header("location: Home/executive/Department_Chairperson");
                // exit();

                $sql_find = "SELECT *FROM office_head as head JOIN tbl_department as dept ON head.department_fk = dept.department_id WHERE head.department_fk = $dept_fk";

                $result_dept = mysqli_query($conn,$sql_find);

                while ($row  = mysqli_fetch_assoc($result_dept)) {
                    
                    if($row['department_name'] == "Nursing Program"){
                        session_start();
                        $_SESSION['chair_nursing'] = $use_email;
                        header("location: Home/executive/Department_Chairperson/NP");
                        exit();
                    }
                    else if ($row['department_name'] == "Business Administration Program") {
                        session_start();
                        $_SESSION['chair_bap'] = $use_email;
                        header("location: Home/executive/Department_Chairperson/BAP");
                        exit();
                    }
                    else if ($row['department_name'] == "Computer Studies Program") {
                        session_start();
                        $_SESSION['chair_csp'] = $use_email;
                        header("location: Home/executive/Department_Chairperson/CSP");
                        exit();
                    } 
                    else if ($row['department_name'] == "Arts And Science Program") {
                        session_start();
                        $_SESSION['chair_asp'] = $use_email;
                        header("location: Home/executive/Department_Chairperson/ASP");
                        exit();
                    } 
                    else if ($row['department_name'] == "Accountancy Program") {
                        session_start();
                        $_SESSION['chair_ap'] = $use_email;
                        header("location: Home/executive/Department_Chairperson/AP");
                        exit();
                    } 
                    else if ($row['department_name'] == "College of Law Program") {
                        session_start();
                        $_SESSION['chair_law'] = $use_email;
                        header("location: Home/executive/Department_Chairperson/College_Law");
                        exit();
                    } 
                    else if ($row['department_name'] == "Engineering and Technology Program") {
                        session_start();
                        $_SESSION['chair_etp'] = $use_email;
                        header("location: Home/executive/Department_Chairperson/ETP");
                        exit();
                    }
                    else if ($row['department_name'] == "Teachers Education Program") {
                        session_start();
                        $_SESSION['chair_tep'] = $use_email;
                        header("location: Home/executive/Department_Chairperson/TEP");
                        exit();
                    }
                    else{
                        session_start();
                        $_SESSION['chair_cjep'] = $use_email;
                        header("location: Home/executive/Department_Chairperson/CJEP");
                        exit();
                    }
                }
            }

        }
    }

?>


<!-- Update Office Info When The user is logging in -->
<?php  

    function Office_head($use_email,$id,$fname,$lname){

        require 'connector/connect.php';

        $sql = "SELECT *FROM account_type as account JOIN office_head as office ON account.account_info_id = office.account_fk WHERE office.account_fk = $id";

        $result_find = mysqli_query($conn,$sql);
        while ($row = mysqli_fetch_assoc($result_find)) {
            $dept_fk = $row['department_fk'];
            if ($row['office_assign'] == "Admission") {
                $admission_update = "UPDATE office_head as head JOIN account_type as account ON head.account_fk = account.account_info_id SET head.office_fname='$fname',head.office_lname='$lname',account.status =1 WHERE head.account_fk = $id";
                if (mysqli_query($conn,$admission_update) === TRUE) {
                    # code...
                    session_start();
                    $_SESSION['adminssion'] = $use_email;
                    header("location: Home/Office/Admission");
                    exit();
                }
            }
            else if ($row['office_assign'] == "CES_office") {
                $admission_update = "UPDATE office_head as head JOIN account_type as account ON head.account_fk = account.account_info_id SET head.office_fname='$fname',head.office_lname='$lname',account.status =1 WHERE head.account_fk = $id";
                if (mysqli_query($conn,$admission_update) === TRUE) {
                    session_start();
                    $_SESSION['ces'] = $use_email;
                    header("location: Home/Office/Ces_Office");
                    exit();
                }
            }
            else if ($row['office_assign'] == "Guidance_office") {
                $admission_update = "UPDATE office_head as head JOIN account_type as account ON head.account_fk = account.account_info_id SET head.office_fname='$fname',head.office_lname='$lname',account.status =1 WHERE head.account_fk = $id";
                if (mysqli_query($conn,$admission_update) === TRUE) {
                    # code...
                    session_start();
                    $_SESSION['guidance'] = $use_email;
                    header("location: Home/Office/Guidance");
                    exit();
                }
            }
            else if ($row['office_assign'] == "ORA") {
                $admission_update = "UPDATE office_head as head JOIN account_type as account ON head.account_fk = account.account_info_id SET head.office_fname='$fname',head.office_lname='$lname',account.status =1 WHERE head.account_fk = $id";
                if (mysqli_query($conn,$admission_update) === TRUE) {
                    session_start();
                    $_SESSION['ora'] = $use_email;
                    header("location: Home/Office/ORA");
                    exit();
                }
            }
            else if ($row['office_assign'] == "DSA_office") {
                $admission_update = "UPDATE office_head as head JOIN account_type as account ON head.account_fk = account.account_info_id SET head.office_fname='$fname',head.office_lname='$lname',account.status =1 WHERE head.account_fk = $id";
                if (mysqli_query($conn,$admission_update) === TRUE) {
                    # code...
                    session_start();
                    $_SESSION['dsa'] = $use_email;
                    header("location: Home/Office/DSA");
                    exit();
                }
            }
            else if ($row['office_assign'] == "Veritas") {
                $admission_update = "UPDATE office_head as head JOIN account_type as account ON head.account_fk = account.account_info_id SET head.office_fname='$fname',head.office_lname='$lname',account.status =1 WHERE head.account_fk = $id";
                if (mysqli_query($conn,$admission_update) === TRUE) {
                    # code...
                    session_start();
                    $_SESSION['veritas'] = $use_email;
                    header("location: Home/Office/Veritas");
                    exit();
                }
            }
            else if ($row['office_assign'] == "DAO") {
                $admission_update = "UPDATE office_head as head JOIN account_type as account ON head.account_fk = account.account_info_id SET head.office_fname='$fname',head.office_lname='$lname',account.status =1 WHERE head.account_fk = $id";
                if (mysqli_query($conn,$admission_update) === TRUE) {
                   session_start();
                    $_SESSION['dao'] = $use_email;
                    header("location: Home/Office/DAO");
                    exit();
                }
            }
            else if ($row['office_assign'] == "Cashier") {
               $admission_update = "UPDATE office_head as head JOIN account_type as account ON head.account_fk = account.account_info_id SET head.office_fname='$fname',head.office_lname='$lname',account.status =1 WHERE head.account_fk = $id";
                if (mysqli_query($conn,$admission_update) === TRUE) {
                    session_start();
                    $_SESSION['cashier'] = $use_email;
                    header("location: Home/Office/Cashier");
                    exit();
                }
            }
            else if ($row['office_assign'] == "Program_dean") {
                $sql_find = "SELECT *FROM office_head as head JOIN tbl_department as dept ON head.department_fk = dept.department_id WHERE head.department_fk = $dept_fk";

                $result_dept = mysqli_query($conn,$sql_find);

                while ($row  = mysqli_fetch_assoc($result_dept)) {
                    
                    if($row['department_name'] == "Nursing Program"){
                        $admission_update = "UPDATE office_head as head JOIN account_type as account ON head.account_fk = account.account_info_id SET head.office_fname='$fname',head.office_lname='$lname',account.status =1 WHERE head.account_fk = $id";
                        if (mysqli_query($conn,$admission_update) === TRUE) {
                            session_start();
                            $_SESSION['nursing'] = $use_email;
                            header("location: Home/executive/Program_Dean/NP");
                            exit();
                        }
                    }
                    else if ($row['department_name'] == "Business Administration Program") {
                        $admission_update = "UPDATE office_head as head JOIN account_type as account ON head.account_fk = account.account_info_id SET head.office_fname='$fname',head.office_lname='$lname',account.status =1 WHERE head.account_fk = $id";
                        if (mysqli_query($conn,$admission_update) === TRUE) {
                            session_start();
                            $_SESSION['bap'] = $use_email;
                            header("location: Home/executive/Program_Dean/BAP");
                            exit();
                        }
                    }
                    else if ($row['department_name'] == "Computer Studies Program") {
                        $admission_update = "UPDATE office_head as head JOIN account_type as account ON head.account_fk = account.account_info_id SET head.office_fname='$fname',head.office_lname='$lname',account.status =1 WHERE head.account_fk = $id";
                        if (mysqli_query($conn,$admission_update) === TRUE) {
                            session_start();
                            $_SESSION['csp'] = $use_email;
                            header("location: Home/executive/Program_Dean/CSP");
                            exit();
                        }
                    } 
                    else if ($row['department_name'] == "Arts And Science Program") {
                        $admission_update = "UPDATE office_head as head JOIN account_type as account ON head.account_fk = account.account_info_id SET head.office_fname='$fname',head.office_lname='$lname',account.status =1 WHERE head.account_fk = $id";
                        if (mysqli_query($conn,$admission_update) === TRUE) {
                            session_start();
                            $_SESSION['asp'] = $use_email;
                            header("location: Home/executive/Program_Dean/ASP");
                            exit();
                        }
                    } 
                    else if ($row['department_name'] == "Accountancy Program") {
                        $admission_update = "UPDATE office_head as head JOIN account_type as account ON head.account_fk = account.account_info_id SET head.office_fname='$fname',head.office_lname='$lname',account.status =1 WHERE head.account_fk = $id";
                        if (mysqli_query($conn,$admission_update) === TRUE) {
                            session_start();
                            $_SESSION['ap'] = $use_email;
                            header("location: Home/executive/Program_Dean/AP");
                            exit();
                        }
                    } 
                    else if ($row['department_name'] == "College of Law Program") {
                        $admission_update = "UPDATE office_head as head JOIN account_type as account ON head.account_fk = account.account_info_id SET head.office_fname='$fname',head.office_lname='$lname',account.status =1 WHERE head.account_fk = $id";
                        if (mysqli_query($conn,$admission_update) === TRUE) {
                            session_start();
                            $_SESSION['law'] = $use_email;
                            header("location: Home/executive/Program_Dean/College_Law");
                            exit();
                        }
                    } 
                    else if ($row['department_name'] == "Engineering and Technology Program") {
                        $admission_update = "UPDATE office_head as head JOIN account_type as account ON head.account_fk = account.account_info_id SET head.office_fname='$fname',head.office_lname='$lname',account.status =1 WHERE head.account_fk = $id";
                        if (mysqli_query($conn,$admission_update) === TRUE) {
                            session_start();
                            $_SESSION['etp'] = $use_email;
                            header("location: Home/executive/Program_Dean/ETP");
                            exit();
                        }
                    }
                    else if ($row['department_name'] == "Teachers Education Program") {
                        $admission_update = "UPDATE office_head as head JOIN account_type as account ON head.account_fk = account.account_info_id SET head.office_fname='$fname',head.office_lname='$lname',account.status =1 WHERE head.account_fk = $id";
                        if (mysqli_query($conn,$admission_update) === TRUE) {
                            session_start();
                            $_SESSION['tep'] = $use_email;
                            header("location: Home/executive/Program_Dean/TEP");
                            exit();
                        }
                    }
                    else{
                        $admission_update = "UPDATE office_head as head JOIN account_type as account ON head.account_fk = account.account_info_id SET head.office_fname='$fname',head.office_lname='$lname',account.status =1 WHERE head.account_fk = $id";
                        if (mysqli_query($conn,$admission_update) === TRUE) {
                            session_start();
                            $_SESSION['cjep'] = $use_email;
                            header("location: Home/executive/Program_Dean/CJEP");
                            exit();
                        }
                    }
                } 
            }
            else if ($row['office_assign'] == "Records_incharge") {
                $admission_update = "UPDATE office_head as head JOIN account_type as account ON head.account_fk = account.account_info_id SET head.office_fname='$fname',head.office_lname='$lname',account.status =1 WHERE head.account_fk = $id";
                if (mysqli_query($conn,$admission_update) === TRUE) {
                    # code...
                    session_start();
                    $_SESSION['record'] = $use_email;
                    header("location: Home/Office/Record");
                    exit();
                }
            }
            else if ($row['office_assign'] == "Registrars_office") {

                

                $admission_update = "UPDATE office_head as head JOIN account_type as account ON head.account_fk = account.account_info_id SET head.office_fname='$fname',head.office_lname='$lname',account.status =1 WHERE head.account_fk = $id";
                if (mysqli_query($conn,$admission_update) === TRUE) {
                    # code...
                    session_start();
                    $_SESSION['registrar'] = $use_email;
                    header("location: Home/executive/registrar");
                    exit();
                }
            }
            else if ($row['office_assign'] == "College-librarian") {
                $admission_update = "UPDATE office_head as head JOIN account_type as account ON head.account_fk = account.account_info_id SET head.office_fname='$fname',head.office_lname='$lname',account.status =1 WHERE head.account_fk = $id";
                if (mysqli_query($conn,$admission_update) === TRUE) {
                    # code...
                    session_start();
                    $_SESSION['library'] = $use_email;
                    header("location: Home/Office/library");
                    exit();
                }
            }
            else if ($row['office_assign'] == "PMO") {
                $admission_update = "UPDATE office_head as head JOIN account_type as account ON head.account_fk = account.account_info_id SET head.office_fname='$fname',head.office_lname='$lname',account.status =1 WHERE head.account_fk = $id";
                if (mysqli_query($conn,$admission_update) === TRUE) {
                    # code...
                    session_start();
                    $_SESSION['pmo'] = $use_email;
                    header("location: Home/Office/PMO");
                    exit();
                }
            }
            else if ($row['office_assign'] == "Bookstore") {
                $admission_update = "UPDATE office_head as head JOIN account_type as account ON head.account_fk = account.account_info_id SET head.office_fname='$fname',head.office_lname='$lname',account.status =1 WHERE head.account_fk = $id";
                if (mysqli_query($conn,$admission_update) === TRUE) {
                    session_start();
                    $_SESSION['bookstore'] = $use_email;
                    header("location: Home/Office/Bookstore");
                    exit();
                }
            }
            else if ($row['office_assign'] == "ITSD") {
                $admission_update = "UPDATE office_head as head JOIN account_type as account ON head.account_fk = account.account_info_id SET head.office_fname='$fname',head.office_lname='$lname',account.status =1 WHERE head.account_fk = $id";
                if (mysqli_query($conn,$admission_update) === TRUE) {
                    # code...
                    session_start();
                    $_SESSION['itsd'] = $use_email;
                    header("location: Home/Office/ITSD");
                    exit();
                }
            }
            else if ($row['office_assign'] == "Graduate_studies") {
                $admission_update = "UPDATE office_head as head JOIN account_type as account ON head.account_fk = account.account_info_id SET head.office_fname='$fname',head.office_lname='$lname',account.status =1 WHERE head.account_fk = $id";
                if (mysqli_query($conn,$admission_update) === TRUE) {
                    session_start();
                    $_SESSION['studies'] = $use_email;
                    header("location: Home/Office/Graduates");
                    exit();
                }
            }
            else if ($row['office_assign'] == "HRMD") {
                $admission_update = "UPDATE office_head as head JOIN account_type as account ON head.account_fk = account.account_info_id SET head.office_fname='$fname',head.office_lname='$lname',account.status =1 WHERE head.account_fk = $id";
                if (mysqli_query($conn,$admission_update) === TRUE) {
                    # code...
                    session_start();
                    $_SESSION['hrmd'] = $use_email;
                    header("location: Home/executive/HRMD_Head");
                    exit();
                }
            }
            else if ($row['office_assign'] == "VP_ASA") {
                $admission_update = "UPDATE office_head as head JOIN account_type as account ON head.account_fk = account.account_info_id SET head.office_fname='$fname',head.office_lname='$lname',account.status =1 WHERE head.account_fk = $id";
                if (mysqli_query($conn,$admission_update) === TRUE) {
                    session_start();
                    $_SESSION['vp_asa'] = $use_email;
                    header("location: Home/executive/VP_Asa");
                    exit();
                }
            }
            else if ($row['office_assign'] == "University_president") {
                $admission_update = "UPDATE office_head as head JOIN account_type as account ON head.account_fk = account.account_info_id SET head.office_fname='$fname',head.office_lname='$lname',account.status =1 WHERE head.account_fk = $id";
                if (mysqli_query($conn,$admission_update) === TRUE) {
                    session_start();
                    $_SESSION['president'] = $use_email;
                    header("location: Home/executive/President");
                    exit();
                }
            }
            else if ($row['office_assign'] == "Comptroller") {
                $admission_update = "UPDATE office_head as head JOIN account_type as account ON head.account_fk = account.account_info_id SET head.office_fname='$fname',head.office_lname='$lname',account.status =1 WHERE head.account_fk = $id";
                if (mysqli_query($conn,$admission_update) === TRUE) {
                    # code...
                    session_start();
                    $_SESSION['comptroller'] = $use_email;
                    header("location: Home/Office/Comptroller");
                    exit();
                }
            }
            else if ($row['office_assign'] == "VP_AAR") {
               $admission_update = "UPDATE office_head as head JOIN account_type as account ON head.account_fk = account.account_info_id SET head.office_fname='$fname',head.office_lname='$lname',account.status =1 WHERE head.account_fk = $id";
                if (mysqli_query($conn,$admission_update) === TRUE) {
                    session_start();
                    $_SESSION['vp_arr'] = $use_email;
                    header("location: Home/executive/VP_Arr");
                    exit();
                }
            }
            else{
                $sql_find = "SELECT *FROM office_head as head JOIN tbl_department as dept ON head.department_fk = dept.department_id WHERE head.department_fk = $dept_fk";

                $result_dept = mysqli_query($conn,$sql_find);

                while ($row  = mysqli_fetch_assoc($result_dept)) {
                    
                    if($row['department_name'] == "Nursing Program"){
                        $admission_update = "UPDATE office_head as head JOIN account_type as account ON head.account_fk = account.account_info_id SET head.office_fname='$fname',head.office_lname='$lname',account.status =1 WHERE head.account_fk = $id";
                        if (mysqli_query($conn,$admission_update) === TRUE) {
                            session_start();
                            $_SESSION['chair_nursing'] = $use_email;
                            header("location: Home/executive/Department_Chairperson/NP");
                            exit();
                        }
                    }
                    else if ($row['department_name'] == "Business Administration Program") {
                        $admission_update = "UPDATE office_head as head JOIN account_type as account ON head.account_fk = account.account_info_id SET head.office_fname='$fname',head.office_lname='$lname',account.status =1 WHERE head.account_fk = $id";
                        if (mysqli_query($conn,$admission_update) === TRUE) {
                            session_start();
                            $_SESSION['chair_bap'] = $use_email;
                            header("location: Home/executive/Department_Chairperson/BAP");
                            exit();
                        }
                    }
                    else if ($row['department_name'] == "Computer Studies Program") {
                        $admission_update = "UPDATE office_head as head JOIN account_type as account ON head.account_fk = account.account_info_id SET head.office_fname='$fname',head.office_lname='$lname',account.status =1 WHERE head.account_fk = $id";
                        if (mysqli_query($conn,$admission_update) === TRUE) {
                            session_start();
                            $_SESSION['chair_csp'] = $use_email;
                            header("location: Home/executive/Department_Chairperson/CSP");
                            exit();
                        }
                    } 
                    else if ($row['department_name'] == "Arts And Science Program") {
                        $admission_update = "UPDATE office_head as head JOIN account_type as account ON head.account_fk = account.account_info_id SET head.office_fname='$fname',head.office_lname='$lname',account.status =1 WHERE head.account_fk = $id";
                        if (mysqli_query($conn,$admission_update) === TRUE) {
                            session_start();
                            $_SESSION['chair_asp'] = $use_email;
                            header("location: Home/executive/Department_Chairperson/ASP");
                            exit();
                        }
                    } 
                    else if ($row['department_name'] == "Accountancy Program") {
                        $admission_update = "UPDATE office_head as head JOIN account_type as account ON head.account_fk = account.account_info_id SET head.office_fname='$fname',head.office_lname='$lname',account.status =1 WHERE head.account_fk = $id";
                        if (mysqli_query($conn,$admission_update) === TRUE) {
                            session_start();
                            $_SESSION['chair_ap'] = $use_email;
                            header("location: Home/executive/Department_Chairperson/AP");
                            exit();
                        }
                    } 
                    else if ($row['department_name'] == "College of Law Program") {
                        $admission_update = "UPDATE office_head as head JOIN account_type as account ON head.account_fk = account.account_info_id SET head.office_fname='$fname',head.office_lname='$lname',account.status =1 WHERE head.account_fk = $id";
                        if (mysqli_query($conn,$admission_update) === TRUE) {
                            session_start();
                            $_SESSION['chair_law'] = $use_email;
                            header("location: Home/executive/Department_Chairperson/College_Law");
                            exit();
                        }
                    } 
                    else if ($row['department_name'] == "Engineering and Technology Program") {
                        $admission_update = "UPDATE office_head as head JOIN account_type as account ON head.account_fk = account.account_info_id SET head.office_fname='$fname',head.office_lname='$lname',account.status =1 WHERE head.account_fk = $id";
                        if (mysqli_query($conn,$admission_update) === TRUE) {
                            session_start();
                            $_SESSION['chair_etp'] = $use_email;
                            header("location: Home/executive/Department_Chairperson/ETP");
                            exit();
                        }
                    }
                    else if ($row['department_name'] == "Teachers Education Program") {
                        $admission_update = "UPDATE office_head as head JOIN account_type as account ON head.account_fk = account.account_info_id SET head.office_fname='$fname',head.office_lname='$lname',account.status =1 WHERE head.account_fk = $id";
                        if (mysqli_query($conn,$admission_update) === TRUE) {
                            session_start();
                            $_SESSION['chair_tep'] = $use_email;
                            header("location: Home/executive/Department_Chairperson/TEP");
                            exit();
                        }
                    }
                    else{
                        $admission_update = "UPDATE office_head as head JOIN account_type as account ON head.account_fk = account.account_info_id SET head.office_fname='$fname',head.office_lname='$lname',account.status =1 WHERE head.account_fk = $id";
                        if (mysqli_query($conn,$admission_update) === TRUE) {
                            session_start();
                            $_SESSION['chair_cjep'] = $use_email;
                            header("location: Home/executive/Department_Chairperson/CJEP");
                            exit();
                        }
                    }     
                }
            }
        }
    }
?>


<!-- Student -->
<?php  

    function Student_Data($use_email,$id,$fname,$lname){

        require 'connector/connect.php';

        $update = "UPDATE tbl_student as student JOIN account_type as account ON student.account_student_fk = account.account_info_id SET student.fname ='$fname',student.lname='$lname',account.status = 1 WHERE student.account_student_fk = $id";
        if (mysqli_query($conn,$update) === TRUE) {
            session_start();
            $_SESSION['student'] = $use_email;
            header("location: Home/student");
            exit();
        }

        
    }

?>


<!-- Employee to search tbl_employee-->
<?php  
    function search_employee($use_email,$use_id,$fname,$lname){

        // echo $use_id;

        require 'connector/connect.php';

        $employee = "SELECT *FROM account_type as account JOIN tbl_employee as employee ON account.account_info_id = employee.emplo_account_fk WHERE employee.emplo_account_fk = $use_id";

        $result_find = mysqli_query($conn,$employee);
        while ($row = mysqli_fetch_assoc($result_find)) {
            $employee_id = $row['employee_id'];

            Update_employee($use_email,$use_id,$employee_id,$fname,$lname);
        }
    }
?>

<?php  
    function  Update_employee($use_email,$use_id,$employee_id,$fname,$lname){

        require 'connector/connect.php';

        $sql = "SELECT *FROM tbl_employee as employee JOIN tbl_employee_info as info ON employee.employee_id = info.employee_fk WHERE employee.employee_id = $employee_id";

        $result_find = mysqli_query($conn,$sql);
        while ($row = mysqli_fetch_assoc($result_find)) {
            
            if ($row['employee_type'] == "Teaching") {
                $update = "UPDATE tbl_employee as teaching JOIN account_type as account ON teaching.emplo_account_fk = account.account_info_id SET teaching.emplo_fname='$fname',teaching.emplo_lname='$lname',account.status = 1 WHERE teaching.emplo_account_fk = $use_id";
                if (mysqli_query($conn,$update) === TRUE) {
                    session_start();
                    $_SESSION['teaching'] = $use_email;
                    header("location: Home/employee/teaching");
                    exit();
                }
            }
            else{
                $update = "UPDATE tbl_employee as non_teaching JOIN account_type as account ON non_teaching.emplo_account_fk = account.account_info_id SET non_teaching.emplo_fname='$fname',non_teaching.emplo_lname='$lname',account.status = 1 WHERE non_teaching.emplo_account_fk = $use_id";
                if (mysqli_query($conn,$update) === TRUE) {
                    session_start();
                    $_SESSION['employee'] = $use_email;
                    header("location: Home/employee/non-teaching");
                    exit();
                }
            }
        }
    }
?>

<?php  
    
    function employee_sepate_page($id,$u_email){
        require 'connector/connect.php';

        $sql = "SELECT *FROM account_type as account JOIN tbl_employee_info as employee ON account.account_info_id = employee.emplo_info_account_fk WHERE employee.emplo_info_account_fk = $id";

        $search_type = mysqli_query($conn,$sql);

        while ($row = mysqli_fetch_assoc($search_type)) {
            
            if ($row['employee_type'] == "Teaching") {
                session_start();
                $_SESSION['teaching'] = $u_email;
                header("location: Home/employee/teaching");
                exit();
            }
            else{
                session_start();
                $_SESSION['non_teaching'] = $u_email;
                header("location: Home/employee/non-teaching");
                exit();
            }
        }
    }
?>



<?php  

    function Identify_employee($u_email,$fname,$lname,$id){

        require 'connector/connect.php';

        $sql = "SELECT *FROM account_type as account JOIN tbl_employee_info as info ON account.account_info_id = info.emplo_info_account_fk WHERE account.account_info_id = $id";

        $result = mysqli_query($conn,$sql);

        while ($row = mysqli_fetch_assoc($result)) {
            
            if ($row['employee_type'] == "Teaching") {
                session_start();
                $_SESSION['teaching'] = $u_email;
                header("location: Home/employee/teaching");
                exit();
            }
            else{
                session_start();
                $_SESSION['non_teaching'] = $u_email;
                header("location: Home/employee/non-teaching");
                exit();
            }
        }
    }    

?>
