<?php   
	session_start();
	unset($_SESSION['chair_law']); 
	header("location: ../../../../index"); 
	exit();
?>