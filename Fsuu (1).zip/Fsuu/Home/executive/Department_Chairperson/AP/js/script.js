$(document).ready(function(event) {
	
	$(document).on('click', '#view', function(event) {
		event.preventDefault();

		var id = $(this).prop('value');

        $.ajax({
            url: "function/search",
            type: "POST",
            data: {
                "search_data" : true,
                id:id,
            },
            success:function(response){
            	// console.log(response);
                $('#status tbody').empty();
                if (response == 2) {

                }
                else{
                    $.each(response, function(index, val) {
                        
                    $('.status-modal').addClass('bg-status');

                    
                     if (val['purpose'] == "GRADING") {
                                 var regis = val['registrar']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['registrar'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var library = val['library']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['library'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var pmo = val['pmo']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['pmo'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var bookstore = val['bookstore']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['bookstore'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var chair = val['Department_chair']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['Department_chair'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     //var comproller = val['Comptroller']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var program_dean = val['program_dean']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['program_dean'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     //var arts = val['asp_dean']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var hrmd = val['HRMD']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['HRMD'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var vp_aar = val['vp_aar']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['vp_aar'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";

                                $('.data-employee').append('<tr class="text-center">'+
                                    '<td>Registrar Office</td>'+
                               

                                    '<td>'+regis+'</td>'+
                                '</tr>'+
                                '<tr class="text-center">'+
                                    '<td>College Librarian</td>'+
                                   
                                    '<td>'+library+'</td>'+
                                '</tr>'+
                                '<tr class="text-center">'+
                                    '<td>Property and Maintenance Office</td>'+
                                  
                                    '<td>'+pmo+'</td>'+
                                '</tr>'+
                                '<tr class="text-center">'+
                                    '<td>Bookstore/Auxilliary Resource Services</td>'+
                                    
                                    '<td>'+bookstore+'</td>'+
                                '</tr>'+
                                '<tr class="text-center">'+
                                    '<td>Department (Chairperson)</td>'+
                                    
                                    '<td>'+chair+'</td>'+
                                '</tr>'+
                                '<tr class="text-center">'+
                                    '<td>Program Dean</td>'+
                                    
                                    '<td>'+program_dean+'</td>'+
                                '</tr>'+
                                '<tr class="text-center">'+
                                    '<td>HRMD (Director)</td>'+
                                    
                                    '<td>'+hrmd+'</td>'+
                                '</tr>'+
                                '<tr class="text-center">'+
                                    '<td>Academic Affairs and Research (VP-AAR)</td>'+
                                    
                                    '<td>'+vp_aar+'</td>'+
                                '</tr>');
                            }
                    });
                }
            }
        });
		/* Act on the event */
	});

	$('#status-modal-close').click(function(event) {
		/* Act on the event */
		 $('.status-modal').removeClass('bg-status');
	});


	$(document).on('click', '#employee_approved', function(event) {
        event.preventDefault();
        var id = $(this).attr('value');
       
        $.ajax({
            url: "function/update",
            type: "POST",
            data:{
                "employee_update" : true,
                id:id,
            },
            success:function(response){
                console.log(response);
                if (response == 1) {
                    alertify.success('Approved');
                    setTimeout(function(){
                    	window.location = 'applicant'
                    },1500);
                }
                else{
                	alertify.error('Failed To Approved');
                }
            }
        });
    });

    $(document).on('click', '#undo-employee', function(event) {
    	event.preventDefault();

    	 var id = $(this).attr('value');
      

        $.ajax({
            url: "function/update",
            type: "POST",
            data:{
                "undo_employee" : true,
                id:id,
            },
            success:function(response){
                console.log(response);
                if (response == 1) {
                    alertify.success('Undo Status');
                    setTimeout(function(){
                    	window.location ="clearance"
                    },1500);
                }
                else{
                	alertify.error("Something went wrong");
                }
            }
        });
		/* Act on the event */

    	/* Act on the event */
    });


});