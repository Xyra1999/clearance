<?php  

	require "../../../../connector/connect.php";


	session_start();
	

	if (isset($_POST['teaching_update'])) {
	// echo "!@3";
		$id = mysqli_real_escape_string($conn,$_POST['id']);
		$fname = mysqli_real_escape_string($conn,$_POST['fname']);
		$mnane = mysqli_real_escape_string($conn,$_POST['mnane']);
		$lname = mysqli_real_escape_string($conn,$_POST['lname']);


		$sql = "UPDATE tbl_employee SET emplo_fname= '$fname',emplo_mname= '$mnane',emplo_lname= '$lname' WHERE employee_id = $id";

		if (mysqli_query($conn,$sql) === TRUE) {
			echo 1;
		}
	}
	else if (isset($_POST['seacrch'])) {
		
		$id = mysqli_real_escape_string($conn,$_POST['id']);

		$search = "SELECT *FROM tbl_employee_msg WHERE office_fk = $id";

		$result_val = [];
		$result_q = mysqli_query($conn,$search);
		if (mysqli_num_rows($result_q) > 0) {
			foreach ($result_q as $value) {
			    array_push($result_val,$value);
			}
			header("Content-type: application/json");
			echo json_encode($result_val);

		}
		else{
			echo 2;
		}
	}
	else if (isset($_POST['reply_msg'])) {

		$id = mysqli_real_escape_string($conn,$_POST['id']);
		$reply_msg = mysqli_real_escape_string($conn,$_POST['reply_msg']);
		$convo_id = mysqli_real_escape_string($conn,$_POST['convo_id']);


		$purpose = $_SESSION['purpose'];
		
		$user_fk = $_SESSION['account_fk'];

	

		$sql = "UPDATE tbl_employee_msg SET reply_msg ='$reply_msg',status =2 WHERE employee_msg_id =$convo_id";
		// $sql = "INSERT INTO tbl_employee_msg (text_msg,reply_msg,file_name,account_fk,office_fk,date_msg,status) VALUES ('','$reply_msg','',$user_fk,$id,NOW(),2)";
		if (mysqli_query($conn,$sql) === TRUE) {
			
			$update = "UPDATE tbl_employee_status SET registrar = 0 WHERE tbl_employee_account_fk = $user_fk AND purpose = '$purpose'";

			if (mysqli_query($conn,$update) === TRUE) {
				echo 1;
			}
		}


	}


?>