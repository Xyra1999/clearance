<?php  


	session_start();

	if ($_SESSION['registrar']) {
		require "../../../connector/connect.php";
		$email = $_SESSION['registrar'];

		$find = "SELECT *from account_type WHERE email ='$email'";

		$result = mysqli_query($conn,$find);

	    if (mysqli_num_rows($result) > 0) {
	        while ($row = mysqli_fetch_assoc($result)) {
	            $u_email = $row['email'];
	            $id = $row['account_info_id'];
	            Data($u_email,$id);
	            break;
	        }
    	}
	}
	else{
		header("location: ../../../index");
		exit();
	}

?>

<?php  

	function Data($u_email,$id){
		require "../../../connector/connect.php";

		$search = "SELECT *FROM account_type as account JOIN office_head as office ON account.account_info_id = office.account_fk WHERE office.account_fk = $id";

		$result = mysqli_query($conn,$search);

	    if (mysqli_num_rows($result) > 0) {
	        while ($row = mysqli_fetch_assoc($result)) {
	            $u_email = $row['email'];
	            $fname = $row['office_fname'];
	            $lname = $row['office_lname'];
	            $office_id = $row['office_id'];
	            Display($u_email,$fname,$lname,$office_id);
	            break;
	        }
    	}

	}
?>

<?php  

	function Display($u_email,$fname,$lname,$office_id){
		?>

			<!DOCTYPE html>
			<html>
			<head>
				<meta charset="utf-8">
				<meta http-equiv="X-UA-Compatible" content="IE=edge">
				<link href="../../../assets/css/bootstrap.min.css" rel="stylesheet">
				<link rel="stylesheet" href="../../../assets/css/style.css">
				<link href="../../../assets/icon/fsuu.png" rel="icon">
				
				<link href="../../../assets/css/alertify.css" rel="stylesheet">
    			<link href="../../../assets/css/alertify.min.css" rel="stylesheet">
				<link rel="stylesheet" href="../../../assets/css/jquery.dataTables.min.css">
				<link rel="stylesheet" href="../../../assets/css/responsive.dataTables.min.css">
				<link rel="stylesheet" href="css/registrar.css">
				<script type="text/javascript" src="../../../assets/js/jquery-3.4.1.min.js"></script>
				<title>Father Saturnino Urios University</title>
			</head>
			<body>

				<?php  
					$_SESSION['office_id'] = $office_id;
				?>

			<!-- header -->
			<nav class="navbar navbar-default banner-color">
			  <div class="container-fluid">
			    <a href="index"><img src="../../../assets/image/plain.png" alt="" height="100" width="200" class="img-fluid rounded"></a>
			    <div class="d-flex">
			      <div class="row">
			      	<div class="list">
			      		<ul>
			      			<li><span class="text-light fw-bold" style="font-size: 15px;">Registrar</span></li>
			      			<li><span class="text-light fw-bold" style="font-size: 16px;"><?php echo $fname." ".$lname; ?></span></li>
			      			<li><a href="profile" class="text-light fw-bold"><i class="fas fa-user-circle fs-6"></i></a></li>
			      			<li>
			      				<button class="btn position-relative" id="message-modal">
								 <i class="fas fa-envelope fs-5 text-light"></i>
								  <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
									
								    <span class="visually-hidden">unread messages</span>
								  </span>
								</button>
			      				<!-- <button class="btn btn-sm btn-outline"></button> -->
			      			</li>
			      			<li><a class="text-light fw-bold" href="logout"><i class="fas fa-power-off"></i></a></li>
			      		</ul>
			      	</div>
			      </div>
			    </div>
			  </div>
			</nav>
			<div class="color-header">
				<div class="container">
					<div class="inside-header text-left">
						<ul>
							<li><a href="applicant" class="text-secondary">Applicant</a></li>
							<li><a class="text-secondary" href="archives">Archives</a></li>
							<li><a class="text-secondary" href="clear">Cleared Clearance</a></li>
							<li><a href="logs" class="text-secondary">Activity Logs</a></li>
						</ul>
					</div>
				</div>
			</div>
			<!-- end of header -->

			<div class="mt-4">
				<div class="container">
					<div class="col-md-4">
						<select name="" id="applicant" class="form-select">
							<option value="" disabled>Choose Applicant</option>
							<option value="Employee" selected>Employee</option>
							<option value="Student" >Student</option>
						</select>
					</div>
				</div>
			</div>



			<div class="container mt-4">
				<div class="table-box">
					<table id="example" class="table table-striped display responsive nowrap" style="width:100%">
			        <thead>
			            <tr class="table-dark">
			                <th>#</th>
			                <th>Purpose</th>
			                <th>Email</th>
			                <th>Fullname</th>
			                <th>ID Number</th>
			                <th class="text-center">Action</th>
			            </tr>
			        </thead>
			        <tbody>

			        </tbody>
	          	</table>
				</div>
			</div>

			

		<?php
	}

?>

<!-- msge -->
<div class="modal_box">
				<div class="container">
					<div class="modal-dialog modal-lg">
						<div class="modal-content">
							<div class="modal-header banner">
								<div class="modal-title">
									<h3 class="text-light">Deficiency</h3>
								</div>
							</div>
							<div class="modal-body">
								<div class="container">
									<div class="row">
										<div class="col-md-6">
											<label for="" class="form-label">
												Email
											</label>
											<input type="text" class="form-control" id="applicant_email" disabled>
										</div>
										<div class="col-md-6">
											<label for="" class="form-label">
												Category
											</label>
											<input type="text" class="form-control" id="category" disabled value="Document">
										</div>
										<div class="col-md-12">
											<label for="" class="form-label fw-bold">
												Your Message
											</label>
											<textarea name="" id="msg" cols="2" rows="2" style="resize: none;" class="form-control" disabled></textarea>
										</div>
										<div class="col-md-12">
											<label for="" class="form-label fw-bold">
												Applicant Reply
											</label>
											<textarea name="" id="applicant_reply" cols="2" rows="2" style="resize: none;" class="form-control" disabled></textarea>
										</div>
										<div class="col-md-12">
											<label for="" class="form-label fw-bold">
												File
											</label>
											<a href="" id="file"></a>
										</div>
									</div>
								</div>
							</div>
							<div class="modal-footer">
								<button class="btn btn-sm btn-secondary" id="close_modal">Cancel</button>
								<button class="btn btn-sm btn-success" id="approved_msg">Approved</button>
							</div>
						</div>
					</div>
				</div>
			</div>
		<!-- end of msg -->


		<!-- reply -->

		<div class="reply_modal">
			<div class="container">
					<div class="modal-dialog modal-lg">
						<div class="modal-content">
							<div class="modal-header banner">
								<div class="modal-title">
									<h3 class="text-light">Deficiency</h3>
								</div>
							</div>
							<div class="modal-body">
								<div class="container">
									<div class="row">
										<div class="col-md-6">
											<label for="" class="form-label">
												Email
											</label>
											<input type="text" class="form-control" id="email" disabled>
										</div>
										<div class="col-md-6">
											<label for="" class="form-label">
												Category
											</label>
											<input type="text" class="form-control" id="category" disabled value="Document">
											<input type="text" id="status_id" class="form-control d-none">
										</div>
										<div class="col-md-12">
											<label for="" class="form-label fw-bold">
												Your Message
											</label>
											<textarea name="" id="office_msg" cols="5" rows="5" style="resize: none;" class="form-control"></textarea>
										</div>
									</div>
								</div>
							</div>
							<div class="modal-footer">
								<button class="btn btn-sm btn-secondary" id="close_modal_msg">Cancel</button>
								<button class="btn btn-sm btn-primary" id="employee_deficiency">Send</button>
							</div>
						</div>
					</div>
				</div>
		</div>

		<!-- end of reply  -->


		<!-- status modal -->

		<div class="status-modal">
			<div class="container">
				<div class="modal-dialog modal-lg">
					<div class="modal-content">
						<div class="modal-header">
							<div class="modal-title">
								<h3><center>Status</center></h3>
							</div>
						</div>
						<div class="modal-body">
							<table id="status">
								<thead>
									 <tr>
									    <th class="text-center">Officess</th>
									    <th class="text-center">Status</th>
									 </tr>
								</thead>
								<tbody class="data-employee">
									
								</tbody>
							</table>
						</div>
						<div class="modal-footer">
							<button class="btn btn-sm btn-secondary" id="status-modal-close">Close</button>
						</div>
					</div>
				</div>
			</div>
		</div>



		<!-- end of status modal -->



		<div class="message">
			<div class="modal_msg">
				<div class="container">
					<div class="box-width">
						<center><h3 class="fs-5 p-6">Message</h3></center>
						<hr>
						<div class="list-msg">
							<ul class="data-msg">
								
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>


		<!-- modal for approved with inc or w/o inc -->

		<div class="modal_inc">
			<div class="container">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							<div class="modal-title">
								<h3>Option Approve</h3>
							</div>
						</div>
						<div class="modal-body">
							<button class="btn btn-sm btn-success" id="approved_without">Approved W/O INC</button>
							<button class="btn btn-sm btn-danger" id="approve_inc">Approved W/ INC</button>
						</div>
						<div class="modal-footer">
							<button class="btn btn-sm btn-secondary" id="close_modal_inc">Close</button>
						</div>
					</div>
				</div>
			</div>
		</div>

		<!-- end of modal for approved with inc or w/o inc  -->

<script type="text/javascript" src="../../../assets/js/fontawesome.js"></script>
<script type="text/javascript" src="../../../assets/js/datatables.min.js"></script>
<script src="../../../assets/js/alertify.js"></script>
<script src="../../../assets/js/alertify.min.js"></script>

<script src="js/script.js"></script>
<script src="js/load_msg.js"></script>

<script>
	$(document).ready(function() {
   
	    $('#example').DataTable({
	        "processing": true,
	        "serverSide": true,
	        "ajax" : "function/employee_load"
	    });
	    responsive: true

	});
</script>

</body>
</html>