<?php  
	
	require "../../../../connector/connect.php";

	session_start();

	$id =  $_SESSION['office_id'];

	$output = "";


	$que = "SELECT *from tbl_employee_msg JOIN office_head ON office_head.office_id = tbl_employee_msg.office_fk JOIN account_type as account ON account.account_info_id = tbl_employee_msg.account_fk WHERE tbl_employee_msg.office_fk = $id AND tbl_employee_msg.status IN (2,1) AND text_msg != '' order by date_msg DESC";
		$result = mysqli_query($conn,$que);
		$output = "";
		if (mysqli_num_rows($result) > 0) {
			while ($row = mysqli_fetch_assoc($result)) {
				$assign = $row['email'];
				$date = strtotime($row['date_msg']);
				$format = date('M d Y  g:i:A' ,$date);
			    $output .='	
			    	<li class="message-list" id="'.$row['employee_msg_id'].'">
			    	<button id="btn" style="display: none;">'.$row['employee_msg_id'].'</button>
			    	<button id="status_info" class="d-none" value="'.$row['status_info_id'].'"></button>
			    		<span class="fw-bold fs-6 applicant_email">'.$assign.'</span>
			    		<br>
			    		<small>'.$row['reply_msg'].' <br> <span>'.$format.'</span></small>
			    		<hr>
			    	</li>
			    ';
			}
		}
		else{
			$output .= '
				<li> <center>	<a  class="text-bold text-italic nav-link text-secondary fw-bold fs-5">No Message</a> </center> </li>
			';
		}
	
	$query = "SELECT *from tbl_employee_msg WHERE account_fk = $id AND status =2";
	$result_1 = mysqli_query($conn,$query);
	$count = mysqli_num_rows($result_1);
	
	$data = array(
		'notification'	=> $output,
		'unseen_notification'	=> $count
	);
	echo json_encode($data);

	// }

?>