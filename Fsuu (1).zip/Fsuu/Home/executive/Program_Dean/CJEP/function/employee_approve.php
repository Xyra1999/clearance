<?php  

	require "../../../../../connector/connect.php";


	$request = $_REQUEST;

	$col = array(
		0	=>	'account_info_id',
		1	=>	'purpose',
		2	=>	'emplo_fname',
		3	=>	'emplo_idnumber',
		4	=>	'email',
		5	=>	'account_info_id',
	);

	$sql = "SELECT stats.program_dean,account_info_id,stats.tbl_employee_id,stats.purpose,account.email,employee.emplo_fname,employee.emplo_mname,employee.emplo_lname,employee.emplo_idnumber FROM tbl_employee_status as stats JOIN account_type as account ON stats.tbl_employee_account_fk = account.account_info_id JOIN tbl_employee as employee ON employee.emplo_account_fk = account.account_info_id WHERE stats.program_dean IN (1) AND stats.department_name ='Criminology Program' AND stats.purpose IN('SEPARATION','GRADING')";

	$query = mysqli_query($conn,$sql);

	$totalData = mysqli_num_rows($query);

	$filter = $totalData;

	$sql ="SELECT stats.program_dean,account_info_id,stats.tbl_employee_id,stats.purpose,account.email,employee.emplo_fname,employee.emplo_mname,employee.emplo_lname,employee.emplo_idnumber FROM tbl_employee_status as stats JOIN account_type as account ON stats.tbl_employee_account_fk = account.account_info_id JOIN tbl_employee as employee ON employee.emplo_account_fk = account.account_info_id WHERE 1=1 AND stats.program_dean IN (1) AND stats.department_name ='Criminology Program' AND stats.purpose IN('SEPARATION','GRADING')";
	if(!empty($request['search']['value'])){
	    $sql.=" AND (account.account_info_id Like '".$request['search']['value']."%' ";
	    $sql.=" OR stats.purpose Like '".$request['search']['value']."%' ";
	    $sql.=" OR employee.emplo_fname Like '".$request['search']['value']."%' ";
	    $sql.=" OR employee.emplo_idnumber Like '".$request['search']['value']."%' ";
	    $sql.=" OR account.email Like '".$request['search']['value']."%' ";
	    $sql.=" OR account.account_info_id Like '".$request['search']['value']."%' )";
	}

	$query = mysqli_query($conn,$sql);
	$totalData = mysqli_num_rows($query);

	$sql.=" ORDER BY ".$col[$request['order'][0]['column']]."   ".$request['order'][0]['dir']."  LIMIT ".
    $request['start']."  ,".$request['length']."  ";

	$query = mysqli_query($conn,$sql);

	$data = array();

	while ($row = mysqli_fetch_array($query)) {

		$btn = $row[0] == 0 ? "<button class='btn btn-sm btn-primary' value='".$row[2]."' id='view'>View</button>
	    	<button class='btn btn-sm btn-success' value='".$row[2]."' id='employee_approved'>Approved<span class='d-none purpose'>".$row[2]."</span></button>
	    	<button class='btn btn-sm btn-secondary' value='".$row[2]."' id='search_data'>Deficiency</button>" : "<button class='btn btn-sm btn-primary' value='".$row[2]."' id='view'>View</button> <button class='btn btn-sm btn-secondary' id='undo-employee' value='".$row[2]."'>Undo</button>";

	    	$idnum = "<span id='idnum'>".$row[8]."</span>";
	    	$purpose = "<span id='purpose'>".$row[3]."</span>";

	    $subdata = array();
	    $subdata[] = $row[2];
	    $subdata[] = "$purpose";
	    $subdata[] = $row[4];
	    $subdata[] = $row[5]." ".$row[6]." ".$row[7];
	    // $subdata[] = $row[2];
	    $subdata[] = "$idnum";
	    $subdata[] = "
	    	$btn
	    ";
	    $data[] = $subdata;
	}

	$json_data=array(
	    "draw"              =>  intval($request['draw']),
	    "recordsTotal"      =>  intval($totalData),
	    "recordsFiltered"   =>  intval($filter),
	    "data"              =>  $data
	);

	echo json_encode($json_data);

?>