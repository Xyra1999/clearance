$(document).ready(function(){
	$('#applicant').change(function(){
		var text = $(this).val();

		if (text == "Employee") {
			window.location = "employee"
		}
		else{
			window.location = "student"
		}
	});

    $('#data-clear').change(function(event) {
        /* Act on the event */
        var text = $(this).val();

        if (text == "Employee") {
            window.location = "clear-employee"
        }
        else{
            window.location = "clear-student"
        }
    });

	$(document).on('click', '#approve', function(event) {
        event.preventDefault();
        var id = $(this).attr('value');
        console.log(id);

        $.ajax({
            url: "function/update",
            type: "POST",
            data:{
                "update_status" : true,
                id:id,
            },
            success:function(response){
                console.log(response);
                if (response == 1) {
                    console.log("done");
                }
                else{

                }
            }
        });
    });

    $(document).on('click', '#employee_approved', function(event) {
        event.preventDefault();
        var id = $(this).attr('value');
        

        $.ajax({
            url: "function/update",
            type: "POST",
            data:{
                "employee_update" : true,
                id:id,
        
         
            },
            success:function(response){
                console.log(response);
                if (response == 1) {
                    // console.log("done");
                }
                else if (response == 3) {
                    $('.modal_inc').addClass('bg-status');
                    $('#approve_inc').attr('value',id);
                    $('#approved_without').attr('value',id);
                }
                else{

                }
            }
        });
    });

    $('#approve_inc').click(function(event) {
        var id = $(this).attr('value');

        $.ajax({
            url: "function/update",
            type: "POST",
            data: {
                "employee_with_inc" : true,
                id:id,
            },
            success:function(response){
                if (response == 1) {
                    setTimeout(function(){
                        $('.modal_inc').removeClass('bg-status');
                    },1500);
                    setTimeout(function(){
                        alertify.success('Update Status');
                    },2000);
                    setTimeout(function(){
                        window.location ="employee";
                    },2500)
                }
                else{

                }
            }
        });  
    });

    $('#approved_without').click(function(event) {
        var id = $(this).attr('value');

        $.ajax({
            url: "function/update",
            type: "POST",
            data: {
                "employee_without_inc" : true,
                id:id,
            },
            success:function(response){
                if (response == 1) {
                    setTimeout(function(){
                        $('.modal_inc').removeClass('bg-status');
                    },1500);
                    setTimeout(function(){
                        alertify.success('Update Status');
                    },2000);
                    setTimeout(function(){
                        window.location ="employee";
                    },2500)
                }
                else{

                }
            }
        }); 
    });

    $('#close_modal_inc').click(function(event) {
        /* Act on the event */
         $('.modal_inc').removeClass('bg-status');
    });

    $('#approved_msg').click(function(event) {
        
        var id = $(this).prop('value');


        $.ajax({
            url: "function/update",
            type: "POST",
            data: {
                "approve_deficiency" : true,
                id:id,
            },
            success:function(response){
                if (response == 1) {
                    setTimeout(function(){
                        $('.modal_box').removeClass('bg-active');
                        alertify.success("Send Deficiency");
                    },2000)
                    setTimeout(function(){
                        window.location = "employee";
                    },2500);
                }
                else{
                    setTimeout(function(){
                        $('.modal_box').removeClass('bg-active');
                        alertify.error("Failed To Update");
                    },2000)
                    
                }
            }
        });

    });

    // Searrch data
    $(document).on('click', '#search_data', function(event) {
        event.preventDefault();
        var id = $(this).attr('value');
        var purpose = $("#example").find("td").eq(1).html();
        // console.log(id);
        var approve_id = $('#employee_approved').attr('value'); 
        
        //$('.modal_box').addClass('bg-active');

        $.ajax({
            url: "function/update",
            type: "POST",
            data:{
                "search" : true,
                id:id,
                purpose:purpose,
            },
            success:function(response){
                console.log(response);
                if (response == 2) {

                }
                else{
                    $.each(response, function(index, val) {
                         $('.reply_modal').addClass('bg-active');
                         $('#status_id').prop('value',val['tbl_employee_id']);                        
                         $('#email').prop('value',val['email']);
                         $('#employee_deficiency').attr('value',val['account_info_id']);
                    });
                }
            }
        });
        /* Act on the event */
    });
    $('#close_modal_msg').click(function(event) {
        /* Act on the event */
        $('.reply_modal').removeClass('bg-active');
    });

    $('#close_modal').click(function(event) {
        /* Act on the event */
        $('.modal_box').removeClass('bg-active');
        $('#applicant_email').val('');
        $('#msg').val('');
        $('#applicant_reply').val('');

    });

    $(document).on('click', '#message_view', function(event) {
        event.preventDefault();
        var id = $(this).attr('value');

        $('.reply_modal').addClass('bg-active');

        $.ajax({
            url: "function/update",
            type: "POST",
            data: {
                "msg_view" : true,
                id:id,
            },
            success:function(response){
                if (response == 2) {

                }
                else{
                    $.each(response, function(index, val) {
                        console.log(val['reply_msg']);
                    });
                }
            }
        });
    });

    $(document).on('click', '#employee_deficiency', function(event) {
        event.preventDefault();
        var id = $(this).attr('value');
        var msg = $('#office_msg').val();
        var purpose = $("#example").find("td").eq(1).html(); 
        var status_id = $('#status_id').val();



        $.ajax({
            url: "function/update",
            type: "POST",
            data:{
                "employee_deficiency" : true,
                id:id,
                msg:msg,
                purpose:purpose,
                status_id:status_id,
            },
            success:function(response){
                if (response == 1) {
                    setTimeout(function(){
                        $('.reply_modal').removeClass('bg-active');
                        $('#office_msg').text('')
                        alertify.success("Send Deficiency");
                    },2000)
                    
                }
                else{
                    setTimeout(function(){
                        $('.reply_modal').removeClass('bg-active');
                        $('#office_msg').text('')
                        alertify.error("Failed To Send");
                    },2000)
                    
                }
            }
        });
    });

    $('#status-modal-close').click(function(event) {
        /* Act on the event */
        $('.status-modal').removeClass('bg-status');
    });

    $(document).on('click','#employee_with_inc',function(event){
        var id = $(this).attr('value');

        $.ajax({
            url: "function/update",
            type: "POST",
            data:{
                "approve_with_inc" : true,
                id:id,
            },
            success:function(response){
                console.log(response);
                if (response == 1) {
                     setTimeout(function(){
                        alertify.success("Send Deficiency");
                    },2000);
                     setTimeout(function(){
                        window.location = "clear-employee";
                     },2500);
                }
                else{

                }
            }
        });
    });

    $(document).on('click','#update_status_inc',function(event){
        var id = $(this).attr('value');

        $.ajax({
            url: "function/update",
            type: "POST",
            data: {
                "update_with_inc" : true,
                id:id,
            },
            success:function(response){
                if (response == 1) {

                }
                else{

                }
            }
        });
    });

    $(document).on('click', '#view', function(event) {
        event.preventDefault();
        var id = $(this).prop('value');

        $.ajax({
            url: "function/search",
            type: "POST",
            data: {
                "search_data" : true,
                id:id,
            },
            success:function(response){
                $('#status tbody').empty();
                if (response == 2) {

                }
                else{
                    $.each(response, function(index, val) {
                        
                    $('.status-modal').addClass('bg-status');

                      var regis = val['registrar']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['registrar'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var library = val['library']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['library'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var pmo = val['pmo']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['pmo'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var bookstore = val['bookstore']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['bookstore'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var itsd = val['ITSD']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['ITSD'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var comproller = val['Comptroller']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['Comptroller'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var guidance = val['Guidance']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['Guidance'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var graduate = val['Graduate_Studies']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['Graduate_Studies'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var hrmd = val['HRMD']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['HRMD'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var vp_asa = val['vp_asa']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['vp_asa'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var President = val['president']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['president'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";

                        if (val['purpose'] == "PERAA") {
                            $('.data-employee').append('<tr class="text-center">'+
                                    '<td>Registrar Office</td>'+
                                    '<td>'+regis+'</td>'+
                                '</tr>'+
                                '<tr class="text-center">'+
                                    '<td>College Librarian</td>'+
                                    '<td>'+library+'</td>'+
                                '</tr>'+
                                '<tr class="text-center">'+
                                    '<td>Property and Maintenance Office</td>'+
                                    '<td>'+pmo+'</td>'+
                                '</tr>'+
                                '<tr class="text-center">'+
                                    '<td>Bookstore/Auxilliary Resource Services</td>'+
                                    '<td>'+bookstore+'</td>'+
                                '</tr>'+
                                '<tr class="text-center">'+
                                    '<td>ITSD</td>'+
                                    '<td>'+itsd+'</td>'+
                                '</tr>'+
                                '<tr class="text-center">'+
                                    '<td>Comptroller</td>'+
                                    '<td>'+comproller+'</td>'+
                                '</tr>'+
                                '<tr class="text-center">'+
                                    '<td>Guidance Office</td>'+
                                    '<td>'+guidance+'</td>'+
                                '</tr>'+
                                '<tr class="text-center">'+
                                    '<td>Graduate Studies and Research</td>'+
                                    '<td>'+graduate+'</td>'+
                                '</tr>'+
                                '<tr class="text-center">'+
                                    '<td>HRMD (Director)</td>'+
                                    '<td>'+hrmd+'</td>'+
                                '</tr>'+
                                '<tr class="text-center">'+
                                    '<td>Administrative Student Affairs (VP-ASA)</td>'+
                                    '<td>'+vp_asa+'</td>'+
                                '</tr>'+
                                '<tr class="text-center">'+
                                    '<td>University President</td>'+
                                    '<td>'+President+'</td>'+
                                '</tr>');
                            }
                            else if (val['purpose'] == "GRADING") {
                                 var regis = val['registrar']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['registrar'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var library = val['library']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['library'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var pmo = val['pmo']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['pmo'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var bookstore = val['bookstore']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['bookstore'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var chair = val['Department_chair']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['Department_chair'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     //var comproller = val['Comptroller']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var program_dean = val['program_dean']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['program_dean'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     //var arts = val['asp_dean']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var hrmd = val['HRMD']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['HRMD'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var vp_aar = val['vp_aar']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['vp_aar'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";

                                $('.data-employee').append('<tr class="text-center">'+
                                    '<td>Registrar Office</td>'+
                               

                                    '<td>'+regis+'</td>'+
                                '</tr>'+
                                '<tr class="text-center">'+
                                    '<td>College Librarian</td>'+
                                   
                                    '<td>'+library+'</td>'+
                                '</tr>'+
                                '<tr class="text-center">'+
                                    '<td>Property and Maintenance Office</td>'+
                                  
                                    '<td>'+pmo+'</td>'+
                                '</tr>'+
                                '<tr class="text-center">'+
                                    '<td>Bookstore/Auxilliary Resource Services</td>'+
                                    
                                    '<td>'+bookstore+'</td>'+
                                '</tr>'+
                                '<tr class="text-center">'+
                                    '<td>Department (Chairperson)</td>'+
                                    
                                    '<td>'+chair+'</td>'+
                                '</tr>'+
                                '<tr class="text-center">'+
                                    '<td>Program Dean</td>'+
                                    
                                    '<td>'+program_dean+'</td>'+
                                '</tr>'+
                                '<tr class="text-center">'+
                                    '<td>HRMD (Director)</td>'+
                                    
                                    '<td>'+hrmd+'</td>'+
                                '</tr>'+
                                '<tr class="text-center">'+
                                    '<td>Academic Affairs and Research (VP-AAR)</td>'+
                                    
                                    '<td>'+vp_aar+'</td>'+
                                '</tr>');
                            }
                            else{
                                 var regis = val['registrar']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                                 var library = val['library']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                                 var pmo = val['pmo']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                                 var bookstore = val['bookstore']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                                 var itsd = val['ITSD']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                                 var comproller = val['Comptroller']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                                 var program_dean = val['program_dean']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                                 var arts = val['asp_dean']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                                 var hrmd = val['HRMD']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                                 var vp_aar = val['vp_aar']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                                 var Cashier = val['Cashier']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                            $('.data-employee').append('<tr class="text-center">'+
                                        '<td>Registrar Office</td>'+
                                        '<td><button class="btn btn-sm btn-primary">View Requirements</button></td>'+
                                        '<td><button class="btn btn-sm btn-primary"><i class="fas fa-envelope"></i></button></td>'+

                                        '<td>'+regis+'</td>'+
                                    '</tr>'+
                                    '<tr class="text-center">'+
                                        '<td>College Librarian</td>'+
                                        '<td><button class="btn btn-sm btn-primary">View Requirements</button></td>'+
                                        '<td><button class="btn btn-sm btn-primary"><i class="fas fa-envelope"></i></button></td>'+
                                        '<td>'+library+'</td>'+
                                    '</tr>'+
                                    '<tr class="text-center">'+
                                        '<td>Property and Maintenance Office</td>'+
                                        '<td><button class="btn btn-sm btn-primary">View Requirements</button></td>'+
                                        '<td><button class="btn btn-sm btn-primary"><i class="fas fa-envelope"></i></button></td>'+
                                        '<td>'+pmo+'</td>'+
                                    '</tr>'+
                                    '<tr class="text-center">'+
                                        '<td>Bookstore/Auxilliary Resource Services</td>'+
                                        '<td><button class="btn btn-sm btn-primary">View Requirements</button></td>'+
                                        '<td><button class="btn btn-sm btn-primary"><i class="fas fa-envelope"></i></button></td>'+
                                        '<td>'+bookstore+'</td>'+
                                    '</tr>'+
                                    '<tr class="text-center">'+
                                        '<td>ITSD</td>'+
                                        '<td><button class="btn btn-sm btn-primary">View Requirements</button></td>'+
                                        '<td><button class="btn btn-sm btn-primary"><i class="fas fa-envelope"></i></button></td>'+
                                        '<td>'+itsd+'</td>'+
                                    '</tr>'+
                                    '<tr class="text-center">'+
                                        '<td>Comptroller</td>'+
                                        '<td><button class="btn btn-sm btn-primary">View Requirements</button></td>'+
                                        '<td><button class="btn btn-sm btn-primary"><i class="fas fa-envelope"></i></button></td>'+
                                        '<td>'+comproller+'</td>'+
                                    '</tr>'+
                                    '<tr class="text-center">'+
                                        '<td>Program Dean</td>'+
                                        '<td><button class="btn btn-sm btn-primary">View Requirements</button></td>'+
                                        '<td><button class="btn btn-sm btn-primary"><i class="fas fa-envelope"></i></button></td>'+
                                        '<td>'+program_dean+'</td>'+
                                    '</tr>'+
                                    '<tr class="text-center">'+
                                        '<td>Dean Art and Science</td>'+
                                        '<td><button class="btn btn-sm btn-primary">View Requirements</button></td>'+
                                        '<td><button class="btn btn-sm btn-primary"><i class="fas fa-envelope"></i></button></td>'+
                                        '<td>'+arts+'</td>'+
                                    '</tr>'+
                                    '<tr class="text-center">'+
                                        '<td>Cashier</td>'+
                                        '<td><button class="btn btn-sm btn-primary">View Requirements</button></td>'+
                                        '<td><button class="btn btn-sm btn-primary"><i class="fas fa-envelope"></i></button></td>'+
                                        '<td>'+Cashier+'</td>'+
                                    '</tr>'+
                                    '<tr class="text-center">'+
                                        '<td>HRMD (Director)</td>'+
                                        '<td><button class="btn btn-sm btn-primary">View Requirements</button></td>'+
                                        '<td><button class="btn btn-sm btn-primary"><i class="fas fa-envelope"></i></button></td>'+
                                        '<td>'+hrmd+'</td>'+
                                    '</tr>'+
                                    '<tr class="text-center">'+
                                        '<td>Academic Affairs and Research (VP-AAR)</td>'+
                                        '<td><button class="btn btn-sm btn-primary">View Requirements</button></td>'+
                                        '<td><button class="btn btn-sm btn-primary"><i class="fas fa-envelope"></i></button></td>'+
                                        '<td>'+vp_aar+'</td>'+
                                    '</tr>');
                            }
                
                    });
                }
            }
        });

    });





    // Student Function

    $(document).on('click', '#defiency', function(event) {
        event.preventDefault();
        var id = $(this).prop('value');

        // console.log(id);

        $.ajax({
            url: "function/update",
            type: "POST",
            data: {
                "student_search" : true,
                id:id,
            },
            success:function(response){
                // console.log(response);
                if (response == 2) {

                }
                else{
                     $.each(response, function(index, val) {
                        // console.log(val['email']);
                         $('.modal-defiency').addClass('bg-status');
                         $('#status_id').prop('value',val['student_info_id']);
                         $('#student_id').prop('value',val['student_info_id'])                        
                         $('#email').prop('value',val['email']);
                         $('#student-deficiency').attr('value',val['account_info_id']);
                    });
                }
            }
        });


        /* Act on the event */
    });

    $('#close-student').click(function(event) {
        /* Act on the event */
        $('.modal-defiency').removeClass('bg-status');
    });


    $('#student-deficiency').click(function(event) {
        /* Act on the event */
        var id = $(this).prop('value');
        var msg = $('#office_msg').val();
        var student_info_id = $('#student_id').val();

        $.ajax({
            url: "function/update",
            type: "POST",
            data: {
                "send_student" : true,
                id:id,
                msg:msg,
                student_info_id:student_info_id,
            },
            success:function(response){
                console.log(response);
                if (response == 1) {
                    setTimeout(function(){
                        $('.modal-defiency').removeClass('bg-status');
                        $('#office_msg').text('')
                        alertify.success("Send Deficiency");
                    },2000)
                }
                else{
                    setTimeout(function(){
                       $('.modal-defiency').removeClass('bg-status');
                        $('#office_msg').text('')
                        alertify.success("Send Deficiency");
                    },2000)
                }
            }
        });
        
    });

    $('#status-modal-close-student').click(function(event){
        $('.status-modal-student').removeClass('bg-status');
    })

    $(document).on('click','#view-student',function(event){

        var id = $(this).attr('value');

        $.ajax({
            url: "function/search",
            type: "POST",
            data: {
                "student_search" : true,
                id:id,
            },
            success:function(response){

                $('#status .data-student').empty();
                if (response == 2) {

                }
                else{
                    $.each(response,function(index,val){

                        $('.status-modal-student').addClass('bg-status');

                        var admis = val['admission']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                        var ces = val['ces']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                        var guidance = val['guidance']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                        var ora = val['ora']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                        var dsa = val['dsa']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                        var dao = val['dao']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                        var program_dean = val['program_dean']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                        var record_incharge = val['record_incharge']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                        var veritas = val['veritas']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                        var cashier = val['cashier']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                        var registrar = val['registrar']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";

                    $('.data-student').append('<tr>'+
                            '<td class="text-center">Admission and Scholarship</td>'+
                           
                            '<td class="text-center">'+admis+'</td>'+
                            '</tr>'+

                            '<tr>'+
                        '<td class="text-center">CES Office</td>'+
                      
                        '<td class="text-center"> '+ces+' </td>'+
                        '</tr>'+
                        '<tr>'+
                        '<td class="text-center">Guidance Office</td>'+
                       
                        '<td class="text-center"> '+guidance+' </td>'+
                        '</tr>'+
                        '<tr>'+
                        '<td class="text-center">Office Religious Affairs</td>'+
                      
                        '<td class="text-center"> '+ora+'</td>'+
                        '</tr>'+
                        '<tr>'+
                        '<td class="text-center">DSA Office</td>'+
                     
                        '<td class="text-center"> '+dsa+' </td>'+
                        '</tr>'+
                        '<td class="text-center">VERITAS</td>'+
                     
                        '<td class="text-center"> '+veritas+'</td>'+
                        '</tr>'+
                        '<td class="text-center">DAO</td>'+
                       
                        '<td class="text-center"> '+dao+'</td>'+
                        '</tr>'+
                        '<td class="text-center">Cashier</td>'+
                        
                        '<td class="text-center"> '+cashier+'</td>'+
                        '</tr>'+
                        '<td class="text-center">Program Dean</td>'+
                      
                        '<td class="text-center"> '+program_dean+'</td>'+
                        '</tr>'+
                        '<td class="text-center">Records incharge</td>'+
                        
                        '<td class="text-center"> '+record_incharge+'</td>'+
                        '</tr>'+
                        '<td class="text-center">Registrar Office</td>'+
                       
                        '<td class="text-center"> '+registrar+'</td>'+
                        '</tr>');
                    });
                }
            }
        });

    });

    
    $(document).on('click', '#undo_status', function(event) {
        event.preventDefault();

        var id = $(this).attr('value');

        $.ajax({
            url: "function/update",
            type: "POST",
            data: {
                "undo_status" : true,
                id:id,
            },
            success:function(response){
                if (response == 1) {
                     setTimeout(function(){
                        alertify.success("Undo Status");
                    },1500);
                     setTimeout(function(){
                        window.location = "clear-employee";
                     },2000);
                }
                else{

                }
            }
        });

        /* Act on the event */
    });


    
});