<?php   
	session_start();
	unset($_SESSION['vp_asa']); 
	header("location: ../../../index"); 
	exit();
?>