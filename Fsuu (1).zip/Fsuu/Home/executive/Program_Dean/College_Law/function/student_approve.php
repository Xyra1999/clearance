<?php  

	require "../../../../../connector/connect.php";


	$request = $_REQUEST;

	$col = array(
		0	=>	'student_info_id',
		1	=>	'fname',
		2	=>	'idnumber',
		3	=>	'email',
		4	=>	'student_info_id',
	);

	$sql = "SELECT stats.program_dean,stats.student_info_id,account.email,student.idnumber,student.fname,student.mname,student.lname FROM tbl_student_status as stats JOIN account_type as account ON stats.tbl_account_fk = account.account_info_id JOIN tbl_student as student ON student.account_student_fk = account.account_info_id WHERE stats.program_dean IN (1) AND department_name ='College of Law Program'";

	$query = mysqli_query($conn,$sql);

	$totalData = mysqli_num_rows($query);

	$filter = $totalData;

	$sql ="SELECT stats.program_dean,stats.student_info_id,account.email,student.idnumber,student.fname,student.mname,student.lname FROM tbl_student_status as stats JOIN account_type as account ON stats.tbl_account_fk = account.account_info_id JOIN tbl_student as student ON student.account_student_fk = account.account_info_id WHERE 1=1 AND stats.program_dean IN (1) AND department_name ='College of Law Program'";
	if(!empty($request['search']['value'])){
	    $sql.=" AND (stats.student_info_id Like '".$request['search']['value']."%' ";
	    $sql.=" OR student.fname Like '".$request['search']['value']."%' ";
	    $sql.=" OR student.idnumber Like '".$request['search']['value']."%' ";
	    $sql.=" OR account.email Like '".$request['search']['value']."%' ";
	    $sql.=" OR stats.student_info_id Like '".$request['search']['value']."%' )";
	}

	$query = mysqli_query($conn,$sql);
	$totalData = mysqli_num_rows($query);

	$sql.=" ORDER BY ".$col[$request['order'][0]['column']]."   ".$request['order'][0]['dir']."  LIMIT ".
    $request['start']."  ,".$request['length']."  ";

	$query = mysqli_query($conn,$sql);

	$data = array();

	while ($row = mysqli_fetch_array($query)) {

		$btn = $row[0] == 0 ? "<button class='btn btn-sm btn-primary' value='".$row[1]."' id='view-student'>View</button>
	    	<button class='btn btn-sm btn-success' value='".$row[1]."' id='approve'>Approved</button>
	    	<button class='btn btn-sm btn-secondary' value='".$row[1]."' id='defiency'>Deficiency</button>" : "<button class='btn btn-sm btn-primary' value='".$row[1]."' id='view-student'>View</button> <button class='btn btn-sm btn-secondary' id='undo-student' value='".$row[1]."'>Undo</button>";

	    $subdata = array();
	    $subdata[] = $row[1];
	    $subdata[] = $row[3];
	    $subdata[] = $row[4]." ".$row[5]." ".$row[6];
	    $subdata[] = $row[2];
	    // $subdata[] = $row[1];
	    $subdata[] = "
	    $btn

	    ";
	    $data[] = $subdata;
	}

	$json_data=array(
	    "draw"              =>  intval($request['draw']),
	    "recordsTotal"      =>  intval($totalData),
	    "recordsFiltered"   =>  intval($filter),
	    "data"              =>  $data
	);

	echo json_encode($json_data);

?>