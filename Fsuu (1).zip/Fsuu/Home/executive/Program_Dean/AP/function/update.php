<?php  

	require "../../../../../connector/connect.php";

	if (isset($_POST['employee_update'])) {

		$id = mysqli_real_escape_string($conn,$_POST['id']);
		
		$sql = "UPDATE tbl_employee_status SET program_dean = 1 WHERE tbl_employee_id = $id";

		if (mysqli_query($conn,$sql) === TRUE) {
			echo 1;		
		}
	}
	else if (isset($_POST['undo_employee'])) {
		$id = mysqli_real_escape_string($conn,$_POST['id']);
		
		$sql = "UPDATE tbl_employee_status SET program_dean = 0 WHERE tbl_employee_id = $id";

		if (mysqli_query($conn,$sql) === TRUE) {
			echo 1;		
		}
	}
	else if (isset($_POST['student_search'])) {
		$id = mysqli_real_escape_string($conn,$_POST['id']);



		$search = "SELECT *FROM tbl_student_status WHERE student_info_id = $id";

		$result_val = [];
		$result_q = mysqli_query($conn,$search);
		if (mysqli_num_rows($result_q) > 0) {
			foreach ($result_q as $value) {
			    array_push($result_val,$value);
			}
			header("Content-type: application/json");
			echo json_encode($result_val);

		}
		else{
			echo 2;
		}
	}
	else if (isset($_POST['update_status'])) {
		$id = mysqli_real_escape_string($conn,$_POST['id']);

		$sql = "UPDATE tbl_student_status SET program_dean = 1 WHERE student_info_id = $id";

		if (mysqli_query($conn,$sql) === TRUE) {
			echo 1;
		}
	}
	else if (isset($_POST['undo_student'])) {
		$id = mysqli_real_escape_string($conn,$_POST['id']);

		$sql = "UPDATE tbl_student_status SET program_dean = 0 WHERE student_info_id = $id";

		if (mysqli_query($conn,$sql) === TRUE) {
			echo 1;
		}
	}

?>