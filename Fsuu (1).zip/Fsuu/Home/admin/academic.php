<?php  


	session_start();

	if ($_SESSION['admin']) {
		require "../../connector/connect.php";
		$email = $_SESSION['admin'];

		$find = "SELECT *from account_type WHERE email ='$email'";

		$result = mysqli_query($conn,$find);

	    if (mysqli_num_rows($result) > 0) {
	        while ($row = mysqli_fetch_assoc($result)) {
	            $u_email = $row['email'];
	            $id = $row['account_info_id'];
	            Data($u_email,$id);
	            break;
	        }
    	}
	}
	else{
		header("location: ../../index");
		exit();
	}

?>

<?php  

	function Data($u_email,$id){
		require "../../connector/connect.php";

		$search = "SELECT *FROM account_type as account JOIN account_info as info ON account.account_info_id = info.account_type_fk WHERE account.email = '$u_email'";

		$result = mysqli_query($conn,$search);

	    if (mysqli_num_rows($result) > 0) {
	        while ($row = mysqli_fetch_assoc($result)) {
	            $u_email = $row['email'];
	            $fname = $row['fname'];
	            $mname = $row['mname'];
	            $lname = $row['lname'];
	            Display($u_email,$fname,$mname,$lname);
	            break;
	        }
    	}

	}
?>

<?php  

	function Display($u_email,$fname,$mname,$lname){
		?>

			<!DOCTYPE html>
			<html>
			<head>
				<meta charset="utf-8">
				<meta http-equiv="X-UA-Compatible" content="IE=edge">
				<link href="../../assets/css/bootstrap.min.css" rel="stylesheet">
				<link rel="stylesheet" href="../../assets/css/style.css">
				<link href="../../assets/icon/fsuu.png" rel="icon">
				<link href="../../assets/css/alertify.css" rel="stylesheet">
    			<link href="../../assets/css/alertify.min.css" rel="stylesheet">
				<title>Father Saturnino Urios University</title>
			</head>
			<body>


			<!-- header -->
			<nav class="navbar navbar-default banner-color">
			  <div class="container-fluid">
			    <a href="index"><img src="../../assets/image/plain.png" alt="" height="100" width="200" class="img-fluid rounded"></a>
			    <div class="d-flex">
			      <div class="row">
			      	<div class="list">
			      		<ul>
			      			<li><span class="text-light fw-bold">Super Admin</span></li>
			      			<li><span class="text-light fw-bold"><?php echo $fname." ".$lname; ?></span></li>
			      			<li><a class="text-light fw-bold" href="logout"><i class="fas fa-power-off"></i></a></li>
			      		</ul>
			      	</div>
			      </div>
			    </div>
			  </div>
			</nav>
			<div class="color-header">
				<div class="container">
					<div class="inside-header">
						<ul>
							<li><a href="add" class="text-secondary">Add Admin</a></li>
							<li><a class="text-secondary" href="progress">Progess</a></li>
							<li><a class="text-primary fw-bold" href="academic">Set Academic Year</a></li>
							<li><a class="text-secondary" href="clearance">Clearance Cleared</a></li>
							<li><a class="text-secondary" href="report">Logs</a></li>
							<li><a class="text-secondary" href="add_department">Add Department & Course</a></li>
							<li><a class="text-secondary" href="display">Display Data</a></li>
							<li><a class="text-secondary" href="import">Import CSV</a></li>
						</ul>
					</div>
				</div>
			</div>
			<!-- end of header -->


			<div class="mt-4">
				<div class="container">
					<div class="modal-dialog">
						<div class="modal-content">
							<div class="modal-header banner">
								<div class="modal-title text-light">
									Add Admin
								</div>
							</div>

							<!-- modal body -->
							<div class="modal-body">
								<div class="row">
									<div class="col-md-6">
										<label for="" class="form-label">
											Current School Year
										</label>
										<input type="text" class="form-control" id="sy" disabled>
									</div>
									<div class="col-md-6">
										<label for="" class="form-label">
											Semester
										</label>
										<input type="text" class="form-control" id="sem" disabled>
									</div>
									<div class="col-md-6">
										<label for="" class="form-label">
											New Semester
										</label>
										<input type="text" class="form-control" id="new_sy">
									</div>
									<div class="col-md-6">
										<label for="" class="form-label">
											Semester
										</label>
										<select name="" id="new_sem" class="form-select">
											<option value="1st">1st</option>
											<option value="2nd">2nd</option>
											<option value="Summer">Summer</option>
										</select>
									</div>
								</div>
							</div>
							<!-- end of modal body -->
							<div class="modal-footer">
								<button class="btn btn-primary btn-sm" id="set_academic">Set Academic Year</button>
							</div>
						</div>
					</div>
				</div>
			</div>

		<?php
	}

?>



	<script type="text/javascript" src="../../assets/js/fontawesome.js"></script>
	<script type="text/javascript" src="../../assets/js/jquery-3.4.1.min.js"></script>
	<script src="../../assets/js/alertify.js"></script>
    <script src="../../assets/js/alertify.min.js"></script>
	<script src="js/admin.js"></script>

</body>
</html>