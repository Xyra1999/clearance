<?php  


	require "../../../../connector/connect.php";

	if (isset($_POST['search_data'])) {
		# code...

		$id = mysqli_real_escape_string($conn,$_POST['id']);

		$search = "SELECT *FROM tbl_student_status WHERE student_info_id = $id";

		$result_val = [];
		$result_q = mysqli_query($conn,$search);
		if (mysqli_num_rows($result_q) > 0) {
			foreach ($result_q as $value) {
			    array_push($result_val,$value);
			}
			header("Content-type: application/json");
			echo json_encode($result_val);

		}
		else{
			echo 2;
		}
	}
	else if (isset($_POST['search_employee'])) {

		$id = mysqli_real_escape_string($conn,$_POST['id']);

		$search = "SELECT *FROM tbl_employee_status WHERE tbl_employee_id = $id";

		$result_val = [];
		$result_q = mysqli_query($conn,$search);
		if (mysqli_num_rows($result_q) > 0) {
			foreach ($result_q as $value) {
			    array_push($result_val,$value);
			}
			header("Content-type: application/json");
			echo json_encode($result_val);

		}
		else{
			echo 2;
		}
		# code...
	}


?>