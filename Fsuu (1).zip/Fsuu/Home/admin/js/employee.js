$(document).ready(function(event){

	$(document).on('click', '#view', function(event) {
		event.preventDefault();
        var id = $(this).prop('value');

        $.ajax({
            url: "function/search",
            type: "POST",
            data: {
                "search_data" : true,
                id:id,
            },
            success:function(response){
                $('#status tbody').empty();
                if (response == 2) {

                }
                else{
                    $.each(response, function(index, val) {
                        
                    $('.status-modal').addClass('bg-status');

                      var regis = val['registrar']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['registrar'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : val['registrar'] == 3 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Approve W/ INC</span>" :"<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var library = val['library']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['library'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var pmo = val['pmo']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['pmo'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var bookstore = val['bookstore']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['bookstore'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var itsd = val['ITSD']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['ITSD'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var comproller = val['Comptroller']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['Comptroller'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var guidance = val['Guidance']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['Guidance'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var graduate = val['Graduate_Studies']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['Graduate_Studies'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var hrmd = val['HRMD']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['HRMD'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var vp_asa = val['vp_asa']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['vp_asa'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var President = val['president']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['president'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";

                        if (val['purpose'] == "PERAA") {
                            $('.data-employee').append('<tr class="text-center">'+
                                    '<td>Registrar Office</td>'+
                                    '<td>'+regis+'</td>'+
                                '</tr>'+
                                '<tr class="text-center">'+
                                    '<td>College Librarian</td>'+
                                    '<td>'+library+'</td>'+
                                '</tr>'+
                                '<tr class="text-center">'+
                                    '<td>Property and Maintenance Office</td>'+
                                    '<td>'+pmo+'</td>'+
                                '</tr>'+
                                '<tr class="text-center">'+
                                    '<td>Bookstore/Auxilliary Resource Services</td>'+
                                    '<td>'+bookstore+'</td>'+
                                '</tr>'+
                                '<tr class="text-center">'+
                                    '<td>ITSD</td>'+
                                    '<td>'+itsd+'</td>'+
                                '</tr>'+
                                '<tr class="text-center">'+
                                    '<td>Comptroller</td>'+
                                    '<td>'+comproller+'</td>'+
                                '</tr>'+
                                '<tr class="text-center">'+
                                    '<td>Guidance Office</td>'+
                                    '<td>'+guidance+'</td>'+
                                '</tr>'+
                                '<tr class="text-center">'+
                                    '<td>Graduate Studies and Research</td>'+
                                    '<td>'+graduate+'</td>'+
                                '</tr>'+
                                '<tr class="text-center">'+
                                    '<td>HRMD (Director)</td>'+
                                    '<td>'+hrmd+'</td>'+
                                '</tr>'+
                                '<tr class="text-center">'+
                                    '<td>Administrative Student Affairs (VP-ASA)</td>'+
                                    '<td>'+vp_asa+'</td>'+
                                '</tr>'+
                                '<tr class="text-center">'+
                                    '<td>University President</td>'+
                                    '<td>'+President+'</td>'+
                                '</tr>');
                            }
                            else if (val['purpose'] == "GRADING") {
                                  var regis = val['registrar']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['registrar'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : val['registrar'] == 3 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Approve W/ INC</span>" :"<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var library = val['library']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['library'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var pmo = val['pmo']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['pmo'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var bookstore = val['bookstore']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['bookstore'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var chair = val['Department_chair']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['Department_chair'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     //var comproller = val['Comptroller']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var program_dean = val['program_dean']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['program_dean'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     //var arts = val['asp_dean']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var hrmd = val['HRMD']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['HRMD'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var vp_aar = val['vp_aar']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['vp_aar'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";

                                $('.data-employee').append('<tr class="text-center">'+
                                    '<td>Registrar Office</td>'+
                               

                                    '<td>'+regis+'</td>'+
                                '</tr>'+
                                '<tr class="text-center">'+
                                    '<td>College Librarian</td>'+
                                   
                                    '<td>'+library+'</td>'+
                                '</tr>'+
                                '<tr class="text-center">'+
                                    '<td>Property and Maintenance Office</td>'+
                                  
                                    '<td>'+pmo+'</td>'+
                                '</tr>'+
                                '<tr class="text-center">'+
                                    '<td>Bookstore/Auxilliary Resource Services</td>'+
                                    
                                    '<td>'+bookstore+'</td>'+
                                '</tr>'+
                                '<tr class="text-center">'+
                                    '<td>Department (Chairperson)</td>'+
                                    
                                    '<td>'+chair+'</td>'+
                                '</tr>'+
                                '<tr class="text-center">'+
                                    '<td>Program Dean</td>'+
                                    
                                    '<td>'+program_dean+'</td>'+
                                '</tr>'+
                                '<tr class="text-center">'+
                                    '<td>HRMD (Director)</td>'+
                                    
                                    '<td>'+hrmd+'</td>'+
                                '</tr>'+
                                '<tr class="text-center">'+
                                    '<td>Academic Affairs and Research (VP-AAR)</td>'+
                                    
                                    '<td>'+vp_aar+'</td>'+
                                '</tr>');
                            }
                            else{
                                 var regis = val['registrar']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : val['registrar'] == 2 ? "<span  class='text-light bg-secondary p-2 rounded' style='font-size: 13px;''>Deficiency</span>" : val['registrar'] == 3 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Approve W/ INC</span>" :"<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                                 var library = val['library']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                                 var pmo = val['pmo']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                                 var bookstore = val['bookstore']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                                 var itsd = val['ITSD']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                                 var comproller = val['Comptroller']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                                 var program_dean = val['program_dean']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                                 var arts = val['asp_dean']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                                 var hrmd = val['HRMD']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                                 var vp_aar = val['vp_aar']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                                 var Cashier = val['Cashier']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                            $('.data-employee').append('<tr class="text-center">'+
                                        '<td>Registrar Office</td>'+
                                        

                                        '<td>'+regis+'</td>'+
                                    '</tr>'+
                                    '<tr class="text-center">'+
                                        '<td>College Librarian</td>'+
                                       
                                        '<td>'+library+'</td>'+
                                    '</tr>'+
                                    '<tr class="text-center">'+
                                        '<td>Property and Maintenance Office</td>'+
                                       
                                        '<td>'+pmo+'</td>'+
                                    '</tr>'+
                                    '<tr class="text-center">'+
                                        '<td>Bookstore/Auxilliary Resource Services</td>'+
                                        
                                        '<td>'+bookstore+'</td>'+
                                    '</tr>'+
                                    '<tr class="text-center">'+
                                        '<td>ITSD</td>'+
                                        
                                        '<td>'+itsd+'</td>'+
                                    '</tr>'+
                                    '<tr class="text-center">'+
                                        '<td>Comptroller</td>'+
                                       
                                        '<td>'+comproller+'</td>'+
                                    '</tr>'+
                                    '<tr class="text-center">'+
                                        '<td>Program Dean</td>'+
                                       
                                        '<td>'+program_dean+'</td>'+
                                    '</tr>'+
                                    '<tr class="text-center">'+
                                        '<td>Dean Art and Science</td>'+
                                        
                                        '<td>'+arts+'</td>'+
                                    '</tr>'+
                                    '<tr class="text-center">'+
                                        '<td>Cashier</td>'+
                                       
                                        '<td>'+Cashier+'</td>'+
                                    '</tr>'+
                                    '<tr class="text-center">'+
                                        '<td>HRMD (Director)</td>'+
                                        
                                        '<td>'+hrmd+'</td>'+
                                    '</tr>'+
                                    '<tr class="text-center">'+
                                        '<td>Academic Affairs and Research (VP-AAR)</td>'+
                                        
                                        '<td>'+vp_aar+'</td>'+
                                    '</tr>');
                            }
                
                    });
                }
            }
        });
	});

	$('#status-modal-close').click(function(event) {
		/* Act on the event */
		  $('.status-modal').removeClass('bg-status');
	});

	$(document).on('click','#view-student',function(event){

        var id = $(this).attr('value');

        console.log(id);

        $.ajax({
            url: "function/search",
            type: "POST",
            data: {
                "student_search" : true,
                id:id,
            },
            success:function(response){

                $('#status .data-student').empty();
                if (response == 2) {

                }
                else{
                    $.each(response,function(index,val){

                        $('.status-modal-student').addClass('bg-status');

                        var admis = val['admission']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                        var ces = val['ces']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                        var guidance = val['guidance']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                        var ora = val['ora']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                        var dsa = val['dsa']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                        var dao = val['dao']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                        var program_dean = val['program_dean']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                        var record_incharge = val['record_incharge']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                        var veritas = val['veritas']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                        var cashier = val['cashier']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                        var registrar = val['registrar']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";

                    $('.data-student').append('<tr>'+
                            '<td class="text-center">Admission and Scholarship</td>'+
                           
                            '<td class="text-center">'+admis+'</td>'+
                            '</tr>'+

                            '<tr>'+
                        '<td class="text-center">CES Office</td>'+
                      
                        '<td class="text-center"> '+ces+' </td>'+
                        '</tr>'+
                        '<tr>'+
                        '<td class="text-center">Guidance Office</td>'+
                       
                        '<td class="text-center"> '+guidance+' </td>'+
                        '</tr>'+
                        '<tr>'+
                        '<td class="text-center">Office Religious Affairs</td>'+
                      
                        '<td class="text-center"> '+ora+'</td>'+
                        '</tr>'+
                        '<tr>'+
                        '<td class="text-center">DSA Office</td>'+
                     
                        '<td class="text-center"> '+dsa+' </td>'+
                        '</tr>'+
                        '<td class="text-center">VERITAS</td>'+
                     
                        '<td class="text-center"> '+veritas+'</td>'+
                        '</tr>'+
                        '<td class="text-center">DAO</td>'+
                       
                        '<td class="text-center"> '+dao+'</td>'+
                        '</tr>'+
                        '<td class="text-center">Cashier</td>'+
                        
                        '<td class="text-center"> '+cashier+'</td>'+
                        '</tr>'+
                        '<td class="text-center">Program Dean</td>'+
                      
                        '<td class="text-center"> '+program_dean+'</td>'+
                        '</tr>'+
                        '<td class="text-center">Records incharge</td>'+
                        
                        '<td class="text-center"> '+record_incharge+'</td>'+
                        '</tr>'+
                        '<td class="text-center">Registrar Office</td>'+
                       
                        '<td class="text-center"> '+registrar+'</td>'+
                        '</tr>');
                    });
                }
            }
        });
    });
	

	$('#status-modal-close-student').click(function(event) {
		/* Act on the event */

		 $('.status-modal-student').removeClass('bg-status');
	});
	
});