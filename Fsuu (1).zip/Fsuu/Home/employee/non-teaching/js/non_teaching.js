$(document).ready(function(event){

	$('#clearance_submit').click(function(event){
		var id = $(this).val();
		var text = $('#non_teaching').val();

		$.ajax({
			url: "function/submit",
			type: "POST",
			data: {
				"apply_clearance" : true,
				id:id,
				text:text,
			},
			success:function(response){
				// console.log(response);
				if (response == 1) {
					alertify.success("Clearance Submit");
				}
				else if (response == 2) {
					alertify.notify("Already Submitted");
				}
				else if (response == 3) {
					alertify.notify("Please Choose Purpose");
				}
				else{
					alertify.error("Something went wrong");
				}
			}
		});
	})


	$('#update_profile').click(function(event) {
		var id = $(this).attr('value');

		var fname = $("#fname").val();
		var mname = $("#mname").val();
		var lname = $("#lname").val();

		var load = $('#with_load').val();

		
		
		$.ajax({
			url: "function/submit",
			type: "POST",
			data: {
				"update" : true,
				id:id,
				fname:fname,
				mname:mname,
				lname:lname,
				load:load,
			},
			success:function(response){
				if (response == 1) {
					alertify.success("Profile Updated");
					setTimeout(function(){
						window.location = "profile"
					},2000);
				}
				else{
					alertify.error("Something Went Wrong");
				}
			}
		});
	});

	$('#status_select').change(function(event) {
		var status = $('#status_select').val();

		if (status == "PERAA") {
			window.location = "peraa"
		}
		else if (status == "SEPARATION") {
			window.location = "separation"
		}
		else{
			window.location = "grading"
		}
	});
});