$(document).ready(function(){
	student_load_data();

	setInterval(function(){
		student_load_data();
	},2000);
});

function student_load_data(){

	$.ajax({
		url: "function/student_load",
		cache: false,

		success:function(response){
			$('.row_data').remove();
			if (response == 2) {

			}
			else{
				$.each(response,function(index,val){
					$('.student_data').append('<tr class="row_data">'+
			                '<td>'+val['student_info_id']+'</td>'+
			                '<td>'+val['idnumber']+'</td>'+
			                '<td>'+val['student_info_id']+'</td>'+
			                '<td>'+val['email']+'</td>'+
			                '<td>'+val['student_info_id']+'</td>'+
			                '<td>'+val['student_info_id']+'</td>'+
			                '<td>'+
			                	'<button class="btn btn-sm btn-primary">View</button>'+
			                	'<button class="btn btn-sm btn-success">Approve</button>'+
			                	'<button class="btn btn-sm btn-danger">Message</button>'+
			                	'<button class="btn btn-sm btn-secondary">Deficiency</button>'+
			                '</td>'+
			            '</tr>')
				});
			}
		}
	})
}