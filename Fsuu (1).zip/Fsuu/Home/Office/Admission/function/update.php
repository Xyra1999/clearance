<?php  

	require "../../../../connector/connect.php";


	if (isset($_POST['update_status'])) {
		
		$id = mysqli_real_escape_string($conn,$_POST['id']);

		$sql = "UPDATE tbl_student_status SET admission = 1 WHERE student_info_id = $id";

		if (mysqli_query($conn,$sql) === TRUE) {

			$search = "SELECT *FROM tbl_student_status WHERE student_info_id = $id";

			$result = mysqli_query($conn,$search);

			while ($row = mysqli_fetch_assoc($result)) {
			    $fk = $row['tbl_account_fk'];
			    break;
			}

			$join = "SELECT *FROM account_type as account JOIN tbl_student as student ON account.account_info_id = student.account_student_fk WHERE account.account_info_id = $fk";

			$result_q = mysqli_query($conn,$join);

			while ($rows = mysqli_fetch_assoc($result_q)) {
			    $email = $rows['email'];
			    $sy = $rows['school_year'];
			    $idnum = $rows['idnumber'];
			    break;
			}

			$remark_log = "Approved "." ".$idnum;

			$insert_log = "INSERT INTO tbl_admission_log(idnumber,email,school_year,remark,date_log) VALUES('$idnum','$email','$sy','$remark_log',NOW())";

			if (mysqli_query($conn,$insert_log) === TRUE) {
				echo 1;
			}
		}
	}
	else if (isset($_POST['undo_status'])) {
		$id = mysqli_real_escape_string($conn,$_POST['id']);

		$sql = "UPDATE tbl_student_status SET admission = 0 WHERE student_info_id = $id";

		if (mysqli_query($conn,$sql) === TRUE) {

			$search = "SELECT *FROM tbl_student_status WHERE student_info_id = $id";

			$result = mysqli_query($conn,$search);

			while ($row = mysqli_fetch_assoc($result)) {
			    $fk = $row['tbl_account_fk'];
			    break;
			}

			$join = "SELECT *FROM account_type as account JOIN tbl_student as student ON account.account_info_id = student.account_student_fk WHERE account.account_info_id = $fk";

			$result_q = mysqli_query($conn,$join);

			while ($rows = mysqli_fetch_assoc($result_q)) {
			    $email = $rows['email'];
			    $sy = $rows['school_year'];
			    $idnum = $rows['idnumber'];
			    break;
			}

			$remark_log = "UNDO STATUS "." ".$idnum;

			$insert_log = "INSERT INTO tbl_admission_log(idnumber,email,school_year,remark,date_log) VALUES('$idnum','$email','$sy','$remark_log',NOW())";

			if (mysqli_query($conn,$insert_log) === TRUE) {
				echo 1;
			}
		}
	}


?>