<?php   
	session_start();
	unset($_SESSION['studies']); 
	header("location: ../../../index"); 
	exit();
?>