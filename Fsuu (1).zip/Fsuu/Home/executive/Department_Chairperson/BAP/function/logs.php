<?php  

	require "../../../../../connector/connect.php";


	$request = $_REQUEST;

	$col = array(
		0	=>	'log_id',
		1	=>	'remark',
		2	=>	'date_log',
	);

	$sql = "SELECT log_id,remark,date_log from tbl_log_dean WHERE type ='Department Chairperson' AND department_name = 'Business Administration Program'";

	$query = mysqli_query($conn,$sql);

	$totalData = mysqli_num_rows($query);

	$filter = $totalData;

	$sql ="SELECT log_id,remark,date_log from tbl_log_dean WHERE type ='Department Chairperson' AND department_name = 'Accountancy Program' AND 1=1";
	if(!empty($request['search']['value'])){
	    $sql.=" AND (log_id Like '".$request['search']['value']."%' ";
	    $sql.=" OR remark Like '".$request['search']['value']."%' ";
	    $sql.=" OR date_log Like '".$request['search']['value']."%' )";
	}

	$query = mysqli_query($conn,$sql);
	$totalData = mysqli_num_rows($query);

	$sql.=" ORDER BY ".$col[$request['order'][0]['column']]."   ".$request['order'][0]['dir']."  LIMIT ".
    $request['start']."  ,".$request['length']."  ";

	$query = mysqli_query($conn,$sql);

	$data = array();

	while ($row = mysqli_fetch_array($query)) {

		$date = strtotime($row[2]);
		$format = date('M d Y  g:i:A' ,$date);

	    $subdata = array();
	    $subdata[] = $row[0];
	    $subdata[] = $row[1];
	    $subdata[] = "$format";
	    $data[] = $subdata;
	}

	$json_data=array(
	    "draw"              =>  intval($request['draw']),
	    "recordsTotal"      =>  intval($totalData),
	    "recordsFiltered"   =>  intval($filter),
	    "data"              =>  $data
	);

	echo json_encode($json_data);

?>