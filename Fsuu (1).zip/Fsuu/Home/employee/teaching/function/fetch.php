<?php  
	
	require "../../../../connector/connect.php";

	session_start();

	$id =  $_SESSION['account_fk'];

	$output = "";


	$que = "SELECT *from tbl_employee_msg JOIN office_head ON office_head.office_id = tbl_employee_msg.office_fk WHERE tbl_employee_msg.account_fk = $id AND status IN (0,1) AND text_msg != '' order by date_msg DESC";
		$result = mysqli_query($conn,$que);
		$output = "";
		if (mysqli_num_rows($result) > 0) {
			while ($row = mysqli_fetch_assoc($result)) {
				$assign = $row['office_assign'];

				$date = strtotime($row['date_msg']);
				$format = date('M d Y  g:i:A' ,$date);
			    $output .='	
			    	<li class="message-list" id="'.$row['employee_msg_id'].'">
			    	<button id="btn" style="display: none;">'.$row['employee_msg_id'].'</button>
			    		<span class="fw-bold fs-6">'.$assign.'</span>
			    		<br>
			    		<small>'.$row['text_msg'].' <br> <span>'.$format.'</span></small>
			    		<hr>
			    	</li>
			    ';
			}
		}
		else{
			$output .= '
				<li> <center>	<a  class="text-bold text-italic nav-link text-secondary fw-bold fs-5">No Message</a> </center> </li>
			';
		}
	
	$query = "SELECT *from tbl_employee_msg WHERE account_fk = $id AND status =0";
	$result_1 = mysqli_query($conn,$query);
	$count = mysqli_num_rows($result_1);
	
	$data = array(
		'notification'	=> $output,
		'unseen_notification'	=> $count
	);
	echo json_encode($data);

	// }

?>