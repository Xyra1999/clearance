<?php  


	session_start();

	if ($_SESSION['admin']) {
		require "../../connector/connect.php";
		$email = $_SESSION['admin'];

		$find = "SELECT *from account_type WHERE email ='$email'";

		$result = mysqli_query($conn,$find);

	    if (mysqli_num_rows($result) > 0) {
	        while ($row = mysqli_fetch_assoc($result)) {
	            $u_email = $row['email'];
	            $id = $row['account_info_id'];
	            Data($u_email,$id);
	            break;
	        }
    	}
	}
	else{
		header("location: ../../index");
		exit();
	}

?>

<?php  

	function Data($u_email,$id){
		require "../../connector/connect.php";

		$search = "SELECT *FROM account_type as account JOIN account_info as info ON account.account_info_id = info.account_type_fk WHERE account.email = '$u_email'";

		$result = mysqli_query($conn,$search);

	    if (mysqli_num_rows($result) > 0) {
	        while ($row = mysqli_fetch_assoc($result)) {
	            $u_email = $row['email'];
	            $fname = $row['fname'];
	            $mname = $row['mname'];
	            $lname = $row['lname'];
	            Display($u_email,$fname,$mname,$lname);
	            break;
	        }
    	}

	}
?>

<?php  

	function Display($u_email,$fname,$mname,$lname){
		?>

			<!DOCTYPE html>
			<html>
			<head>
				<meta charset="utf-8">
				<meta http-equiv="X-UA-Compatible" content="IE=edge">
				<link href="../../assets/css/bootstrap.min.css" rel="stylesheet">
				<link rel="stylesheet" href="../../assets/css/style.css">
				<link href="../../assets/icon/fsuu.png" rel="icon">
				<link href="../../assets/css/alertify.css" rel="stylesheet">
    			<link href="../../assets/css/alertify.min.css" rel="stylesheet">
    			<link rel="stylesheet" href="../../assets/css/jquery.dataTables.min.css">
				<link rel="stylesheet" href="../../assets/css/responsive.dataTables.min.css">
				<link rel="stylesheet" href="css/admin.css">
				<title>Father Saturnino Urios University</title>
			</head>
			<body>


			<!-- header -->
			<nav class="navbar navbar-default banner-color">
			  <div class="container-fluid">
			    <a href="index"><img src="../../assets/image/plain.png" alt="" height="100" width="200" class="img-fluid rounded"></a>
			    <div class="d-flex">
			      <div class="row">
			      	<div class="list">
			      		<ul>
			      			<li><span class="text-light fw-bold">Super Admin</span></li>
			      			<li><span class="text-light fw-bold"><?php echo $fname." ".$lname; ?></span></li>
			      			<li><a class="text-light fw-bold" href="logout"><i class="fas fa-power-off"></i></a></li>
			      		</ul>
			      	</div>
			      </div>
			    </div>
			  </div>
			</nav>
			<div class="color-header">
				<div class="container">
					<div class="inside-header">
						<ul>
							<li><a href="add" class="text-secondary">Add Admin</a></li>
							<li><a class="text-primary fw-bold" href="progress">Progess</a></li>
							<li><a class="text-secondary" href="academic">Set Academic Year</a></li>
							<li><a class="text-secondary" href="clearance">Clearance Cleared</a></li>
							<li><a class="text-secondary" href="report">Logs</a></li>
							<li><a class="text-secondary" href="add_department">Add Department & Course</a></li>
							<li><a class="text-secondary" href="display">Display Data</a></li>
							<li><a class="text-secondary" href="import">Import CSV</a></li>
						</ul>
					</div>
					<div class="bar-header">
						<!-- <button class="btn btn-outline-primary"></button> -->
						<i class="fas fa-bars fs-4" style="cursor: pointer;"></i>
					</div>
				</div>
			</div>
			<!-- end of header -->
			<br>
			<div class="container">
				<div class="col-md-4">
					<button class="btn btn-sm btn-primary" id="add_office"><i class="fas fa-plus"></i> Add Office </button>
				</div>
			</div>

			<div class="mt-3">
				<div class="container">
					<div class="box-center">
						<div class="draw-box">
							<div class="box">
								<div class="row">

									<?php  

										require "../../connector/connect.php";

										$sql = "SELECT *FROM tbl_office_name order by office_name ASC";

										$result = mysqli_query($conn,$sql);

										while ($row = mysqli_fetch_assoc($result)) {
												$office_id = $row['office_name_id'];
												$office = $row['office_name'];
										    ?>

										    	<div class="col-md-3 mt-3">
					<div class="card">
						<div class="card-body">
							<h3 class="card-title flex-row">
								<span class="fs-6" id="card_office_name"><?php echo $row['office_name']; ?></span> <button class="btn btn-sm btn-outline" id="option" value="<?php echo $office_id; ?>"><i class="fas fa-ellipsis-v fs-6 text-secondary" style="cursor: pointer;"></i></button>
							</h3>
							<div class="card-subtitle mb-2 text-muted fs-6">
								Executive
							</div>
							<div class="card-text">
								<p class="text-justify">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Dolorem nobis dolores molestias rem iste deserunt dicta sunt ipsam, fugit sint sequi, deleniti quae similique consequatur, laboriosam? Dignissimos voluptatem, id commodi.</p>
							</div>
						</div>
					</div>
				</div>

										    <?php
										}
									?>

		<?php
	}

?>


	<!-- modal for add offce -->

	<div class="modal_add_office">
		<div class="container">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header banner">
						<div class="modal-title">
							<h3 class="fs-5 text-light">Add Office</h3>
						</div>
					</div>
					<div class="modal-body">
						<label for="" class="form-label">
							Office Name:
						</label>
						<input type="text" class="form-control" id="office_name">
					</div>
					<div class="modal-footer">
						<button class="btn btn-secondary btn-sm" id="close_office">Close</button>
						<button class="btn btn-primary btn-sm" id="add_office_name">Add Office</button>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- end of add modal offcie -->

	<!-- modal option -->

	<div class="modal-option-office">
		<div class="container">
			<div class="col-md-12">
				<div class="modal-dialog modal-lg">
			<div class="modal-content">
				<div class="modal-header banner">
					<div class="modal-title">
						<h3 class="fs-5 text-light">Option - <span class="office-name"></span></h3>
					</div>
				</div>
				<div class="modal-body">
					<div class="option-btn">
						<button class="btn btn-primary btn-sm" value="" id="add-office"> <i class="fas fa-plus"></i> Add</button>
					
					<button class="btn btn-danger btn-sm" value="" id="delete-office"> <i class="fas fa-trash-alt"></i> Delete</button>
					<br>
					<div class="container mt-4">
						<div class="table-box">
							<table id="example" class="table table-striped display responsive nowrap" style="width:100%">
					        <thead>
					            <tr class="table-dark">
					                <th>Name</th>
					                <th class="text-center">Action</th>
					            </tr>
					        </thead>
					        <tbody class="table-office">

					        </tbody>
			          	</table>
						</div>
					</div>
					</div>
					<div class="add-person">
						<div class="container">
							<div class="row">
								<div class="col-md-12">
									<label for="">
										Email
									</label>
									<input type="text" class="form-control" id="email">
								</div>
								<div class="col-md-12">
									<label for="">
										ID Number
									</label>
									<input type="text" class="form-control" id="idnum">
								</div>
								
							</div>
						</div>
						<div class="modal-footer">
							<button class="btn btn-secondary btn-sm" id="cancel-add-person">Cancel</button>
							<button class="btn btn-primary btn-sm" id="add-personel">Add</button>
						</div>
					</div>
					<div class="trasnfer_data">
						<div class="container">
							<div class="row">
								<center><h3 class="text-secondary fs-5">Transfer Office</h3></center>
								<div class="col-md-12">
									<label for="">
										Email
									</label>
									<input type="text" class="form-control" id="tmp_email" disabled>
								</div>
								<div class="col-md-12">
									<label for="">
										ID Number
									</label>
									<input type="text" class="form-control" id="idnum" disabled>
								</div>
								<div class="col-md-12">
									<label for="">
										Office
									</label>
									<select name="" id="office_name_transfer" class="form-select">
										<?php  

											require "../../connector/connect.php";

											$sql = "SELECT *FROM tbl_office_name WHERE office_name NOT IN('Program_dean','Department_chaiperson') order by office_name ASC";

											$result = mysqli_query($conn,$sql);
											while ($row = mysqli_fetch_assoc($result)) {
													$office = $row['office_name'];
													$id = $row['office_name_id'];
												?>
													<option value="<?php echo $id ?>"><?php echo $office; ?></option>
												<?php
											}
										?>
									</select>
								</div>
							</div>
						</div>
						<div class="modal-footer">
							<button class="btn btn-secondary btn-sm" id="cancel-transfer">Cancel</button>
							<button class="btn btn-primary btn-sm" id="transfer_account_data">Transfer</button>
						</div>
					</div>
				</div>
				<div class="modal-footer office-footer">
					<button class="btn btn-sm btn-secondary" id="close_office_modal">Close</button>
				</div>
			</div>
		</div>
			</div>
		</div>
	</div>
	<!-- end of modal option -->


	<!-- modal employee profile -->
	<div class="modal-profile">
		<div class="container">
			<div class="modal-dialog modal-lg">
				<div class="modal-content">
					<div class="modal-header banner">
						<div class="modal-title">
							<h3 class="text-light fs-5">Office Head Profile</h3>
						</div>
					</div>
					<div class="modal-body">
						<div class="container">
							<div class="row">
								<div class="col-md-12">
									<label for="" class="form-label">
										Email
									</label>
									<input type="text" class="form-control" id="office_email">
								</div>
								<div class="col-md-12">
									<label for="" class="form-label">
										First Name
									</label>
									<input type="text" class="form-control" id="fname">
								</div>
							
								<div class="col-md-12">
									<label for="" class="form-label">
										Last Name
									</label>
									<input type="text" class="form-control" id="lname">
								</div>
							</div>
						</div>
					</div>
					<div class="modal-footer">
						<button class="btn btn-sm btn-secondary" id="close_profile">Close</button>
						<button class="btn btn-sm btn-success" id="update_status">Update</button>
					</div>
				</div>
			</div>
		</div>
	</div>


	<!-- end of modal employee profile -->






<script type="text/javascript" src="../../assets/js/fontawesome.js"></script>
<script type="text/javascript" src="../../assets/js/jquery-3.4.1.min.js"></script>
	<script src="../../assets/js/alertify.js"></script>
    <script src="../../assets/js/alertify.min.js"></script>
    <script type="text/javascript" src="../../assets/js/datatables.min.js"></script>
<script src="js/admin.js"></script>
<script src="js/load.js"></script>

<script>
	
</script>
</body>
</html>