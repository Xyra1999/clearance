$(document).ready(function(event) {

    // update profile
     $('#update_profile').click(function(event) {
        var id = $(this).attr('value');
        var fname = $('#fname').val();
        var mnane = $('#mname').val();
        var lname = $('#lname').val();

        console.log(fname+"\n"+lname);

        $.ajax({
            url: "function/update",
            type: "POST",
            data: {
                "teaching_update" : true,
                id:id,
                fname:fname,
                mnane:mnane,
                lname:lname,
            },
            success:function(response){
                // console.log(response);
                if (response == 1) {
                 alertify.success("Data Updated");
                 setTimeout(function(){
                     window.location="profile"
                 },2000);
                }
                else{
                 alertify.error("Update Failed");
                 setTimeout(function(){
                     window.location="profile"
                 },2000);
                }
            }
        });
    });

     // apply clearance
     $('#apply').click(function(event) {
         /* Act on the event */
         var purpose = $('#purpose_select').val();
         var id = $('#idnumber').val();
         var key = $(this).val();
         var office = $('.office-assign').text();

         if (purpose == "") {
            alertify.error("Please Select Purpose");
         }
         else{
             $.ajax({
                url: "function/apply_clearance",
                type: "POST",
                data: {
                    "Apply" : true,
                    purpose:purpose,
                    id:id,
                    key:key,
                    office:office,
                },
                success:function(response){
                    console.log(response);
                    if (response == 1) {
                        alertify.success("Apply Clearance Submitted");
                    }
                    else if (response == 2) {
                        alertify.notify("Already Submitted");
                    }
                    else{
                        alertify.error("Failed to Apply");
                    }
                }
             });
         }
        
     });

    $(document).on('click', '#registrar', function(event) {
        event.preventDefault();
        var id = $(this).attr('value');

        // $('.modal_box').addClass('bg-active');
        $.ajax({
            url: "function/update",
            type: "POST",
            data: {
                "seacrch" : true,
                id:id,
            },
            success:function(response){
                
                if (response == 2) {

                }
                else{
                    $.each(response, function(index, val) {
                        $('.modal_box').addClass('bg-active');
                        $('#office_fk').prop('value',val['office_fk']);
                        $('#msg').text(val['text_msg']);
                        $('#msg_reply').text(val['text_msg']);
                        $('#employee_status_fk').prop('value',val['office_fk']);
                        $('#employee_send').prop('value',val['employee_status_fk']);
                      
                    });
                }
            }
        });
        /* Act on the event */
    });

    $('#employee_send').click(function(event) {
        
        var id = $(this).attr('value');
        var reply_msg = $('#msg_user').val();
        var office = $('#employee_status_fk').prop('value');
        var convo_id = $('#convo_id').prop('value');

        $.ajax({
            url: "function/update",
            type: "POST",
            data: {
                "reply_msg" : true,
                id:id,
                reply_msg:reply_msg,
                office:office,
                convo_id:convo_id,
            },
            success:function(response){
                console.log(response);
                if (response == 1) {
                    alertify.success("Send Mesage");
                    setTimeout(function(){
                        $('.modal_box').removeClass('bg-active');
                        $('.msg_box').css('display', 'block');
                        $('.reply').css('display', 'none');
                    },2000);
                }
                else{
                    alertify.error("Failed to Send");
                    setTimeout(function(){
                        $('.modal_box').removeClass('bg-active');
                        $('.msg_box').css('display', 'block');
                        $('.reply').css('display', 'none');
                    },2000);
                }
            }
        });

    });

    $('#employee_reply').click(function(event) {
        /* Act on the event */
        $('.msg_box').css('display', 'none');
        $('.reply').css('display', 'block');
    });
    $('#close_modal').click(function(event) {
        /* Act on the event */
        $('.modal_box').removeClass('bg-active');
    });
    $('#back').click(function(event) {
        /* Act on the event */
        $('.msg_box').css('display', 'block');
        $('.reply').css('display', 'none');
    });
    $('#file_q').change(function(event) {
        var file = $('#file_q').val().split('.').pop().toLowerCase();

        if ($.inArray(file,['pdf']) == 0) {
            $('.error').text('');
        }
        else{
            $('.error').text('Please attach pdf file only');
        }
    });

     $('#status_select').change(function(event) {
         var text = $(this).val();

         if (text == "PERAA") {
            window.location = "peraa"
         }
         else if (text == "SEPARATION") {
            window.location = "separation"
         }
         else{
            window.location = "grading"
         }
     });

     $('#status_select_requirements').change(function(event) {
         /* Act on the event */

         var text = $(this).val();
         if (text == "PERAA REQUIREMENTS") {
            window.location = "peraa-deficiency"
         }
         else if (text == "SEPARATION REQUIREMENTS") {
            window.location = "separation-deficiency"
         }
         else{
            window.location = "grading-deficiency"
         }
     });


     $('#message-modal').click(function(event) {
        // console.log("wd");
         $('.message').toggleClass('show');
         $('body').toggleClass('off');
     });

});