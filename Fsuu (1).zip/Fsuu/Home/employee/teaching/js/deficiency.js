$(document).ready(function(event){
	$(document).on('click', '#btn_deficiency', function(event) {
		event.preventDefault();

		var id = $(this).attr('value');
		// var txt = $('#o_name').text();

		// console.log(txt);

		$.ajax({
			url: "function/search",
			type: "POST",
			data: {
				"search_msg" : true,
				id:id,
			},
			success:function(response){
				console.log(response);
				if (response == 2) {
					
				}
				else{
					$.each(response, function(index, val) {
						if (val['office_name'] == "Bookstore") {
							$('.modal-bookstore').addClass('bg-active');
							$('.modal-message-deficiency').removeClass('bg-active')
							// console.log(val['office_name']);
							$('#office_books').prop('value',val['office_name']);
							$('#purpose_books').prop('value',val['purpose']);
							$('#msg_defi_books').text(val['book']);
							$('#send_file').attr('value',id);
						}
						else{
							$('.modal-message-deficiency').addClass('bg-active');
							$('#office').prop('value',val['office_name']);
							$('#purpose').prop('value',val['purpose']);
							$('#msg_defi').text(val['book']);
						}
						// console.log(val['office_name']);
					});
				}
			}
		});

		/* Act on the event */
	});

	$('#send_file').click(function(event) {
		/* Act on the event */

		var load_file = $('#load_file')[0].files[0];
		var id = $(this).attr('value');

		var fileInput2 = document.getElementById('load_file');
		var filePath2 = fileInput2.value;

		var allowedExtensions = /(\.jpg|\.jpeg|\.png|\.pdf|\.docs)$/i;

		var form_data = new FormData();

		var prog = $('.progress-bar');
		var tmp = 0;

		// setInterval(function(){
		// 	tmp++;
		// 	prog.css('width',tmp,+'%');
		// 	prog.attr('aria-valuenow',tmp);
		// 	console.log(tmp);
		// },40)

		if ($('#load_file')[0].files.length === 1 && allowedExtensions.exec(filePath2)) {

			form_data.append('loan_file',load_file);
			form_data.append('id',id);

			$.ajax({
				url: "function/upload",
				type: "POST",
				datatype: "script",
				cache: false,
				contentType: false,
				processData: false,
				data: form_data,

				success:function(response){
					console.log(response);
					if (response == 1) {
						$('#load_file').val('');
						$('.books_file').hide();
						$('.msg_books').show();
						$('#close_modal_message').removeClass('bg-active')
					}
					else{

					}
				}
			});
		}
		else{
			$('.error').html("Please Attach File/Must Correcr file format");
		}

	});

	$('#close_modal_message').click(function(event) {
		/* Act on the event */
		$('.modal-message-deficiency').removeClass('bg-active');
	});

	$('#close_modal_message_books').click(function(event) {
		/* Act on the event */
		$('.modal-bookstore').removeClass('bg-active')
	});
	$('#proceed').click(function(event) {
		/* Act on the event */
		$('.msg_books').hide(300);
		$('.books_file').show(300);
	});
	$('#Cancel').click(function(event) {
		/* Act on the event */
		$('.msg_books').show(300);
		$('.books_file').hide(300);
	});

	$('#load_file').change(function(event) {
		/* Act on the event */
		var fileInput2 = document.getElementById('load_file');
		var filePath2 = fileInput2.value;

		var allowedExtensions = /(\.jpg|\.jpeg|\.png|\.pdf|\.docs)$/i;

		if (!allowedExtensions.exec(filePath2)) {
			$('.error').text("Please Attach The Correct Format");
		}
		else{
			$('.error').text('')
		}
	});


});