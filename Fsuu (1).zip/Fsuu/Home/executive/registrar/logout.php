<?php   
	session_start();
	unset($_SESSION['registrar']); 
	header("location: ../../../index"); 
	exit();
?>