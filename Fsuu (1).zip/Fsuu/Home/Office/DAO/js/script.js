$(document).ready(function(){
		
	$(document).on('click', '#approve', function(event) {
		event.preventDefault();
		var id = $(this).attr('value');
		console.log(id);

		$.ajax({
			url: "function/update",
			type: "POST",
			data:{
				"update_status" : true,
				id:id,
			},
			success:function(response){
				console.log(response);
				if (response == 1) {
					setTimeout(function(){
                        window.location = "student";
                    },1000);
				}
				else{

				}
			}
		});
	});

	$(document).on('click','#view-student',function(event){
		var id = $(this).attr('value');

		$.ajax({
			url: "function/update",
			type: "POST",
			data: {
				"search_data" : true,
				id:id,
			},
			success:function(response){
                // console.log(response);
				$('#status tbody').empty();
				if (response == 2) {

				}
				else{
					$.each(response,function(index,val){
						$('.status-modal-student').addClass('bg-status');

                        var admis = val['admission']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                        var ces = val['ces']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                        var guidance = val['guidance']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                        var ora = val['ora']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                        var dsa = val['dsa']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                        var dao = val['dao']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                        var program_dean = val['program_dean']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                        var record_incharge = val['record_incharge']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                        var veritas = val['veritas']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                        var cashier = val['cashier']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                        var registrar = val['registrar']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";

                    $('.data-student').append('<tr>'+
                            '<td class="text-center">Admission and Scholarship</td>'+
                           
                            '<td class="text-center">'+admis+'</td>'+
                            '</tr>'+

                            '<tr>'+
                        '<td class="text-center">CES Office</td>'+
                      
                        '<td class="text-center"> '+ces+' </td>'+
                        '</tr>'+
                        '<tr>'+
                        '<td class="text-center">Guidance Office</td>'+
                       
                        '<td class="text-center"> '+guidance+' </td>'+
                        '</tr>'+
                        '<tr>'+
                        '<td class="text-center">Office Religious Affairs</td>'+
                      
                        '<td class="text-center"> '+ora+'</td>'+
                        '</tr>'+
                        '<tr>'+
                        '<td class="text-center">DSA Office</td>'+
                     
                        '<td class="text-center"> '+dsa+' </td>'+
                        '</tr>'+
                        '<td class="text-center">VERITAS</td>'+
                     
                        '<td class="text-center"> '+veritas+'</td>'+
                        '</tr>'+
                        '<td class="text-center">DAO</td>'+
                       
                        '<td class="text-center"> '+dao+'</td>'+
                        '</tr>'+
                        '<td class="text-center">Cashier</td>'+
                        
                        '<td class="text-center"> '+cashier+'</td>'+
                        '</tr>'+
                        '<td class="text-center">Program Dean</td>'+
                      
                        '<td class="text-center"> '+program_dean+'</td>'+
                        '</tr>'+
                        '<td class="text-center">Records incharge</td>'+
                        
                        '<td class="text-center"> '+record_incharge+'</td>'+
                        '</tr>'+
                        '<td class="text-center">Registrar Office</td>'+
                       
                        '<td class="text-center"> '+registrar+'</td>'+
                        '</tr>');

					});
				}
			}
		});
    });


    $('#status-modal-close-student').click(function(event){
        $('.status-modal-student').removeClass('bg-status');
    })
    $('#status-modal-close-student').click(function(event){
        $('.status-modal').removeClass('bg-status');
    })
	
	$(document).on('click','#view-student-status',function(event){
		var id = $(this).attr('value');

		$.ajax({
			url: "function/update",
			type: "POST",
			data: {
				"search_data" : true,
				id:id,
			},
			success:function(response){
                console.log(response);
				$('#status tbody').empty();
				if (response == 2) {

				}
				else{
					$.each(response,function(index,val){
						$('.status-modal').addClass('bg-status');

                        var admis = val['admission']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                        var ces = val['ces']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                        var guidance = val['guidance']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                        var ora = val['ora']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                        var dsa = val['dsa']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                        var dao = val['dao']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                        var program_dean = val['program_dean']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                        var record_incharge = val['record_incharge']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                        var veritas = val['veritas']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                        var cashier = val['cashier']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                        var registrar = val['registrar']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";

                    $('.data-student').append('<tr>'+
                            '<td class="text-center">Admission and Scholarship</td>'+
                           
                            '<td class="text-center">'+admis+'</td>'+
                            '</tr>'+

                            '<tr>'+
                        '<td class="text-center">CES Office</td>'+
                      
                        '<td class="text-center"> '+ces+' </td>'+
                        '</tr>'+
                        '<tr>'+
                        '<td class="text-center">Guidance Office</td>'+
                       
                        '<td class="text-center"> '+guidance+' </td>'+
                        '</tr>'+
                        '<tr>'+
                        '<td class="text-center">Office Religious Affairs</td>'+
                      
                        '<td class="text-center"> '+ora+'</td>'+
                        '</tr>'+
                        '<tr>'+
                        '<td class="text-center">DSA Office</td>'+
                     
                        '<td class="text-center"> '+dsa+' </td>'+
                        '</tr>'+
                        '<td class="text-center">VERITAS</td>'+
                     
                        '<td class="text-center"> '+veritas+'</td>'+
                        '</tr>'+
                        '<td class="text-center">DAO</td>'+
                       
                        '<td class="text-center"> '+dao+'</td>'+
                        '</tr>'+
                        '<td class="text-center">Cashier</td>'+
                        
                        '<td class="text-center"> '+cashier+'</td>'+
                        '</tr>'+
                        '<td class="text-center">Program Dean</td>'+
                      
                        '<td class="text-center"> '+program_dean+'</td>'+
                        '</tr>'+
                        '<td class="text-center">Records incharge</td>'+
                        
                        '<td class="text-center"> '+record_incharge+'</td>'+
                        '</tr>'+
                        '<td class="text-center">Registrar Office</td>'+
                       
                        '<td class="text-center"> '+registrar+'</td>'+
                        '</tr>');

					});
				}
			}
		});
	})
});