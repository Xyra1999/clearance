<?php   
	session_start();
	unset($_SESSION['vp_arr']); 
	header("location: ../../../index"); 
	exit();
?>