$(document).ready(function(event){
	$(document).on('click', '#view', function(event) {
        event.preventDefault();
        var id = $(this).prop('value');

        $.ajax({
            url: "function/search",
            type: "POST",
            data: {
                "search_employee" : true,
                id:id,
            },
            success:function(response){
            	console.log(response);
                $('#status tbody').empty();
                if (response == 2) {

                }
                else{
                    $.each(response, function(index, val) {
                        
                    $('.status-modal').addClass('bg-status');

                      var regis = val['registrar']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var library = val['library']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var pmo = val['pmo']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var bookstore = val['bookstore']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var itsd = val['ITSD']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var comproller = val['Comptroller']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var program_dean = val['program_dean']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var arts = val['asp_dean']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var hrmd = val['HRMD']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var vp_aar = val['vp_aar']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                     var Cashier = val['Cashier']  == 0 ? "<span  class='text-light bg-danger p-2 rounded' style='font-size: 13px;''>Pending</span>" : "<span  class='text-light bg-success p-2 rounded' style='font-size: 13px;''>Approved</span>";
                $('.data-employee').append('<tr class="text-center">'+
                            '<td>Registrar Office</td>'+
                           

                            '<td>'+regis+'</td>'+
                        '</tr>'+
                        '<tr class="text-center">'+
                            '<td>College Librarian</td>'+
                  
                            '<td>'+library+'</td>'+
                        '</tr>'+
                        '<tr class="text-center">'+
                            '<td>Property and Maintenance Office</td>'+
                       
                            '<td>'+pmo+'</td>'+
                        '</tr>'+
                        '<tr class="text-center">'+
                            '<td>Bookstore/Auxilliary Resource Services</td>'+
                          
                            '<td>'+bookstore+'</td>'+
                        '</tr>'+
                        '<tr class="text-center">'+
                            '<td>ITSD</td>'+
                            
                            '<td>'+itsd+'</td>'+
                        '</tr>'+
                        '<tr class="text-center">'+
                            '<td>Comptroller</td>'+
                            
                            '<td>'+comproller+'</td>'+
                        '</tr>'+
                        '<tr class="text-center">'+
                            '<td>Program Dean</td>'+
                        
                            '<td>'+program_dean+'</td>'+
                        '</tr>'+
                        '<tr class="text-center">'+
                            '<td>Dean Art and Science</td>'+
                          
                            '<td>'+arts+'</td>'+
                        '</tr>'+
                        '<tr class="text-center">'+
                            '<td>Cashier</td>'+
                       
                            '<td>'+Cashier+'</td>'+
                        '</tr>'+
                        '<tr class="text-center">'+
                            '<td>HRMD (Director)</td>'+
              
                            '<td>'+hrmd+'</td>'+
                        '</tr>'+
                        '<tr class="text-center">'+
                            '<td>Academic Affairs and Research (VP-AAR)</td>'+
        
                            '<td>'+vp_aar+'</td>'+
                        '</tr>');

                    });
                }
            }
        });
	});
});