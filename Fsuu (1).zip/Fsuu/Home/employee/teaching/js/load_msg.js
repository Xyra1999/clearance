$(document).ready(function(event) {
	

	$(document).on('click', '.message-list', function(event) {
		event.preventDefault();

		var id = $(this).closest('li').find('#btn').text();
		// console.log(id);
		$.ajax({
			url: "function/search",
			type: "POST",
			data: {
				"search" : true,
				id:id,
			},
			success:function(response){
				$('.message').removeClass('show')
				$('body').removeClass('off')
				if (response == 2) {

				}
				else{
					$.each(response, function(index, val) {
						$('.modal_box').addClass('bg-active');
						$('#msg_reply').text(val['text_msg']);
						$('#msg').text(val['text_msg']);
						$('#employee_send').attr('value',val['office_fk']);
						$('#convo_id').prop('value',val['employee_msg_id']);
					});
				}
			}
		});
	});

	load_msg();


	setInterval(function(){
		load_msg();
	},2000)



});


function load_msg(view=""){
	$.ajax({
		url: "function/fetch",
		method: "POST",
		data:{
			view:view,
		},
		dataType: "json",
		success:function(data){
			
			$('.data-msg').html(data.notification);
			if (data.unseen_notification > 0) {
				$('.count').html(data.unseen_notification);
			}
			else{
				$('.count').html("");
			}
		}
	});
}