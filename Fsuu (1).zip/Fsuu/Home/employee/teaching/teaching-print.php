<?php  

	session_start();

	if ($_SESSION['teaching_id']) {
		require "../../../connector/connect.php";
		$id = $_SESSION['teaching_id'];

        $purpose = $_SESSION['purpose'];

		$find = "SELECT *from account_type WHERE account_info_id = $id";

		$result = mysqli_query($conn,$find);

	    if (mysqli_num_rows($result) > 0) {
	        while ($row = mysqli_fetch_assoc($result)) {
	            $u_email = $row['email'];
	            $id = $row['account_info_id'];
	            get_all_data($u_email,$id,$purpose);
	            break;
	        }
    	}
	}
	else{
		header("location: peraa");
		exit();
	}

?>


<?php  
	

	function get_all_data($u_email,$id,$purpose){

		require "../../../connector/connect.php";

		$sql = "SELECT *FROM account_type as account JOIN tbl_employee as employee ON account.account_info_id = employee.emplo_account_fk JOIN tbl_employee_info as info ON account.account_info_id = info.emplo_info_account_fk WHERE account.account_info_id = $id";

		$result = mysqli_query($conn,$sql);

		if (mysqli_num_rows($result) > 0) {
			while ($row = mysqli_fetch_assoc($result)) {
				$idnumber = $row['emplo_idnumber'];
				$fname = $row['emplo_fname'];
				$mname = $row['emplo_mname'];
				$lname = $row['emplo_lname'];
				$sy = $row['emplo_school_year'];
				$department_id = $row['employee_office'];
				// $sem = $row['student_sem'];
				Data($u_email,$id,$idnumber,$fname,$mname,$lname,$sy,$department_id,$purpose);
				break;
			}
		}
	}

?>
 

    


<?php  

	function Data($u_email,$id,$idnumber,$fname,$mname,$lname,$sy,$department_id,$purpose){
		?>

			<!DOCTYPE html>
			<html>
			<head>
				<meta charset="utf-8">
				<meta http-equiv="X-UA-Compatible" content="IE=edge">
				<link href="../../../assets/css/bootstrap.min.css" rel="stylesheet">
				<link rel="stylesheet" href="../../../assets/css/style.css">
				<link href="../../assets/icon/fsuu.png" rel="icon">
				<link rel="stylesheet" href="css/teaching.css">
				<title>Print</title>
			</head>
			<body onload="load();">

             

				<div class="modal-body" id="template_1">
                <!-- titleHeader -->
                <center>
                     <div class="d-inline-flex mt-4">
                        <div>
                            <img src="../../../assets/icon/fsuu.png" alt="fsuu logo" style="width:90px; height:90px;">
                        </div>
                        <div class="mt-3">
                            <p>Father Saturnino Urios University</p>
                            <p>Butuan City</p>
                        </div>
                     </div>
                </center>

                <div class="mt-5 mx-5">
                    <p>
                        This is to certify that <b id="applicant_name"><?php echo $fname." ".$mname." ".$lname; ?></b>  of <b id="applicant_dept"><?php 

                        	echo $department_id;

                        ?></b> is cleared of all obligations from all the offices listed below effective on school year Academic Year (<span><u><?php echo $sy ?></u></span>) (<span><u><?php echo "2nd"; ?></u></span>) Semester.
                    </p>
                    <div class="mt-2">
                        <table class="table table-bordered border-dark">
                            <thead>
                                <th style="width: 50%">Office</th>
                                <th>Verified & Cleared by :</th>
                            </thead>
                            <tbody id="offices">
                            	<tr>
                            		<th>Admission and Scholarship</th>
                            		<th>Approved</th>
                            	</tr>
                            	<tr>
                            		<th>CES Office</th>
                            		<th>Approved</th>
                            	</tr>
                            	<tr>
                            		<th>Guidance Office</th>
                            		<th>Approved</th>
                            	</tr>
                            	<tr>
                            		<th>Office Religious Affairs</th>
                            		<th>Approved</th>
                            	</tr>
                            	<tr>
                            		<th>DSA Office</th>
                            		<th>Approved</th>
                            	</tr>
                            	<tr>
                            		<th>VERITAS</th>
                            		<th>Approved</th>
                            	</tr>
                            	<tr>
                            		<th>DAO</th>
                            		<th>Approved</th>
                            	</tr>
                            	<tr>
                            		<th>Cashier</th>
                            		<th>Approved</th>
                            	</tr>
                            	<tr>
                            		<th>Program Dean</th>
                            		<th>Approved</th>
                            	</tr>
                            	<tr>
                            		<th>Records incharge</th>
                            		<th>Approved</th>
                            	</tr>
                            	<tr>
                            		<th>Registrar's Office</th>
                            		<th>Approved</th>
                            	</tr>
                            </tbody>
                        </table>
                    </div>
                    <div style="margin-top:100px;">
                        <p style="margin-top:0;margin-bottom:0;padding:0;">This document is digitally signed by <b>FSUU CLEARANCE</b>. </p>
                        <p style="margin-top:0;margin-bottom:0;padding:0;">Date: <b><span id="date_now"></span></b></p>
                        <p style="margin-top:0;margin-bottom:0;padding:0;">Date Cleared: <b><span id="date_cleared"></span></b></p>
                        <p style="margin-top:0;margin-bottom:0;padding:0;">Type of Clearance: <b>Teaching</b></p>
                        <p style="margin-top:0;margin-bottom:0;padding:0;">Father Saturnino Urios University, Butuan City</p>
                        <p style="margin-top:0;margin-bottom:0;padding:0;">For any concerns you may contact, registrar@urios.edu.ph, 09107917378 and hrmd@urios.edu.ph, 09107917378</p>
                    </div>
                </div>
            </div>
        </div>

        <br>
        <br>
        <br>
        <br><br>
        <br><br>
        <br><br>
        <br><br>
        <br><br>
        <br><br>
        <br><br>
        <br><br>
        <br><br>
        <br><br>
        <br><br>
      

        <div id="template_2" class="border mt-5">
                    <center>
                        <div class="d-inline-flex mt-4">
                            <div>
                                <img src="../../../assets/icon/fsuu.png" alt="fsuu logo" style="width:90px; height:90px;">
                            </div>
                            <div class="mt-3">
                                <b>
                                    <p style="margin-top:0;margin-bottom:0;padding:0;">Father Saturnino Urios University</p>
                                    <p style="margin-top:0;margin-bottom:0;padding:0;">OFFICE OF THE UNIVERSITY REGISTRAR</p>
                                    <p style="margin-top:0;margin-bottom:0;padding:0;">Butuan City</p>
                                </b>
                            </div>
                        </div>
                    </center>
                    <br>
                    <br>
                    <center>
                    <b><p
                            style="
                            font-family: Times New Roman, Times, serif;
                            font-size:25px;
                            "
                            >
                                CLEARANCE FOR GRADING SHEETS
                        </p></b>
                    </center>
                    <br>
                    <div class="mx-5">
                        <p style="font-size:20px;" class="my-5">
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            This is to certify that <b id="applicant_name_2"></b>  of <b id="applicant_dept_2"></b> 
                        This is to certify that <b id="applicant_name_2"></b>  of <b id="applicant_dept_2"></b> 
                            This is to certify that <b id="applicant_name_2"></b>  of <b id="applicant_dept_2"></b> 
                        This is to certify that <b id="applicant_name_2"></b>  of <b id="applicant_dept_2"></b> 
                            This is to certify that <b id="applicant_name_2"></b>  of <b id="applicant_dept_2"></b> 
                            has submitted the hard copies of all his/her grading sheets (without INCs) for
                            <span><u></u></span> Semester
                            of SY <span><u><?php echo $sy ?></u></span>.
                        </p>
                        <br>
                        <br>
                        <br>
                        <center>
                        <u><b><p style="margin-top:0;margin-bottom:0;padding:0;font-size:20px;" id="reg-head-name"></p></b></u><u><b><p style="margin-top:0;margin-bottom:0;padding:0;font-size:20px;" id="reg-head-name"></p></b></u>
                            <p style="margin-top:0;margin-bottom:0;padding:0;"><b>University Registrar</b></p>
                        </center>
                        <br>
                        <br>
                    </div>
                </div>

				
			

		<?php
	}

?>
	<script type="text/javascript" src="../../../assets/js/jquery-3.4.1.min.js"></script>
	<!-- <script src="js/print.js"></script> -->
	<script type="text/javascript">
		
		function load(){
			// document.getElementById("template_1").css('display','none');
			var today = new Date();
			var dd = String(today.getDate()).padStart(2, '0');
			var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
			var yyyy = today.getFullYear();

			today = mm + '/' + dd + '/' + yyyy;

			// console.log(today);

			document.getElementById('date_now').innerHTML = today;

			window.print();
			
		}

	</script>

</body>
</html>