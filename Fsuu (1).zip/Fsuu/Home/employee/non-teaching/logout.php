<?php   
	session_start();
	unset($_SESSION['non_teaching']); 
	header("location: ../../../index"); 
	exit();
?>