<?php   
	session_start();
	unset($_SESSION['cashier']); 
	header("location: ../../../index"); 
	exit();
?>