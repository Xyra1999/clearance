<?php  

	require "../../../connector/connect.php";

	if (isset($_POST['set_year'])) {
		$new_sy = mysqli_real_escape_string($conn,$_POST['new_sy']);
		$new_sem = mysqli_real_escape_string($conn,$_POST['new_sem']);


		$insert = "INSERT INTO academic_year (school_year,semester,date_set) VALUES ('$new_sy','$new_sem',NOW())";

		if (mysqli_query($conn,$insert) === TRUE) {
			echo 1;
		}
	}
	else if (isset($_POST['add_admin'])) {
		$email = mysqli_real_escape_string($conn,$_POST['email']);
		$role = mysqli_real_escape_string($conn,$_POST['role']);
		$office_name = mysqli_real_escape_string($conn,$_POST['office_name']);
		$idnumber = mysqli_real_escape_string($conn,$_POST['idnumber']);

		$search = "SELECT email FROM account_type WHERE email = '$email'";

		$result = mysqli_query($conn,$search);



		if (mysqli_num_rows($result) > 0) {
			echo 2;
		}
		else{
			if ($role == "admin") {
				$insert = "INSERT INTO account_type(email,type) VALUES('$email','$role')";

				if (mysqli_query($conn,$insert) === TRUE) {
					echo 1;
				}
				else{
					echo 3;
				}
			}
			else{
				$insert_data = "INSERT INTO account_type(email,type) VALUES('$email','$role')";
				if (mysqli_query($conn,$insert_data) === TRUE) {
					$last_id = mysqli_insert_id($conn);
					$data = "INSERT INTO office_head(office_fname,office_lname,office_assign,date_registered,account_fk,department_fk) VALUES('','','$office_name',NOW(),$last_id,null)";

					if (mysqli_query($conn,$data) == TRUE) {
						echo 1;
					}
				}
				else{
					echo 3;
				}
			}
		}
	}
	else if (isset($_POST['add_admin_department'])) {
		$email = mysqli_real_escape_string($conn,$_POST['email']);
		$role = mysqli_real_escape_string($conn,$_POST['role']);
		$office_name = mysqli_real_escape_string($conn,$_POST['office_name']);
		$idnumber = mysqli_real_escape_string($conn,$_POST['idnumber']);
		$dept_name = mysqli_real_escape_string($conn,$_POST['dept_name']);

		// echo $email;

		$search = "SELECT email FROM account_type WHERE email = '$email'";

		$result = mysqli_query($conn,$search);

		if (mysqli_num_rows($result) > 0) {
			echo 2;
		}
		else{
			if ($role == "admin") {
				$insert = "INSERT INTO account_type(email,type) VALUES('$email','$role')";

				if (mysqli_query($conn,$insert) === TRUE) {
					echo 1;
				}
				else{
					echo 3;
				}
			}
			else{
				$insert_data = "INSERT INTO account_type(email,type) VALUES('$email','$role')";
				if (mysqli_query($conn,$insert_data) === TRUE) {
					$last_id = mysqli_insert_id($conn);

					$sql_dept_id = "SELECT *FROM tbl_department WHERE department_name = '$dept_name'";
					$result_q = mysqli_query($conn,$sql_dept_id);
					while ($row = mysqli_fetch_assoc($result_q)) {
					    $id_department = $row['department_id'];
					    Chairperson($id_department,$email,$role,$office_name,$idnumber,$last_id);
					    break;
					}
				}
				else{
					echo 3;
				}
			}
		}

	}
	else if (isset($_POST['add_office'])) {
		$name = mysqli_real_escape_string($conn,$_POST['name']);

		$sql = "INSERT INTO tbl_office_name(office_name,office_fk) VALUES('$name',null)";

		if (mysqli_query($conn,$sql) === TRUE) {
			# code...
			echo 1;
		}
	}
?>

<?php  


	function Chairperson($id_department,$email,$role,$office_name,$idnumber,$last_id){
		require "../../../connector/connect.php";

	

		$data = "INSERT INTO office_head(office_fname,office_lname,office_assign,date_registered,account_fk,department_fk) VALUES('','','$office_name',NOW(),$last_id,$id_department)";

		if (mysqli_query($conn,$data) == TRUE) {
			echo 1;
		}

	}

?>