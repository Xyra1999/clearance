
<?php  

	require "../../../../connector/connect.php";


	$request = $_REQUEST;

	$col = array(
		0	=>	'register_log',
		1	=>	'purpose',
		2	=>	'idnumber',
		3	=>	'remark',
		4	=>	'date_log',
	);

	$sql = "SELECT *from tbl_registrar_log";

	$query = mysqli_query($conn,$sql);

	$totalData = mysqli_num_rows($query);

	$filter = $totalData;

	$sql ="SELECT *from tbl_registrar_log WHERE 1=1";
	if(!empty($request['search']['value'])){
	    $sql.=" AND (register_log Like '".$request['search']['value']."%' ";
	    $sql.=" OR remark Like '".$request['search']['value']."%' ";
	    $sql.=" OR idnumber Like '".$request['search']['value']."%' ";
	    $sql.=" OR purpose Like '".$request['search']['value']."%' ";
	    $sql.=" OR date_log Like '".$request['search']['value']."%' )";
	}

	$query = mysqli_query($conn,$sql);
	$totalData = mysqli_num_rows($query);

	$sql.=" ORDER BY ".$col[$request['order'][0]['column']]."   ".$request['order'][0]['dir']."  LIMIT ".
    $request['start']."  ,".$request['length']."  ";

	$query = mysqli_query($conn,$sql);

	$data = array();

	while ($row = mysqli_fetch_array($query)) {

		$date = strtotime($row[4]);
		$format = date('M d Y  g:i:A' ,$date);

	    $subdata = array();
	    $subdata[] = $row[0];
	    $subdata[] = $row[2];
	    $subdata[] = $row[3];
	    $subdata[] = $row[1];
	    $subdata[] = $format;
	    $data[] = $subdata;
	}

	$json_data=array(
	    "draw"              =>  intval($request['draw']),
	    "recordsTotal"      =>  intval($totalData),
	    "recordsFiltered"   =>  intval($filter),
	    "data"              =>  $data
	);

	echo json_encode($json_data);

?>