<?php   
	session_start();
	unset($_SESSION['ces']); 
	header("location: ../../../index"); 
	exit();
?>