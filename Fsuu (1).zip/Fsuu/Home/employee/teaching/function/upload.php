<?php  

	
	require "../../../../connector/connect.php";


	$file_directory = "../../../../upload/";

	$id = mysqli_real_escape_string($conn,$_POST['id']);


	// file name
	$permit_num1 = $_FILES['loan_file']['name'];

	// file goes to the directory
	$target = $file_directory.basename($_FILES['loan_file']['name']);


	$filetype = strtolower(pathinfo($target,PATHINFO_EXTENSION));

	$newfilename = $file_directory.$permit_num1;

	$move =  move_uploaded_file($_FILES["loan_file"]["tmp_name"],$newfilename);	


	$update = "UPDATE tbl_defiency_employee SET upload_files ='$permit_num1' WHERE tbl_library_defiency_id = $id";

	if (mysqli_query($conn,$update) === TRUE) {
		echo 1;
	}

?>