<?php   
	session_start();
	unset($_SESSION['chair_bap']); 
	header("location: ../../../../index"); 
	exit();
?>