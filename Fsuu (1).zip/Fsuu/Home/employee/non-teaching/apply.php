<?php  


	session_start();

	if ($_SESSION['non_teaching']) {
		require "../../../connector/connect.php";
		$email = $_SESSION['non_teaching'];

		$find = "SELECT *from account_type WHERE email ='$email'";

		$result = mysqli_query($conn,$find);

	    if (mysqli_num_rows($result) > 0) {
	        while ($row = mysqli_fetch_assoc($result)) {
	            $u_email = $row['email'];
	            $id = $row['account_info_id'];
	            Data($u_email,$id);
	            break;
	        }
    	}
	}
	else{
		header("location: ../../../index");
		exit();
	}

?>

<?php  

	function Data($u_email,$id){
		require "../../../connector/connect.php";

		$search = "SELECT *FROM account_type as account JOIN tbl_employee as employee ON account.account_info_id = employee.emplo_account_fk WHERE employee.emplo_account_fk = '$id'";

		$result = mysqli_query($conn,$search);

	    if (mysqli_num_rows($result) > 0) {
	        while ($row = mysqli_fetch_assoc($result)) {
	            $fname = $row['emplo_fname'];
	            $mname = $row['emplo_mname'];
	            $lname = $row['emplo_lname'];
	            $emplo_id = $row['emplo_idnumber'];
	            $emplo_school_year = $row['emplo_school_year'];
	            $employee_id = $row['employee_id'];
	            $employee_fk = $row['emplo_account_fk'];
	            Display($u_email,$fname,$mname,$lname,$emplo_id,$emplo_school_year,$employee_id,$employee_fk);
	            break;
	        }
    	}

	}
?>

<?php  

	function Display($u_email,$fname,$mname,$lname,$emplo_id,$emplo_school_year,$employee_id,$employee_fk){
		?>

			<!DOCTYPE html>
			<html>
			<head>
				<meta charset="utf-8">
				<meta http-equiv="X-UA-Compatible" content="IE=edge">
				<link href="../../../assets/css/bootstrap.min.css" rel="stylesheet">
				<link rel="stylesheet" href="../../../assets/css/style.css">
				<link href="../../../assets/icon/fsuu.png" rel="icon">
				<link href="../../../assets/css/alertify.css" rel="stylesheet">
    			<link href="../../../assets/css/alertify.min.css" rel="stylesheet">
				<title>Father Saturnino Urios University</title>
			</head>
			<body>


			<!-- header -->
			<nav class="navbar navbar-default banner-color">
			  <div class="container-fluid">
			    <a href="index"><img src="../../../assets/image/plain.png" alt="" height="100" width="200" class="img-fluid rounded"></a>
			    <div class="d-flex">
			      <div class="row">
			      	<div class="list">
			      		<ul>
			      			<li><span class="text-light fw-bold" style="font-size: 16px;"><?php echo $fname." ".$lname; ?></span></li>
			      			<li><a href="profile" class="text-light fw-bold"><i class="fas fa-user-circle fs-6"></i></a></li>
			      			<li><a class="text-light fw-bold" href="logout"><i class="fas fa-power-off"></i></a></li>
			      		</ul>
			      	</div>
			      </div>
			    </div>
			  </div>
			</nav>
			
			<div class="color-header">
				<div class="container">
					<div class="inside-header text-left">
						<ul>
							<li><a href="add" class="text-secondary">Apply Clearance</a></li>
							<li><a class="text-secondary" href="status">Clearance Status</a></li>
							<li><a class="text-secondary" href="archieves">Archieves</a></li>
						</ul>
					</div>
				</div>
			</div>
			<!-- end of header -->

			<div class="mt-4">
				<div class="container">
					<div class="modal-dialog modal-xl">
						<div class="modal-content">
							<div class="modal-header banner">
								<div class="modal-title text-light fs-5">
									<div class="d-flex justify-content-between">
										Apply Clearance
									</div>
									<span class="text-light fs-6">SY-<?php echo $emplo_school_year; ?></span>
								</div>
							</div>
							<div class="modal-body">
								<br>
								<div class="row">
									<div class="col-md-4">
										<label for="" class="form-label">
											ID Number
										</label>
										<input type="text" class="form-control fs-6 fw-bold text-secondary bg-light" value="<?php echo $emplo_id; ?>" id="idnum" disabled>
									</div>
									<div class="col-md-4">
										<label for="" class="form-label">
											Purpose
										</label>
										<select name="" id="non_teaching" class="form-select">
											<option value="" disabled selected>Choose Purpose</option>
											<option value="PERAA">PERAA</option>
											<option value="SEPARATION">SEPARATION</option>
											<option value="GRADING">GRADING</option>
										</select>
									</div>
								</div>
								
					
							<div class="modal-footer">
								<button class="btn btn-success btn-sm" value="<?php echo $employee_fk; ?>" id="clearance_submit">Submit</button>
							</div>
						</div>
					</div>
				</div>
			</div>



		<?php
	}

?>



<script type="text/javascript" src="../../../assets/js/fontawesome.js"></script>
<script type="text/javascript" src="../../../assets/js/jquery-3.4.1.min.js"></script>
<script src="../../../assets/js/alertify.js"></script>
<script src="../../../assets/js/alertify.min.js"></script>
<script src="js/non_teaching.js"></script>


</body>
</html>