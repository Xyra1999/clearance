<?php  


	require "../../../connector/connect.php";

	$sql = "SELECT *FROM academic_year order by date_set DESC limit 1";


	$result_val = [];
		$result_q = mysqli_query($conn,$sql);
		if (mysqli_num_rows($result_q) > 0) {
			foreach ($result_q as $value) {
			    array_push($result_val,$value);
			    // break;

			}
			header("Content-type: application/json");
			echo json_encode($result_val);

		}
		else{
			echo 2;
		}


?>