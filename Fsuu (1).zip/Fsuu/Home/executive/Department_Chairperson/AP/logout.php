<?php   
	session_start();
	unset($_SESSION['chair_ap']); 
	header("location: ../../../../index"); 
	exit();
?>