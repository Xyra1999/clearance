<?php  

	require "../../../../connector/connect.php";


	if (isset($_POST['update_status'])) {
		
		$id = mysqli_real_escape_string($conn,$_POST['id']);

		$sql = "UPDATE tbl_student_status SET cashier = 1 WHERE student_info_id = $id";

		if (mysqli_query($conn,$sql) === TRUE) {
			echo 1;
		}
	}
	else if (isset($_POST['employee_update'])) {

		$id = mysqli_real_escape_string($conn,$_POST['id']);

		$sql = "UPDATE tbl_employee_status SET Cashier = 1 WHERE tbl_employee_id = $id";

		if (mysqli_query($conn,$sql) === TRUE) {
			echo 1;
		}
	}

	else if (isset($_POST['undo_student'])) {
		# code...

		$id = mysqli_real_escape_string($conn,$_POST['id']);

		$sql = "UPDATE tbl_student_status SET cashier = 0 WHERE student_info_id = $id";

		if (mysqli_query($conn,$sql) === TRUE) {
			echo 1;
		}
	}
	else if (isset($_POST['undo_employee'])) {

		$id = mysqli_real_escape_string($conn,$_POST['id']);

		$sql = "UPDATE tbl_employee_status SET Cashier = 0 WHERE tbl_employee_id = $id";

		if (mysqli_query($conn,$sql) === TRUE) {
			echo 1;
		}
	}


?>