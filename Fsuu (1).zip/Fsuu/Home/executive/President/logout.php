<?php   
	session_start();
	unset($_SESSION['president']); 
	header("location: ../../../index"); 
	exit();
?>