<?php   
	session_start();
	unset($_SESSION['chair_cjep']); 
	header("location: ../../../../index"); 
	exit();
?>