<?php   
	session_start();
	unset($_SESSION['adminssion']); 
	header("location: ../../../index"); 
	exit();
?>