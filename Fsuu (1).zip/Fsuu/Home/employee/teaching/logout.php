<?php   
	session_start();
	unset($_SESSION['teaching']); 
	header("location: ../../../index"); 
	exit();
?>