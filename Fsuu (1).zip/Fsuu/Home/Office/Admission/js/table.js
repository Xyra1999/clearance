$(document).ready(function() {
   
    $('#example').DataTable({
        "processing": true,
        "serverSide": true,
        "ajax" : "function/server"
    });
    responsive: true

});




