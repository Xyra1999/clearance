<?php   
	session_start();
	unset($_SESSION['chair_nursing']); 
	header("location: ../../../../index"); 
	exit();
?>