<?php  

	if (isset($_POST['import'])) {
		$filename = $_FILES['student_file']['tmp_name'];

		$sy = $_SESSION['sy'];
		$sem - $_SESSION['sem'];

		if ($_FILES['student_file']['size'] > 0) {
			$file = fopen($filename, 'r');


			while (($row = fgetcsv($file,10000,",")) !== FALSE) {
			    $idnumber = $row[0];
			    $email = $row[1];
			    $course = $row[2];
			    $date_birth = $row[3];
			    $place_birth = $row[4];
			    $citizen = $row[5];
			    $religion = $row[6];
			    $contact = $row[7];
			    $street = $row[8];
			    $brgy = $row[9];
			    $city = $row[10];
			    // echo $count;
			    Search_data($idnumber,$email,$course,$sy,$date_birth,$place_birth,$citizen,$religion,$contact,$street,$brgy,$city,$sem);
			}
			fclose($file);
		}
	}

?>

<?php  
	
	function Search_data($idnumber,$email,$course,$sy,$date_birth,$place_birth,$citizen,$religion,$contact,$street,$brgy,$city,$sem){

		require "../../connector/connect.php";

		$search = "SELECT *FROM account_type WHERE email = '$email'";

		$result = mysqli_query($conn,$search);

		if (mysqli_num_rows($result) > 0) {

			// echo $result;
				
		}
		else{
			$find = "SELECT *from tbl_department as deparment JOIN tbl_course as course ON deparment.department_id = course.department_fk WHERE course.course_name = '$course'";

			$result_find = mysqli_query($conn,$find);
			if (mysqli_num_rows($result_find) > 0) {
				while ($row = mysqli_fetch_assoc($result_find)) {
				    $course_id = $row['course_id'];
				    Insert_data($idnumber,$email,$course,$sy,$course_id,$date_birth,$place_birth,$citizen,$religion,$contact,$street,$brgy,$city,$sem);
				    // echo $course_id;
				    // break;
				}
			}
		}
	}
?>

<?php  
	
	function Insert_data($idnumber,$email,$course,$sy,$course_id,$date_birth,$place_birth,$citizen,$religion,$contact,$street,$brgy,$city,$sem){
		require "../../connector/connect.php";

		$insert_type = "INSERT INTO account_type(email,type) VALUES ('$email','student')";
	    if (mysqli_query($conn,$insert_type) === TRUE) {
	    	$last_id = mysqli_insert_id($conn);
	    	$insert = "INSERT INTO tbl_student(fname,mname,lname,idnumber,school_year,student_sem,account_student_fk,student_department_fk) VALUES ('','','','$idnumber','$sy','$sem',$last_id,$course_id)";
	    	if (mysqli_query($conn,$insert) === TRUE) {
	    		$student_key = mysqli_insert_id($conn);

	    		$student_info = "INSERT INTO tbl_student_info(date_birth,place_birth,citizenship,religion,contact,street,barangay,city,student_fk) VALUES('$date_birth','$place_birth','$citizen','$religion','$contact','$street','$brgy','$city',$student_key)";

	    		if (mysqli_query($conn,$student_info) === TRUE) {
	    			echo "<script> 
	    			alert('Uploaded')  
	    			window.location='import';
	    		</script>";
	    		}
	    	}
	    }
	}

?>